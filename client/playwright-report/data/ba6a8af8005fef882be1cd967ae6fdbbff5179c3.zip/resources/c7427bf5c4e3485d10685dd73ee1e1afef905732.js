import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/LocationPickerModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=38a573e6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=38a573e6"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import __vite__cjsImport4_reactDom from "/node_modules/.vite/deps/react-dom.js?v=38a573e6"; const createPortal = __vite__cjsImport4_reactDom["createPortal"];
import { MapContainer, TileLayer, Marker, Polygon, useMapEvents } from "/node_modules/.vite/deps/react-leaflet.js?v=38a573e6";
import __vite__cjsImport6_leaflet from "/node_modules/.vite/deps/leaflet.js?v=38a573e6"; const L = __vite__cjsImport6_leaflet.__esModule ? __vite__cjsImport6_leaflet.default : __vite__cjsImport6_leaflet;
import { X, MapPin, Navigation, Search } from "/node_modules/.vite/deps/lucide-react.js?v=38a573e6";
import { toast } from "/src/components/ui/Toast.jsx";
import "/node_modules/leaflet/dist/leaflet.css";
import {
  reverseGeocode,
  toLegacyAddressFields,
  buildAddressPreview,
  LIGHT_MAP_TILES,
  LIGHT_MAP_ATTRIBUTION,
  smartAddressBuilder,
  detectCurrentLocation,
  cleanAddressFields
} from "/src/utils/format.jsx";
import { latLngToS2CellId } from "/src/utils/s2Helper.js";
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png"
});
const locationIcon = L.divIcon({
  html: `<div style="background-color: #EF4444; width: 28px; height: 28px; border-radius: 50% 50% 50% 0; border: 3px solid white; transform: rotate(-45deg); box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>`,
  className: "",
  iconSize: [28, 28],
  iconAnchor: [14, 28],
  popupAnchor: [1, -34]
});
const DraggableMarker = ({ position, setPosition }) => {
  _s();
  const markerRef = useRef(null);
  const eventHandlers = {
    dragend() {
      const marker = markerRef.current;
      if (marker != null) {
        const newPos = marker.getLatLng();
        setPosition([newPos.lat, newPos.lng]);
      }
    }
  };
  useMapEvents({
    click(e) {
      setPosition([e.latlng.lat, e.latlng.lng]);
    }
  });
  return /* @__PURE__ */ jsxDEV(
    Marker,
    {
      draggable: true,
      eventHandlers,
      position,
      ref: markerRef,
      icon: locationIcon
    },
    void 0,
    false,
    {
      fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
      lineNumber: 75,
      columnNumber: 5
    },
    this
  );
};
_s(DraggableMarker, "au3a/ip+t6g+xvZjSjpO6VCngWM=", false, function() {
  return [useMapEvents];
});
_c = DraggableMarker;
const MapUpdater = ({ center }) => {
  _s2();
  const map = useMapEvents({});
  useEffect(() => {
    map.setView(center, Math.max(map.getZoom(), 16));
  }, [center, map]);
  return null;
};
_s2(MapUpdater, "gWh149/DLPuF22WgXAndVVlzhL4=", false, function() {
  return [useMapEvents];
});
_c2 = MapUpdater;
const LocationPickerModal = ({ isOpen, onClose, onLocationSelect }) => {
  _s3();
  const [position, setPosition] = useState([20.5937, 78.9629]);
  const [structuredAddress, setStructuredAddress] = useState(null);
  const [loading, setLoading] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [hasInitialized, setHasInitialized] = useState(false);
  const [houseNo, setHouseNo] = useState("");
  const [road, setRoad] = useState("");
  const [area, setArea] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const geocodeTimerRef = useRef(null);
  const shouldSkipGeocodeRef = useRef(false);
  const searchContextRef = useRef(null);
  const didInitializeRef = useRef(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const cellId13 = position ? latLngToS2CellId(position[0], position[1], 13) : null;
  const cellId20 = position ? latLngToS2CellId(position[0], position[1], 20) : null;
  const handleSearch = async (query) => {
    setSearchQuery(query);
    if (query.trim().length < 3) {
      setSearchResults([]);
      setShowDropdown(false);
      return;
    }
    setSearching(true);
    try {
      const res = await fetch(`https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=15&countrycode=in&lat=${position[0]}&lon=${position[1]}&location_bias_scale=0.6`);
      const data = await res.json();
      let results = data?.features || [];
      results = results.filter((feat) => {
        const props = feat.properties || {};
        const country = props.country || "";
        const countryCode = props.countrycode || "";
        return country.toLowerCase() === "india" || countryCode.toLowerCase() === "in";
      });
      if (results.length < 5) {
        try {
          const nomSearchRes = await fetch(
            `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&addressdetails=1&countrycodes=in&limit=10&accept-language=en`,
            { headers: { "User-Agent": "RajServiceBooking/1.0 (service-booking-app)" } }
          );
          const nomSearchJson = await nomSearchRes.json();
          if (Array.isArray(nomSearchJson) && nomSearchJson.length > 0) {
            const mappedNom = nomSearchJson.map((item) => ({
              geometry: {
                coordinates: [parseFloat(item.lon), parseFloat(item.lat)]
              },
              properties: {
                name: item.address.amenity || item.address.shop || item.address.building || item.address.house_number || item.display_name.split(",")[0],
                street: item.address.road || item.address.suburb || "",
                city: item.address.city || item.address.town || item.address.village || "",
                state: item.address.state || "",
                postcode: item.address.postcode || "",
                country: item.address.country || "India",
                district: item.address.suburb || item.address.neighbourhood || ""
              }
            }));
            const existingKeys = new Set(results.map((r) => {
              const namePart = (r.properties.name || "").toLowerCase();
              const cityPart = (r.properties.city || "").toLowerCase();
              return `${namePart}|${cityPart}`;
            }));
            for (const item of mappedNom) {
              const key = `${(item.properties.name || "").toLowerCase()}|${(item.properties.city || "").toLowerCase()}`;
              if (!existingKeys.has(key)) {
                results.push(item);
                existingKeys.add(key);
              }
            }
          }
        } catch (nomErr) {
          console.warn("Nominatim search fallback failed:", nomErr);
        }
      }
      setSearchResults(results.slice(0, 15));
      setShowDropdown(results.length > 0);
    } catch (err) {
      console.error("Search error:", err);
    } finally {
      setSearching(false);
    }
  };
  const handleSelectSearchResult = (result) => {
    const coords = result.geometry.coordinates;
    const lat = coords[1];
    const lng = coords[0];
    const pProps = result.properties || {};
    const pincodeMatch = searchQuery.match(/\b\d{6}\b/);
    const queryPincode = pincodeMatch ? pincodeMatch[0] : null;
    const postcode = queryPincode || pProps.postcode || "";
    const cityVal = pProps.city || "";
    const streetVal = pProps.street || "";
    const areaVal = pProps.district || pProps.suburb || pProps.locality || pProps.name || "";
    searchContextRef.current = {
      pincode: postcode,
      area: areaVal,
      road: streetVal,
      city: cityVal
    };
    setRoad(streetVal);
    setArea(areaVal);
    setCity(cityVal);
    setPincode(postcode);
    shouldSkipGeocodeRef.current = true;
    setPosition([lat, lng]);
    fetchAddressFromCoords(lat, lng);
    setShowDropdown(false);
    setSearchQuery("");
  };
  useEffect(() => {
    if (isOpen && !didInitializeRef.current) {
      didInitializeRef.current = true;
      handleCurrentLocation();
      setHasInitialized(true);
    }
    if (!isOpen) {
      didInitializeRef.current = false;
      setHasInitialized(false);
    }
  }, [isOpen]);
  useEffect(() => {
    if (!isOpen || position[0] === 20.5937 && position[1] === 78.9629) return;
    if (shouldSkipGeocodeRef.current) {
      shouldSkipGeocodeRef.current = false;
      return;
    }
    if (geocodeTimerRef.current) clearTimeout(geocodeTimerRef.current);
    geocodeTimerRef.current = setTimeout(() => {
      fetchAddressFromCoords(position[0], position[1]);
    }, 700);
    return () => {
      if (geocodeTimerRef.current) clearTimeout(geocodeTimerRef.current);
    };
  }, [position, isOpen]);
  const handleCurrentLocation = async () => {
    if (detecting) return;
    setDetecting(true);
    toast.info("Detecting your current location...");
    try {
      const result = await detectCurrentLocation({
        timeout: 4e3,
        targetAccuracy: 150,
        maxUpdates: 1,
        maxRetries: 0
      });
      shouldSkipGeocodeRef.current = true;
      setPosition([result.latitude, result.longitude]);
      setStructuredAddress(result.address);
      setHouseNo(result.address.houseNumber || "");
      setRoad(result.address.road || "");
      setArea(result.address.area || result.address.locality || "");
      setCity(result.address.city || "");
      setPincode(result.address.pincode || result.address.postalCode || "");
    } catch (err) {
      toast.error(err.message || "Could not fetch current location");
    } finally {
      setDetecting(false);
    }
  };
  const fetchAddressFromCoords = async (lat, lng) => {
    setLoading(true);
    try {
      const data = await reverseGeocode(lat, lng);
      if (searchContextRef.current) {
        const ctx = searchContextRef.current;
        const finalRoadValue = ctx.road || data.road || "";
        const finalAreaValue = ctx.area || data.area || data.locality || "";
        const finalCityValue = ctx.city || data.city || "";
        let finalPincodeValue = ctx.pincode || data.pincode || data.postalCode || "";
        if (finalPincodeValue.endsWith("001") && ctx.pincode && ctx.pincode !== "") {
          finalPincodeValue = ctx.pincode;
        }
        setStructuredAddress({
          ...data,
          road: finalRoadValue,
          area: finalAreaValue,
          city: finalCityValue,
          pincode: finalPincodeValue,
          postalCode: finalPincodeValue
        });
        setHouseNo(data.houseNumber || "");
        setRoad(finalRoadValue);
        setArea(finalAreaValue);
        setCity(finalCityValue);
        setPincode(finalPincodeValue);
        searchContextRef.current = null;
      } else {
        setStructuredAddress(data);
        setHouseNo(data.houseNumber || "");
        setRoad(data.road || "");
        setArea(data.area || data.locality || "");
        setCity(data.city || "");
        setPincode(data.pincode || data.postalCode || "");
      }
    } catch (error) {
      console.error("Error fetching address:", error);
      toast.error("Could not resolve address for this location");
    } finally {
      setLoading(false);
    }
  };
  const handleConfirm = () => {
    if (!structuredAddress) {
      toast.error("Please wait for address to load or select a valid location");
      return;
    }
    const updatedAddress = {
      ...structuredAddress,
      houseNumber: houseNo.trim(),
      road: road.trim(),
      area: area.trim(),
      city: city.trim(),
      pincode: pincode.trim(),
      postalCode: pincode.trim(),
      lat: position[0],
      lng: position[1]
    };
    if (houseNo.trim()) {
      const streetBase = updatedAddress.road || updatedAddress.street || "";
      if (streetBase) {
        if (!streetBase.includes(houseNo.trim())) {
          updatedAddress.street = `${houseNo.trim()}, ${streetBase}`;
        } else {
          updatedAddress.street = streetBase;
        }
      } else {
        updatedAddress.street = houseNo.trim();
      }
      updatedAddress.addressLine = updatedAddress.street;
    }
    updatedAddress.formattedAddress = buildAddressPreview(updatedAddress) || smartAddressBuilder(
      {
        house_number: houseNo.trim(),
        road: updatedAddress.road,
        residential: updatedAddress.area,
        neighbourhood: updatedAddress.area,
        suburb: updatedAddress.area,
        city: updatedAddress.city,
        state: updatedAddress.state,
        postcode: updatedAddress.pincode
      },
      updatedAddress._displayName || updatedAddress.formattedAddress
    );
    const legacy = {
      ...toLegacyAddressFields(updatedAddress),
      s2CellId: cellId13,
      s2CellIdPrecise: cellId20
    };
    onLocationSelect(legacy);
    onClose();
  };
  if (!isOpen) return null;
  const displayText = structuredAddress ? buildAddressPreview({
    ...structuredAddress,
    houseNumber: houseNo,
    road,
    area,
    city,
    pincode
  }) || structuredAddress.formattedAddress : "";
  return createPortal(
    /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col h-[90vh] max-h-[780px]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 border-b border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-secondary flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(MapPin, { className: "w-5 h-5 text-primary" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 412,
            columnNumber: 13
          }, this),
          " Select Your Location"
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 411,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "p-1 hover:bg-gray-100 rounded-full transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 415,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 414,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
        lineNumber: 410,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative p-3 border-b border-gray-100 bg-white z-[1005]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: searchQuery,
              onChange: (e) => handleSearch(e.target.value),
              placeholder: "Search address in India...",
              className: "w-full pl-10 pr-10 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
            },
            void 0,
            false,
            {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 422,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(Search, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 430,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 429,
            columnNumber: 13
          }, this),
          searching && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 right-0 pr-3 flex items-center", children: /* @__PURE__ */ jsxDEV("div", { className: " rounded-full h-4 w-4 border-2 border-primary border-t-transparent" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 434,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 433,
            columnNumber: 13
          }, this),
          !searching && searchQuery && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setSearchQuery("");
                setSearchResults([]);
                setShowDropdown(false);
              },
              className: "absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 border-none bg-transparent",
              children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                lineNumber: 447,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 438,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 421,
          columnNumber: 11
        }, this),
        showDropdown && searchResults.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-full left-0 right-0 mt-1 mx-3 bg-white border border-gray-200 rounded-lg shadow-xl max-h-[220px] overflow-y-auto z-[1010] divide-y divide-gray-50", children: searchResults.map((result, idx) => {
          const props = result.properties || {};
          const name = props.name || "";
          const street = props.street || "";
          const city2 = props.city || "";
          const state = props.state || "";
          const postcode = props.postcode || "";
          const mainTitle = name || street || city2;
          const subTitle = [
            name ? street : "",
            props.district || props.suburb || "",
            city2,
            state,
            postcode
          ].filter(Boolean).filter((s) => s !== mainTitle).join(", ");
          return /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleSelectSearchResult(result),
              className: "w-full text-left px-4 py-2.5 hover:bg-gray-50 text-xs text-secondary transition-colors flex items-start gap-2.5 border-none bg-transparent",
              children: [
                /* @__PURE__ */ jsxDEV(MapPin, { className: "w-4 h-4 text-primary shrink-0 mt-0.5" }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                  lineNumber: 480,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-secondary text-xs", children: mainTitle }, void 0, false, {
                    fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                    lineNumber: 482,
                    columnNumber: 23
                  }, this),
                  subTitle && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10px] mt-0.5", children: subTitle }, void 0, false, {
                    fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                    lineNumber: 483,
                    columnNumber: 36
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                  lineNumber: 481,
                  columnNumber: 21
                }, this)
              ]
            },
            idx,
            true,
            {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 474,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 454,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
        lineNumber: 420,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative bg-gray-100", children: [
        /* @__PURE__ */ jsxDEV(MapContainer, { center: position, zoom: 16, style: { height: "100%", width: "100%" }, children: [
          /* @__PURE__ */ jsxDEV(TileLayer, { attribution: LIGHT_MAP_ATTRIBUTION, url: LIGHT_MAP_TILES }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 494,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DraggableMarker, { position, setPosition }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 495,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(MapUpdater, { center: position }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 496,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 493,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onPointerDown: (e) => e.stopPropagation(),
            onClick: (e) => {
              e.preventDefault();
              e.stopPropagation();
              handleCurrentLocation();
            },
            disabled: detecting,
            className: "absolute bottom-4 right-4 z-[1000] bg-red-500 hover:bg-red-600 text-white p-3 rounded-full shadow-lg shadow-red-500/20 active:scale-95 transition-all border-none flex items-center justify-center disabled:opacity-70 disabled:cursor-wait",
            title: detecting ? "Detecting location..." : "My Location",
            "aria-label": detecting ? "Detecting current location" : "Detect current location",
            children: /* @__PURE__ */ jsxDEV(Navigation, { className: `w-5 h-5 ${detecting ? "animate-pulse" : ""}` }, void 0, false, {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 513,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 500,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 left-1/2 -translate-x-1/2 z-[400] bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full shadow-md text-xs font-bold text-secondary border border-gray-200 pointer-events-none text-center", children: "Drag the pin or tap on the map" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 516,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
        lineNumber: 492,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-gray-100 bg-white space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-500 mb-1", children: "House / Flat No." }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 523,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: houseNo,
              onChange: (e) => setHouseNo(e.target.value),
              placeholder: "e.g. 349, Flat 4B",
              className: "w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
            },
            void 0,
            false,
            {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 524,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 522,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 text-xs", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-2 rounded-lg border border-gray-200 focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-primary/10 transition-all duration-200", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-400 font-semibold block text-[10px] uppercase tracking-wider", children: "Road / Street" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 534,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: road,
                onChange: (e) => setRoad(e.target.value),
                placeholder: "e.g. Street 1, Main Road",
                className: "w-full bg-transparent text-secondary font-medium text-xs focus:outline-none border-none p-0 mt-0.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                lineNumber: 535,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 533,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-2 rounded-lg border border-gray-200 focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-primary/10 transition-all duration-200", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-400 font-semibold block text-[10px] uppercase tracking-wider", children: "Area / Locality" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 544,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: area,
                onChange: (e) => setArea(e.target.value),
                placeholder: "e.g. Urban Estate Phase 2",
                className: "w-full bg-transparent text-secondary font-medium text-xs focus:outline-none border-none p-0 mt-0.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                lineNumber: 545,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 543,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-2 rounded-lg border border-gray-200 focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-primary/10 transition-all duration-200", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-400 font-semibold block text-[10px] uppercase tracking-wider", children: "City" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 554,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: city,
                onChange: (e) => setCity(e.target.value),
                placeholder: "e.g. Mohali",
                className: "w-full bg-transparent text-secondary font-medium text-xs focus:outline-none border-none p-0 mt-0.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                lineNumber: 555,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 553,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-2 rounded-lg border border-gray-200 focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-primary/10 transition-all duration-200", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-400 font-semibold block text-[10px] uppercase tracking-wider", children: "Pincode" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
              lineNumber: 564,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: pincode,
                onChange: (e) => setPincode(e.target.value),
                placeholder: "e.g. 160062",
                className: "w-full bg-transparent text-secondary font-medium text-xs focus:outline-none border-none p-0 mt-0.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
                lineNumber: 565,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 563,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 532,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-400 mb-1", children: "Formatted Address" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 575,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-secondary line-clamp-3 min-h-[48px] bg-gray-50 p-2 rounded-lg border border-gray-100", children: loading ? /* @__PURE__ */ jsxDEV("span", { className: "animate-pulse text-gray-400", children: "Resolving address..." }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 578,
            columnNumber: 15
          }, this) : displayText ? displayText : "Move map pin to select location" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 576,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
          lineNumber: 574,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleConfirm,
            disabled: loading || !structuredAddress,
            className: "w-full py-3 bg-primary text-white rounded-lg text-sm font-bold hover:bg-primary/90 disabled:opacity-50 transition-colors shadow-sm",
            children: "Confirm Location"
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
            lineNumber: 586,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
        lineNumber: 521,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
      lineNumber: 409,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx",
      lineNumber: 408,
      columnNumber: 5
    }, this),
    document.body
  );
};
_s3(LocationPickerModal, "G3M29qKcNegZLFytmVhHqdp+Gmc=");
_c3 = LocationPickerModal;
export default LocationPickerModal;
var _c, _c2, _c3;
$RefreshReg$(_c, "DraggableMarker");
$RefreshReg$(_c2, "MapUpdater");
$RefreshReg$(_c3, "LocationPickerModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Project/Service/client/src/components/modals/LocationPickerModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZESixPQUFPQSxTQUFTQyxVQUFVQyxXQUFXQyxjQUFjO0FBQ25ELFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxjQUFjQyxXQUFXQyxRQUFRQyxTQUFTQyxvQkFBb0I7QUFDdkUsT0FBT0MsT0FBTztBQUNkLFNBQVNDLEdBQUdDLFFBQVFDLFlBQVlDLGNBQWM7QUFDOUMsU0FBU0MsYUFBYTtBQUV0QixPQUFPO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msd0JBQXdCO0FBR2pDLE9BQU9kLEVBQUVlLEtBQUtDLFFBQVFDLFVBQVVDO0FBQ2hDbEIsRUFBRWUsS0FBS0MsUUFBUUcsYUFBYTtBQUFBLEVBQzFCQyxlQUFlO0FBQUEsRUFDZkMsU0FBUztBQUFBLEVBQ1RDLFdBQVc7QUFDYixDQUFDO0FBRUQsTUFBTUMsZUFBZXZCLEVBQUV3QixRQUFRO0FBQUEsRUFDN0JDLE1BQU07QUFBQSxFQUNOQyxXQUFXO0FBQUEsRUFDWEMsVUFBVSxDQUFDLElBQUksRUFBRTtBQUFBLEVBQ2pCQyxZQUFZLENBQUMsSUFBSSxFQUFFO0FBQUEsRUFDbkJDLGFBQWEsQ0FBQyxHQUFHLEdBQUc7QUFDdEIsQ0FBQztBQUVELE1BQU1DLGtCQUFrQkEsQ0FBQyxFQUFFQyxVQUFVQyxZQUFZLE1BQU07QUFBQUMsS0FBQTtBQUNyRCxRQUFNQyxZQUFZekMsT0FBTyxJQUFJO0FBQzdCLFFBQU0wQyxnQkFBZ0I7QUFBQSxJQUNwQkMsVUFBVTtBQUNSLFlBQU1DLFNBQVNILFVBQVVJO0FBQ3pCLFVBQUlELFVBQVUsTUFBTTtBQUNsQixjQUFNRSxTQUFTRixPQUFPRyxVQUFVO0FBQ2hDUixvQkFBWSxDQUFDTyxPQUFPRSxLQUFLRixPQUFPRyxHQUFHLENBQUM7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEzQyxlQUFhO0FBQUEsSUFDWDRDLE1BQU1DLEdBQUc7QUFDUFosa0JBQVksQ0FBQ1ksRUFBRUMsT0FBT0osS0FBS0csRUFBRUMsT0FBT0gsR0FBRyxDQUFDO0FBQUEsSUFDMUM7QUFBQSxFQUNGLENBQUM7QUFFRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBLEtBQUtSO0FBQUFBLE1BQ0wsTUFBTVg7QUFBQUE7QUFBQUEsSUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLcUI7QUFHekI7QUFBRVUsR0EzQklILGlCQUFlO0FBQUEsVUFZbkIvQixZQUFZO0FBQUE7QUFBQSxLQVpSK0I7QUE2Qk4sTUFBTWdCLGFBQWFBLENBQUMsRUFBRUMsT0FBTyxNQUFNO0FBQUFDLE1BQUE7QUFDakMsUUFBTUMsTUFBTWxELGFBQWEsQ0FBQyxDQUFDO0FBQzNCUCxZQUFVLE1BQU07QUFDZHlELFFBQUlDLFFBQVFILFFBQVFJLEtBQUtDLElBQUlILElBQUlJLFFBQVEsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNqRCxHQUFHLENBQUNOLFFBQVFFLEdBQUcsQ0FBQztBQUNoQixTQUFPO0FBQ1Q7QUFBRUQsSUFOSUYsWUFBVTtBQUFBLFVBQ0YvQyxZQUFZO0FBQUE7QUFBQSxNQURwQitDO0FBUU4sTUFBTVEsc0JBQXNCQSxDQUFDLEVBQUVDLFFBQVFDLFNBQVNDLGlCQUFpQixNQUFNO0FBQUFDLE1BQUE7QUFDckUsUUFBTSxDQUFDM0IsVUFBVUMsV0FBVyxJQUFJekMsU0FBUyxDQUFDLFNBQVMsT0FBTyxDQUFDO0FBQzNELFFBQU0sQ0FBQ29FLG1CQUFtQkMsb0JBQW9CLElBQUlyRSxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDc0UsU0FBU0MsVUFBVSxJQUFJdkUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3dFLFdBQVdDLFlBQVksSUFBSXpFLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMwRSxnQkFBZ0JDLGlCQUFpQixJQUFJM0UsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzRFLFNBQVNDLFVBQVUsSUFBSTdFLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUM4RSxNQUFNQyxPQUFPLElBQUkvRSxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDZ0YsTUFBTUMsT0FBTyxJQUFJakYsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ2tGLE1BQU1DLE9BQU8sSUFBSW5GLFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUNvRixTQUFTQyxVQUFVLElBQUlyRixTQUFTLEVBQUU7QUFDekMsUUFBTXNGLGtCQUFrQnBGLE9BQU8sSUFBSTtBQUNuQyxRQUFNcUYsdUJBQXVCckYsT0FBTyxLQUFLO0FBQ3pDLFFBQU1zRixtQkFBbUJ0RixPQUFPLElBQUk7QUFDcEMsUUFBTXVGLG1CQUFtQnZGLE9BQU8sS0FBSztBQUdyQyxRQUFNLENBQUN3RixhQUFhQyxjQUFjLElBQUkzRixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDNEYsZUFBZUMsZ0JBQWdCLElBQUk3RixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDOEYsV0FBV0MsWUFBWSxJQUFJL0YsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2dHLGNBQWNDLGVBQWUsSUFBSWpHLFNBQVMsS0FBSztBQUd0RCxRQUFNa0csV0FBVzFELFdBQVdqQixpQkFBaUJpQixTQUFTLENBQUMsR0FBR0EsU0FBUyxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQzdFLFFBQU0yRCxXQUFXM0QsV0FBV2pCLGlCQUFpQmlCLFNBQVMsQ0FBQyxHQUFHQSxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUk7QUFFN0UsUUFBTTRELGVBQWUsT0FBT0MsVUFBVTtBQUNwQ1YsbUJBQWVVLEtBQUs7QUFDcEIsUUFBSUEsTUFBTUMsS0FBSyxFQUFFQyxTQUFTLEdBQUc7QUFDM0JWLHVCQUFpQixFQUFFO0FBQ25CSSxzQkFBZ0IsS0FBSztBQUNyQjtBQUFBLElBQ0Y7QUFDQUYsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTVMsTUFBTSxNQUFNQyxNQUFNLG1DQUFtQ0MsbUJBQW1CTCxLQUFLLENBQUMsZ0NBQWdDN0QsU0FBUyxDQUFDLENBQUMsUUFBUUEsU0FBUyxDQUFDLENBQUMsMEJBQTBCO0FBQzVLLFlBQU1tRSxPQUFPLE1BQU1ILElBQUlJLEtBQUs7QUFDNUIsVUFBSUMsVUFBVUYsTUFBTUcsWUFBWTtBQUdoQ0QsZ0JBQVVBLFFBQVFFLE9BQU8sQ0FBQUMsU0FBUTtBQUMvQixjQUFNQyxRQUFRRCxLQUFLRSxjQUFjLENBQUM7QUFDbEMsY0FBTUMsVUFBVUYsTUFBTUUsV0FBVztBQUNqQyxjQUFNQyxjQUFjSCxNQUFNSSxlQUFlO0FBQ3pDLGVBQU9GLFFBQVFHLFlBQVksTUFBTSxXQUFXRixZQUFZRSxZQUFZLE1BQU07QUFBQSxNQUM1RSxDQUFDO0FBR0QsVUFBSVQsUUFBUU4sU0FBUyxHQUFHO0FBQ3RCLFlBQUk7QUFDRixnQkFBTWdCLGVBQWUsTUFBTWQ7QUFBQUEsWUFDekIsZ0RBQWdEQyxtQkFBbUJMLEtBQUssQ0FBQztBQUFBLFlBQ3pFLEVBQUVtQixTQUFTLEVBQUUsY0FBYyw4Q0FBOEMsRUFBRTtBQUFBLFVBQzdFO0FBQ0EsZ0JBQU1DLGdCQUFnQixNQUFNRixhQUFhWCxLQUFLO0FBQzlDLGNBQUljLE1BQU1DLFFBQVFGLGFBQWEsS0FBS0EsY0FBY2xCLFNBQVMsR0FBRztBQUM1RCxrQkFBTXFCLFlBQVlILGNBQWMvRCxJQUFJLENBQUFtRSxVQUFTO0FBQUEsY0FDM0NDLFVBQVU7QUFBQSxnQkFDUkMsYUFBYSxDQUFDQyxXQUFXSCxLQUFLSSxHQUFHLEdBQUdELFdBQVdILEtBQUszRSxHQUFHLENBQUM7QUFBQSxjQUMxRDtBQUFBLGNBQ0FnRSxZQUFZO0FBQUEsZ0JBQ1ZnQixNQUFNTCxLQUFLTSxRQUFRQyxXQUFXUCxLQUFLTSxRQUFRRSxRQUFRUixLQUFLTSxRQUFRRyxZQUFZVCxLQUFLTSxRQUFRSSxnQkFBZ0JWLEtBQUtXLGFBQWFDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxnQkFDdklDLFFBQVFiLEtBQUtNLFFBQVFyRCxRQUFRK0MsS0FBS00sUUFBUVEsVUFBVTtBQUFBLGdCQUNwRHpELE1BQU0yQyxLQUFLTSxRQUFRakQsUUFBUTJDLEtBQUtNLFFBQVFTLFFBQVFmLEtBQUtNLFFBQVFVLFdBQVc7QUFBQSxnQkFDeEVDLE9BQU9qQixLQUFLTSxRQUFRVyxTQUFTO0FBQUEsZ0JBQzdCQyxVQUFVbEIsS0FBS00sUUFBUVksWUFBWTtBQUFBLGdCQUNuQzVCLFNBQVNVLEtBQUtNLFFBQVFoQixXQUFXO0FBQUEsZ0JBQ2pDNkIsVUFBVW5CLEtBQUtNLFFBQVFRLFVBQVVkLEtBQUtNLFFBQVFjLGlCQUFpQjtBQUFBLGNBQ2pFO0FBQUEsWUFDRixFQUFFO0FBR0Ysa0JBQU1DLGVBQWUsSUFBSUMsSUFBSXRDLFFBQVFuRCxJQUFJLENBQUEwRixNQUFLO0FBQzVDLG9CQUFNQyxZQUFZRCxFQUFFbEMsV0FBV2dCLFFBQVEsSUFBSVosWUFBWTtBQUN2RCxvQkFBTWdDLFlBQVlGLEVBQUVsQyxXQUFXaEMsUUFBUSxJQUFJb0MsWUFBWTtBQUN2RCxxQkFBTyxHQUFHK0IsUUFBUSxJQUFJQyxRQUFRO0FBQUEsWUFDaEMsQ0FBQyxDQUFDO0FBRUYsdUJBQVd6QixRQUFRRCxXQUFXO0FBQzVCLG9CQUFNMkIsTUFBTSxJQUFJMUIsS0FBS1gsV0FBV2dCLFFBQVEsSUFBSVosWUFBWSxDQUFDLEtBQUtPLEtBQUtYLFdBQVdoQyxRQUFRLElBQUlvQyxZQUFZLENBQUM7QUFDdkcsa0JBQUksQ0FBQzRCLGFBQWFNLElBQUlELEdBQUcsR0FBRztBQUMxQjFDLHdCQUFRNEMsS0FBSzVCLElBQUk7QUFDakJxQiw2QkFBYVEsSUFBSUgsR0FBRztBQUFBLGNBQ3RCO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFNBQVNJLFFBQVE7QUFDZkMsa0JBQVFDLEtBQUsscUNBQXFDRixNQUFNO0FBQUEsUUFDMUQ7QUFBQSxNQUNGO0FBRUE5RCx1QkFBaUJnQixRQUFRaUQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNyQzdELHNCQUFnQlksUUFBUU4sU0FBUyxDQUFDO0FBQUEsSUFDcEMsU0FBU3dELEtBQUs7QUFDWkgsY0FBUUksTUFBTSxpQkFBaUJELEdBQUc7QUFBQSxJQUNwQyxVQUFDO0FBQ0NoRSxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTWtFLDJCQUEyQkEsQ0FBQ0MsV0FBVztBQUMzQyxVQUFNQyxTQUFTRCxPQUFPcEMsU0FBU0M7QUFDL0IsVUFBTTdFLE1BQU1pSCxPQUFPLENBQUM7QUFDcEIsVUFBTWhILE1BQU1nSCxPQUFPLENBQUM7QUFFcEIsVUFBTUMsU0FBU0YsT0FBT2hELGNBQWMsQ0FBQztBQUdyQyxVQUFNbUQsZUFBZTNFLFlBQVk0RSxNQUFNLFdBQVc7QUFDbEQsVUFBTUMsZUFBZUYsZUFBZUEsYUFBYSxDQUFDLElBQUk7QUFFdEQsVUFBTXRCLFdBQVd3QixnQkFBZ0JILE9BQU9yQixZQUFZO0FBQ3BELFVBQU15QixVQUFVSixPQUFPbEYsUUFBUTtBQUMvQixVQUFNdUYsWUFBWUwsT0FBTzFCLFVBQVU7QUFDbkMsVUFBTWdDLFVBQVVOLE9BQU9wQixZQUFZb0IsT0FBT3pCLFVBQVV5QixPQUFPTyxZQUFZUCxPQUFPbEMsUUFBUTtBQUV0RjFDLHFCQUFpQnpDLFVBQVU7QUFBQSxNQUN6QnFDLFNBQVMyRDtBQUFBQSxNQUNUL0QsTUFBTTBGO0FBQUFBLE1BQ041RixNQUFNMkY7QUFBQUEsTUFDTnZGLE1BQU1zRjtBQUFBQSxJQUNSO0FBR0F6RixZQUFRMEYsU0FBUztBQUNqQnhGLFlBQVF5RixPQUFPO0FBQ2Z2RixZQUFRcUYsT0FBTztBQUNmbkYsZUFBVzBELFFBQVE7QUFHbkJ4RCx5QkFBcUJ4QyxVQUFVO0FBQy9CTixnQkFBWSxDQUFDUyxLQUFLQyxHQUFHLENBQUM7QUFDdEJ5SCwyQkFBdUIxSCxLQUFLQyxHQUFHO0FBRS9COEMsb0JBQWdCLEtBQUs7QUFDckJOLG1CQUFlLEVBQUU7QUFBQSxFQUNuQjtBQUVBMUYsWUFBVSxNQUFNO0FBQ2QsUUFBSStELFVBQVUsQ0FBQ3lCLGlCQUFpQjFDLFNBQVM7QUFDdkMwQyx1QkFBaUIxQyxVQUFVO0FBQzNCOEgsNEJBQXNCO0FBQ3RCbEcsd0JBQWtCLElBQUk7QUFBQSxJQUN4QjtBQUNBLFFBQUksQ0FBQ1gsUUFBUTtBQUNYeUIsdUJBQWlCMUMsVUFBVTtBQUMzQjRCLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsQ0FBQ1gsTUFBTSxDQUFDO0FBRVgvRCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUMrRCxVQUFVeEIsU0FBUyxDQUFDLE1BQU0sV0FBV0EsU0FBUyxDQUFDLE1BQU0sUUFBUztBQUNuRSxRQUFJK0MscUJBQXFCeEMsU0FBUztBQUNoQ3dDLDJCQUFxQnhDLFVBQVU7QUFDL0I7QUFBQSxJQUNGO0FBQ0EsUUFBSXVDLGdCQUFnQnZDLFFBQVMrSCxjQUFheEYsZ0JBQWdCdkMsT0FBTztBQUNqRXVDLG9CQUFnQnZDLFVBQVVnSSxXQUFXLE1BQU07QUFDekNILDZCQUF1QnBJLFNBQVMsQ0FBQyxHQUFHQSxTQUFTLENBQUMsQ0FBQztBQUFBLElBQ2pELEdBQUcsR0FBRztBQUNOLFdBQU8sTUFBTTtBQUNYLFVBQUk4QyxnQkFBZ0J2QyxRQUFTK0gsY0FBYXhGLGdCQUFnQnZDLE9BQU87QUFBQSxJQUNuRTtBQUFBLEVBQ0YsR0FBRyxDQUFDUCxVQUFVd0IsTUFBTSxDQUFDO0FBRXJCLFFBQU02Ryx3QkFBd0IsWUFBWTtBQUN4QyxRQUFJckcsVUFBVztBQUNmQyxpQkFBYSxJQUFJO0FBQ2pCM0QsVUFBTWtLLEtBQUssb0NBQW9DO0FBQy9DLFFBQUk7QUFDRixZQUFNZCxTQUFTLE1BQU03SSxzQkFBc0I7QUFBQSxRQUN6QzRKLFNBQVM7QUFBQSxRQUNUQyxnQkFBZ0I7QUFBQSxRQUNoQkMsWUFBWTtBQUFBLFFBQ1pDLFlBQVk7QUFBQSxNQUNkLENBQUM7QUFDRDdGLDJCQUFxQnhDLFVBQVU7QUFDL0JOLGtCQUFZLENBQUN5SCxPQUFPbUIsVUFBVW5CLE9BQU9vQixTQUFTLENBQUM7QUFDL0NqSCwyQkFBcUI2RixPQUFPL0IsT0FBTztBQUNuQ3RELGlCQUFXcUYsT0FBTy9CLFFBQVFvRCxlQUFlLEVBQUU7QUFDM0N4RyxjQUFRbUYsT0FBTy9CLFFBQVFyRCxRQUFRLEVBQUU7QUFDakNHLGNBQVFpRixPQUFPL0IsUUFBUW5ELFFBQVFrRixPQUFPL0IsUUFBUXdDLFlBQVksRUFBRTtBQUM1RHhGLGNBQVErRSxPQUFPL0IsUUFBUWpELFFBQVEsRUFBRTtBQUNqQ0csaUJBQVc2RSxPQUFPL0IsUUFBUS9DLFdBQVc4RSxPQUFPL0IsUUFBUXFELGNBQWMsRUFBRTtBQUFBLElBQ3RFLFNBQVN6QixLQUFLO0FBQ1pqSixZQUFNa0osTUFBTUQsSUFBSTBCLFdBQVcsa0NBQWtDO0FBQUEsSUFDL0QsVUFBQztBQUNDaEgsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1tRyx5QkFBeUIsT0FBTzFILEtBQUtDLFFBQVE7QUFDakRvQixlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTW9DLE9BQU8sTUFBTTVGLGVBQWVtQyxLQUFLQyxHQUFHO0FBRzFDLFVBQUlxQyxpQkFBaUJ6QyxTQUFTO0FBQzVCLGNBQU0ySSxNQUFNbEcsaUJBQWlCekM7QUFHN0IsY0FBTTRJLGlCQUFpQkQsSUFBSTVHLFFBQVE2QixLQUFLN0IsUUFBUTtBQUNoRCxjQUFNOEcsaUJBQWlCRixJQUFJMUcsUUFBUTJCLEtBQUszQixRQUFRMkIsS0FBS2dFLFlBQVk7QUFDakUsY0FBTWtCLGlCQUFpQkgsSUFBSXhHLFFBQVF5QixLQUFLekIsUUFBUTtBQUdoRCxZQUFJNEcsb0JBQW9CSixJQUFJdEcsV0FBV3VCLEtBQUt2QixXQUFXdUIsS0FBSzZFLGNBQWM7QUFDMUUsWUFBSU0sa0JBQWtCQyxTQUFTLEtBQUssS0FBS0wsSUFBSXRHLFdBQVdzRyxJQUFJdEcsWUFBWSxJQUFJO0FBQzFFMEcsOEJBQW9CSixJQUFJdEc7QUFBQUEsUUFDMUI7QUFFQWYsNkJBQXFCO0FBQUEsVUFDbkIsR0FBR3NDO0FBQUFBLFVBQ0g3QixNQUFNNkc7QUFBQUEsVUFDTjNHLE1BQU00RztBQUFBQSxVQUNOMUcsTUFBTTJHO0FBQUFBLFVBQ056RyxTQUFTMEc7QUFBQUEsVUFDVE4sWUFBWU07QUFBQUEsUUFDZCxDQUFDO0FBRURqSCxtQkFBVzhCLEtBQUs0RSxlQUFlLEVBQUU7QUFDakN4RyxnQkFBUTRHLGNBQWM7QUFDdEIxRyxnQkFBUTJHLGNBQWM7QUFDdEJ6RyxnQkFBUTBHLGNBQWM7QUFDdEJ4RyxtQkFBV3lHLGlCQUFpQjtBQUc1QnRHLHlCQUFpQnpDLFVBQVU7QUFBQSxNQUM3QixPQUFPO0FBRUxzQiw2QkFBcUJzQyxJQUFJO0FBQ3pCOUIsbUJBQVc4QixLQUFLNEUsZUFBZSxFQUFFO0FBQ2pDeEcsZ0JBQVE0QixLQUFLN0IsUUFBUSxFQUFFO0FBQ3ZCRyxnQkFBUTBCLEtBQUszQixRQUFRMkIsS0FBS2dFLFlBQVksRUFBRTtBQUN4Q3hGLGdCQUFRd0IsS0FBS3pCLFFBQVEsRUFBRTtBQUN2QkcsbUJBQVdzQixLQUFLdkIsV0FBV3VCLEtBQUs2RSxjQUFjLEVBQUU7QUFBQSxNQUNsRDtBQUFBLElBQ0YsU0FBU3hCLE9BQU87QUFDZEosY0FBUUksTUFBTSwyQkFBMkJBLEtBQUs7QUFDOUNsSixZQUFNa0osTUFBTSw2Q0FBNkM7QUFBQSxJQUMzRCxVQUFDO0FBQ0N6RixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTXlILGdCQUFnQkEsTUFBTTtBQUMxQixRQUFJLENBQUM1SCxtQkFBbUI7QUFDdEJ0RCxZQUFNa0osTUFBTSw0REFBNEQ7QUFDeEU7QUFBQSxJQUNGO0FBRUEsVUFBTWlDLGlCQUFpQjtBQUFBLE1BQ3JCLEdBQUc3SDtBQUFBQSxNQUNIbUgsYUFBYTNHLFFBQVEwQixLQUFLO0FBQUEsTUFDMUJ4QixNQUFNQSxLQUFLd0IsS0FBSztBQUFBLE1BQ2hCdEIsTUFBTUEsS0FBS3NCLEtBQUs7QUFBQSxNQUNoQnBCLE1BQU1BLEtBQUtvQixLQUFLO0FBQUEsTUFDaEJsQixTQUFTQSxRQUFRa0IsS0FBSztBQUFBLE1BQ3RCa0YsWUFBWXBHLFFBQVFrQixLQUFLO0FBQUEsTUFDekJwRCxLQUFLVixTQUFTLENBQUM7QUFBQSxNQUNmVyxLQUFLWCxTQUFTLENBQUM7QUFBQSxJQUNqQjtBQUVBLFFBQUlvQyxRQUFRMEIsS0FBSyxHQUFHO0FBQ2xCLFlBQU00RixhQUFhRCxlQUFlbkgsUUFBUW1ILGVBQWV2RCxVQUFVO0FBQ25FLFVBQUl3RCxZQUFZO0FBQ2QsWUFBSSxDQUFDQSxXQUFXQyxTQUFTdkgsUUFBUTBCLEtBQUssQ0FBQyxHQUFHO0FBQ3hDMkYseUJBQWV2RCxTQUFTLEdBQUc5RCxRQUFRMEIsS0FBSyxDQUFDLEtBQUs0RixVQUFVO0FBQUEsUUFDMUQsT0FBTztBQUNMRCx5QkFBZXZELFNBQVN3RDtBQUFBQSxRQUMxQjtBQUFBLE1BQ0YsT0FBTztBQUNMRCx1QkFBZXZELFNBQVM5RCxRQUFRMEIsS0FBSztBQUFBLE1BQ3ZDO0FBQ0EyRixxQkFBZUcsY0FBY0gsZUFBZXZEO0FBQUFBLElBQzlDO0FBRUF1RCxtQkFBZUksbUJBQW1CcEwsb0JBQW9CZ0wsY0FBYyxLQUFLN0s7QUFBQUEsTUFDdkU7QUFBQSxRQUNFbUgsY0FBYzNELFFBQVEwQixLQUFLO0FBQUEsUUFDM0J4QixNQUFNbUgsZUFBZW5IO0FBQUFBLFFBQ3JCd0gsYUFBYUwsZUFBZWpIO0FBQUFBLFFBQzVCaUUsZUFBZWdELGVBQWVqSDtBQUFBQSxRQUM5QjJELFFBQVFzRCxlQUFlakg7QUFBQUEsUUFDdkJFLE1BQU0rRyxlQUFlL0c7QUFBQUEsUUFDckI0RCxPQUFPbUQsZUFBZW5EO0FBQUFBLFFBQ3RCQyxVQUFVa0QsZUFBZTdHO0FBQUFBLE1BQzNCO0FBQUEsTUFDQTZHLGVBQWVNLGdCQUFnQk4sZUFBZUk7QUFBQUEsSUFDaEQ7QUFFQSxVQUFNRyxTQUFTO0FBQUEsTUFDYixHQUFHeEwsc0JBQXNCaUwsY0FBYztBQUFBLE1BQ3ZDUSxVQUFVdkc7QUFBQUEsTUFDVndHLGlCQUFpQnZHO0FBQUFBLElBQ25CO0FBQ0FqQyxxQkFBaUJzSSxNQUFNO0FBQ3ZCdkksWUFBUTtBQUFBLEVBQ1Y7QUFHQSxNQUFJLENBQUNELE9BQVEsUUFBTztBQUVwQixRQUFNMkksY0FBY3ZJLG9CQUNoQm5ELG9CQUFvQjtBQUFBLElBQ3BCLEdBQUdtRDtBQUFBQSxJQUNIbUgsYUFBYTNHO0FBQUFBLElBQ2JFO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0FFO0FBQUFBLEVBQ0YsQ0FBQyxLQUFLaEIsa0JBQWtCaUksbUJBQ3RCO0FBRUosU0FBT2xNO0FBQUFBLElBQ0wsdUJBQUMsU0FBSSxXQUFVLDJFQUNiLGlDQUFDLFNBQUksV0FBVSx1R0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxvREFDWjtBQUFBLGlDQUFDLFVBQU8sV0FBVSwwQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0M7QUFBQSxVQUFHO0FBQUEsYUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFNBQVM4RCxTQUFTLFdBQVUsd0RBQ2xDLGlDQUFDLEtBQUUsV0FBVSwyQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPeUI7QUFBQUEsY0FDUCxVQUFVLENBQUNyQyxNQUFNK0MsYUFBYS9DLEVBQUV1SixPQUFPQyxLQUFLO0FBQUEsY0FDNUMsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLcUk7QUFBQSxVQUVySSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2IsaUNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQy9HLGFBQ0MsdUJBQUMsU0FBSSxXQUFVLHFEQUNiLGlDQUFDLFNBQUksV0FBVSx3RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRixLQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFRCxDQUFDQSxhQUFhSixlQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFDYkMsK0JBQWUsRUFBRTtBQUNqQkUsaUNBQWlCLEVBQUU7QUFDbkJJLGdDQUFnQixLQUFLO0FBQUEsY0FDdkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNCO0FBQUE7QUFBQSxZQVR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUdDRCxnQkFBZ0JKLGNBQWNXLFNBQVMsS0FDdEMsdUJBQUMsU0FBSSxXQUFVLGtLQUNaWCx3QkFBY2xDLElBQUksQ0FBQ3dHLFFBQVE0QyxRQUFRO0FBQ2xDLGdCQUFNN0YsUUFBUWlELE9BQU9oRCxjQUFjLENBQUM7QUFDcEMsZ0JBQU1nQixPQUFPakIsTUFBTWlCLFFBQVE7QUFDM0IsZ0JBQU1RLFNBQVN6QixNQUFNeUIsVUFBVTtBQUMvQixnQkFBTXhELFFBQU8rQixNQUFNL0IsUUFBUTtBQUMzQixnQkFBTTRELFFBQVE3QixNQUFNNkIsU0FBUztBQUM3QixnQkFBTUMsV0FBVzlCLE1BQU04QixZQUFZO0FBR25DLGdCQUFNZ0UsWUFBWTdFLFFBQVFRLFVBQVV4RDtBQUNwQyxnQkFBTThILFdBQVc7QUFBQSxZQUNmOUUsT0FBT1EsU0FBUztBQUFBLFlBQ2hCekIsTUFBTStCLFlBQVkvQixNQUFNMEIsVUFBVTtBQUFBLFlBQ2xDekQ7QUFBQUEsWUFDQTREO0FBQUFBLFlBQ0FDO0FBQUFBLFVBQVEsRUFDUmhDLE9BQU9rRyxPQUFPLEVBQUVsRyxPQUFPLENBQUFtRyxNQUFLQSxNQUFNSCxTQUFTLEVBQUVJLEtBQUssSUFBSTtBQUV4RCxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNbEQseUJBQXlCQyxNQUFNO0FBQUEsY0FDOUMsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFPLFdBQVUsMENBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsZ0JBQ3hELHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSxvQ0FBb0M2Qyx1QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEQ7QUFBQSxrQkFDN0RDLFlBQVksdUJBQUMsVUFBSyxXQUFVLG9DQUFvQ0Esc0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZEO0FBQUEscUJBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQTtBQUFBO0FBQUEsWUFUS0Y7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxRQUVKLENBQUMsS0FqQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtDQTtBQUFBLFdBcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLGdCQUFhLFFBQVF0SyxVQUFVLE1BQU0sSUFBSSxPQUFPLEVBQUU0SyxRQUFRLFFBQVFDLE9BQU8sT0FBTyxHQUMvRTtBQUFBLGlDQUFDLGFBQVUsYUFBYWxNLHVCQUF1QixLQUFLRCxtQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxVQUNwRSx1QkFBQyxtQkFBZ0IsVUFBb0IsZUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxVQUM5RCx1QkFBQyxjQUFXLFFBQVFzQixZQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLGFBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBR0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLGVBQWUsQ0FBQ2EsTUFBTUEsRUFBRWlLLGdCQUFnQjtBQUFBLFlBQ3hDLFNBQVMsQ0FBQ2pLLE1BQU07QUFDZEEsZ0JBQUVrSyxlQUFlO0FBQ2pCbEssZ0JBQUVpSyxnQkFBZ0I7QUFDbEJ6QyxvQ0FBc0I7QUFBQSxZQUN4QjtBQUFBLFlBQ0EsVUFBVXJHO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBQ1YsT0FBT0EsWUFBWSwwQkFBMEI7QUFBQSxZQUM3QyxjQUFZQSxZQUFZLCtCQUErQjtBQUFBLFlBRXZELGlDQUFDLGNBQVcsV0FBVyxXQUFXQSxZQUFZLGtCQUFrQixFQUFFLE1BQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUE7QUFBQSxVQWJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBNQUF5TSw4Q0FBeE47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsZ0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsVUFDbEY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9JO0FBQUFBLGNBQ1AsVUFBVSxDQUFDdkIsTUFBTXdCLFdBQVd4QixFQUFFdUosT0FBT0MsS0FBSztBQUFBLGNBQzFDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSzhIO0FBQUEsYUFQaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0tBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMEVBQXlFLDZCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLFlBQ3ZHO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU8vSDtBQUFBQSxnQkFDUCxVQUFVLENBQUN6QixNQUFNMEIsUUFBUTFCLEVBQUV1SixPQUFPQyxLQUFLO0FBQUEsZ0JBQ3ZDLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtnSDtBQUFBLGVBUGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxnS0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSwwRUFBeUUsK0JBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlHO0FBQUEsWUFDekc7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTzdIO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQzNCLE1BQU00QixRQUFRNUIsRUFBRXVKLE9BQU9DLEtBQUs7QUFBQSxnQkFDdkMsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2dIO0FBQUEsZUFQbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdLQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDBFQUF5RSxvQkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxZQUM5RjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPM0g7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDN0IsTUFBTThCLFFBQVE5QixFQUFFdUosT0FBT0MsS0FBSztBQUFBLGdCQUN2QyxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLZ0g7QUFBQSxlQVBsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0tBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMEVBQXlFLHVCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLFlBQ2pHO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU96SDtBQUFBQSxnQkFDUCxVQUFVLENBQUMvQixNQUFNZ0MsV0FBV2hDLEVBQUV1SixPQUFPQyxLQUFLO0FBQUEsZ0JBQzFDLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtnSDtBQUFBLGVBUGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDRDQUEyQyxpQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxPQUFFLFdBQVUsaUhBQ1Z2SSxvQkFDQyx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLG9DQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRSxJQUNoRXFJLGNBQ0ZBLGNBRUEscUNBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU1g7QUFBQUEsWUFDVCxVQUFVMUgsV0FBVyxDQUFDRjtBQUFBQSxZQUN0QixXQUFVO0FBQUEsWUFBb0k7QUFBQTtBQUFBLFVBSGhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdFQTtBQUFBLFNBeExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5TEEsS0ExTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJMQTtBQUFBLElBQ0FvSixTQUFTQztBQUFBQSxFQUNYO0FBQ0Y7QUFBRXRKLElBemZJSixxQkFBbUI7QUFBQSxNQUFuQkE7QUEyZk4sZUFBZUE7QUFBb0IsSUFBQTJKLElBQUFDLEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsImNyZWF0ZVBvcnRhbCIsIk1hcENvbnRhaW5lciIsIlRpbGVMYXllciIsIk1hcmtlciIsIlBvbHlnb24iLCJ1c2VNYXBFdmVudHMiLCJMIiwiWCIsIk1hcFBpbiIsIk5hdmlnYXRpb24iLCJTZWFyY2giLCJ0b2FzdCIsInJldmVyc2VHZW9jb2RlIiwidG9MZWdhY3lBZGRyZXNzRmllbGRzIiwiYnVpbGRBZGRyZXNzUHJldmlldyIsIkxJR0hUX01BUF9USUxFUyIsIkxJR0hUX01BUF9BVFRSSUJVVElPTiIsInNtYXJ0QWRkcmVzc0J1aWxkZXIiLCJkZXRlY3RDdXJyZW50TG9jYXRpb24iLCJjbGVhbkFkZHJlc3NGaWVsZHMiLCJsYXRMbmdUb1MyQ2VsbElkIiwiSWNvbiIsIkRlZmF1bHQiLCJwcm90b3R5cGUiLCJfZ2V0SWNvblVybCIsIm1lcmdlT3B0aW9ucyIsImljb25SZXRpbmFVcmwiLCJpY29uVXJsIiwic2hhZG93VXJsIiwibG9jYXRpb25JY29uIiwiZGl2SWNvbiIsImh0bWwiLCJjbGFzc05hbWUiLCJpY29uU2l6ZSIsImljb25BbmNob3IiLCJwb3B1cEFuY2hvciIsIkRyYWdnYWJsZU1hcmtlciIsInBvc2l0aW9uIiwic2V0UG9zaXRpb24iLCJfcyIsIm1hcmtlclJlZiIsImV2ZW50SGFuZGxlcnMiLCJkcmFnZW5kIiwibWFya2VyIiwiY3VycmVudCIsIm5ld1BvcyIsImdldExhdExuZyIsImxhdCIsImxuZyIsImNsaWNrIiwiZSIsImxhdGxuZyIsIk1hcFVwZGF0ZXIiLCJjZW50ZXIiLCJfczIiLCJtYXAiLCJzZXRWaWV3IiwiTWF0aCIsIm1heCIsImdldFpvb20iLCJMb2NhdGlvblBpY2tlck1vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsIm9uTG9jYXRpb25TZWxlY3QiLCJfczMiLCJzdHJ1Y3R1cmVkQWRkcmVzcyIsInNldFN0cnVjdHVyZWRBZGRyZXNzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJkZXRlY3RpbmciLCJzZXREZXRlY3RpbmciLCJoYXNJbml0aWFsaXplZCIsInNldEhhc0luaXRpYWxpemVkIiwiaG91c2VObyIsInNldEhvdXNlTm8iLCJyb2FkIiwic2V0Um9hZCIsImFyZWEiLCJzZXRBcmVhIiwiY2l0eSIsInNldENpdHkiLCJwaW5jb2RlIiwic2V0UGluY29kZSIsImdlb2NvZGVUaW1lclJlZiIsInNob3VsZFNraXBHZW9jb2RlUmVmIiwic2VhcmNoQ29udGV4dFJlZiIsImRpZEluaXRpYWxpemVSZWYiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5Iiwic2VhcmNoUmVzdWx0cyIsInNldFNlYXJjaFJlc3VsdHMiLCJzZWFyY2hpbmciLCJzZXRTZWFyY2hpbmciLCJzaG93RHJvcGRvd24iLCJzZXRTaG93RHJvcGRvd24iLCJjZWxsSWQxMyIsImNlbGxJZDIwIiwiaGFuZGxlU2VhcmNoIiwicXVlcnkiLCJ0cmltIiwibGVuZ3RoIiwicmVzIiwiZmV0Y2giLCJlbmNvZGVVUklDb21wb25lbnQiLCJkYXRhIiwianNvbiIsInJlc3VsdHMiLCJmZWF0dXJlcyIsImZpbHRlciIsImZlYXQiLCJwcm9wcyIsInByb3BlcnRpZXMiLCJjb3VudHJ5IiwiY291bnRyeUNvZGUiLCJjb3VudHJ5Y29kZSIsInRvTG93ZXJDYXNlIiwibm9tU2VhcmNoUmVzIiwiaGVhZGVycyIsIm5vbVNlYXJjaEpzb24iLCJBcnJheSIsImlzQXJyYXkiLCJtYXBwZWROb20iLCJpdGVtIiwiZ2VvbWV0cnkiLCJjb29yZGluYXRlcyIsInBhcnNlRmxvYXQiLCJsb24iLCJuYW1lIiwiYWRkcmVzcyIsImFtZW5pdHkiLCJzaG9wIiwiYnVpbGRpbmciLCJob3VzZV9udW1iZXIiLCJkaXNwbGF5X25hbWUiLCJzcGxpdCIsInN0cmVldCIsInN1YnVyYiIsInRvd24iLCJ2aWxsYWdlIiwic3RhdGUiLCJwb3N0Y29kZSIsImRpc3RyaWN0IiwibmVpZ2hib3VyaG9vZCIsImV4aXN0aW5nS2V5cyIsIlNldCIsInIiLCJuYW1lUGFydCIsImNpdHlQYXJ0Iiwia2V5IiwiaGFzIiwicHVzaCIsImFkZCIsIm5vbUVyciIsImNvbnNvbGUiLCJ3YXJuIiwic2xpY2UiLCJlcnIiLCJlcnJvciIsImhhbmRsZVNlbGVjdFNlYXJjaFJlc3VsdCIsInJlc3VsdCIsImNvb3JkcyIsInBQcm9wcyIsInBpbmNvZGVNYXRjaCIsIm1hdGNoIiwicXVlcnlQaW5jb2RlIiwiY2l0eVZhbCIsInN0cmVldFZhbCIsImFyZWFWYWwiLCJsb2NhbGl0eSIsImZldGNoQWRkcmVzc0Zyb21Db29yZHMiLCJoYW5kbGVDdXJyZW50TG9jYXRpb24iLCJjbGVhclRpbWVvdXQiLCJzZXRUaW1lb3V0IiwiaW5mbyIsInRpbWVvdXQiLCJ0YXJnZXRBY2N1cmFjeSIsIm1heFVwZGF0ZXMiLCJtYXhSZXRyaWVzIiwibGF0aXR1ZGUiLCJsb25naXR1ZGUiLCJob3VzZU51bWJlciIsInBvc3RhbENvZGUiLCJtZXNzYWdlIiwiY3R4IiwiZmluYWxSb2FkVmFsdWUiLCJmaW5hbEFyZWFWYWx1ZSIsImZpbmFsQ2l0eVZhbHVlIiwiZmluYWxQaW5jb2RlVmFsdWUiLCJlbmRzV2l0aCIsImhhbmRsZUNvbmZpcm0iLCJ1cGRhdGVkQWRkcmVzcyIsInN0cmVldEJhc2UiLCJpbmNsdWRlcyIsImFkZHJlc3NMaW5lIiwiZm9ybWF0dGVkQWRkcmVzcyIsInJlc2lkZW50aWFsIiwiX2Rpc3BsYXlOYW1lIiwibGVnYWN5IiwiczJDZWxsSWQiLCJzMkNlbGxJZFByZWNpc2UiLCJkaXNwbGF5VGV4dCIsInRhcmdldCIsInZhbHVlIiwiaWR4IiwibWFpblRpdGxlIiwic3ViVGl0bGUiLCJCb29sZWFuIiwicyIsImpvaW4iLCJoZWlnaHQiLCJ3aWR0aCIsInN0b3BQcm9wYWdhdGlvbiIsInByZXZlbnREZWZhdWx0IiwiZG9jdW1lbnQiLCJib2R5IiwiX2MiLCJfYzIiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9jYXRpb25QaWNrZXJNb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIH0gZnJvbSAncmVhY3QtZG9tJztcclxuaW1wb3J0IHsgTWFwQ29udGFpbmVyLCBUaWxlTGF5ZXIsIE1hcmtlciwgUG9seWdvbiwgdXNlTWFwRXZlbnRzIH0gZnJvbSAncmVhY3QtbGVhZmxldCc7XHJcbmltcG9ydCBMIGZyb20gJ2xlYWZsZXQnO1xyXG5pbXBvcnQgeyBYLCBNYXBQaW4sIE5hdmlnYXRpb24sIFNlYXJjaCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnLi4vdWkvVG9hc3QnO1xyXG5cclxuaW1wb3J0ICdsZWFmbGV0L2Rpc3QvbGVhZmxldC5jc3MnO1xyXG5pbXBvcnQge1xyXG4gIHJldmVyc2VHZW9jb2RlLFxyXG4gIHRvTGVnYWN5QWRkcmVzc0ZpZWxkcyxcclxuICBidWlsZEFkZHJlc3NQcmV2aWV3LFxyXG4gIExJR0hUX01BUF9USUxFUyxcclxuICBMSUdIVF9NQVBfQVRUUklCVVRJT04sXHJcbiAgc21hcnRBZGRyZXNzQnVpbGRlcixcclxuICBkZXRlY3RDdXJyZW50TG9jYXRpb24sXHJcbiAgY2xlYW5BZGRyZXNzRmllbGRzXHJcbn0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0JztcclxuaW1wb3J0IHsgbGF0TG5nVG9TMkNlbGxJZCB9IGZyb20gJy4uLy4uL3V0aWxzL3MySGVscGVyJztcclxuXHJcblxyXG5kZWxldGUgTC5JY29uLkRlZmF1bHQucHJvdG90eXBlLl9nZXRJY29uVXJsO1xyXG5MLkljb24uRGVmYXVsdC5tZXJnZU9wdGlvbnMoe1xyXG4gIGljb25SZXRpbmFVcmw6ICdodHRwczovL2NkbmpzLmNsb3VkZmxhcmUuY29tL2FqYXgvbGlicy9sZWFmbGV0LzEuNy4xL2ltYWdlcy9tYXJrZXItaWNvbi0yeC5wbmcnLFxyXG4gIGljb25Vcmw6ICdodHRwczovL2NkbmpzLmNsb3VkZmxhcmUuY29tL2FqYXgvbGlicy9sZWFmbGV0LzEuNy4xL2ltYWdlcy9tYXJrZXItaWNvbi5wbmcnLFxyXG4gIHNoYWRvd1VybDogJ2h0dHBzOi8vY2RuanMuY2xvdWRmbGFyZS5jb20vYWpheC9saWJzL2xlYWZsZXQvMS43LjEvaW1hZ2VzL21hcmtlci1zaGFkb3cucG5nJyxcclxufSk7XHJcblxyXG5jb25zdCBsb2NhdGlvbkljb24gPSBMLmRpdkljb24oe1xyXG4gIGh0bWw6IGA8ZGl2IHN0eWxlPVwiYmFja2dyb3VuZC1jb2xvcjogI0VGNDQ0NDsgd2lkdGg6IDI4cHg7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogNTAlIDUwJSA1MCUgMDsgYm9yZGVyOiAzcHggc29saWQgd2hpdGU7IHRyYW5zZm9ybTogcm90YXRlKC00NWRlZyk7IGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsMCwwLDAuMyk7XCI+PC9kaXY+YCxcclxuICBjbGFzc05hbWU6ICcnLFxyXG4gIGljb25TaXplOiBbMjgsIDI4XSxcclxuICBpY29uQW5jaG9yOiBbMTQsIDI4XSxcclxuICBwb3B1cEFuY2hvcjogWzEsIC0zNF1cclxufSk7XHJcblxyXG5jb25zdCBEcmFnZ2FibGVNYXJrZXIgPSAoeyBwb3NpdGlvbiwgc2V0UG9zaXRpb24gfSkgPT4ge1xyXG4gIGNvbnN0IG1hcmtlclJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBldmVudEhhbmRsZXJzID0ge1xyXG4gICAgZHJhZ2VuZCgpIHtcclxuICAgICAgY29uc3QgbWFya2VyID0gbWFya2VyUmVmLmN1cnJlbnQ7XHJcbiAgICAgIGlmIChtYXJrZXIgIT0gbnVsbCkge1xyXG4gICAgICAgIGNvbnN0IG5ld1BvcyA9IG1hcmtlci5nZXRMYXRMbmcoKTtcclxuICAgICAgICBzZXRQb3NpdGlvbihbbmV3UG9zLmxhdCwgbmV3UG9zLmxuZ10pO1xyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gIH07XHJcblxyXG4gIHVzZU1hcEV2ZW50cyh7XHJcbiAgICBjbGljayhlKSB7XHJcbiAgICAgIHNldFBvc2l0aW9uKFtlLmxhdGxuZy5sYXQsIGUubGF0bG5nLmxuZ10pO1xyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNYXJrZXJcclxuICAgICAgZHJhZ2dhYmxlPXt0cnVlfVxyXG4gICAgICBldmVudEhhbmRsZXJzPXtldmVudEhhbmRsZXJzfVxyXG4gICAgICBwb3NpdGlvbj17cG9zaXRpb259XHJcbiAgICAgIHJlZj17bWFya2VyUmVmfVxyXG4gICAgICBpY29uPXtsb2NhdGlvbkljb259XHJcbiAgICAvPlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBNYXBVcGRhdGVyID0gKHsgY2VudGVyIH0pID0+IHtcclxuICBjb25zdCBtYXAgPSB1c2VNYXBFdmVudHMoe30pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBtYXAuc2V0VmlldyhjZW50ZXIsIE1hdGgubWF4KG1hcC5nZXRab29tKCksIDE2KSk7XHJcbiAgfSwgW2NlbnRlciwgbWFwXSk7XHJcbiAgcmV0dXJuIG51bGw7XHJcbn07XHJcblxyXG5jb25zdCBMb2NhdGlvblBpY2tlck1vZGFsID0gKHsgaXNPcGVuLCBvbkNsb3NlLCBvbkxvY2F0aW9uU2VsZWN0IH0pID0+IHtcclxuICBjb25zdCBbcG9zaXRpb24sIHNldFBvc2l0aW9uXSA9IHVzZVN0YXRlKFsyMC41OTM3LCA3OC45NjI5XSk7XHJcbiAgY29uc3QgW3N0cnVjdHVyZWRBZGRyZXNzLCBzZXRTdHJ1Y3R1cmVkQWRkcmVzc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2RldGVjdGluZywgc2V0RGV0ZWN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaGFzSW5pdGlhbGl6ZWQsIHNldEhhc0luaXRpYWxpemVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaG91c2VObywgc2V0SG91c2VOb10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3JvYWQsIHNldFJvYWRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFthcmVhLCBzZXRBcmVhXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbY2l0eSwgc2V0Q2l0eV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3BpbmNvZGUsIHNldFBpbmNvZGVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IGdlb2NvZGVUaW1lclJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBzaG91bGRTa2lwR2VvY29kZVJlZiA9IHVzZVJlZihmYWxzZSk7XHJcbiAgY29uc3Qgc2VhcmNoQ29udGV4dFJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBkaWRJbml0aWFsaXplUmVmID0gdXNlUmVmKGZhbHNlKTtcclxuXHJcbiAgLy8gU3RhdGUgZm9yIEluZGlhLW9ubHkgYWRkcmVzcyBzZWFyY2ggYXV0b2NvbXBsZXRlXHJcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3NlYXJjaFJlc3VsdHMsIHNldFNlYXJjaFJlc3VsdHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hpbmcsIHNldFNlYXJjaGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dEcm9wZG93biwgc2V0U2hvd0Ryb3Bkb3duXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gUzIgQ2VsbCBjYWxjdWxhdGlvbnMgZm9yIHJlYWwtdGltZSB2aXN1YWxpemF0aW9uICYgYmFja2VuZCBzeW5jXHJcbiAgY29uc3QgY2VsbElkMTMgPSBwb3NpdGlvbiA/IGxhdExuZ1RvUzJDZWxsSWQocG9zaXRpb25bMF0sIHBvc2l0aW9uWzFdLCAxMykgOiBudWxsO1xyXG4gIGNvbnN0IGNlbGxJZDIwID0gcG9zaXRpb24gPyBsYXRMbmdUb1MyQ2VsbElkKHBvc2l0aW9uWzBdLCBwb3NpdGlvblsxXSwgMjApIDogbnVsbDtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VhcmNoID0gYXN5bmMgKHF1ZXJ5KSA9PiB7XHJcbiAgICBzZXRTZWFyY2hRdWVyeShxdWVyeSk7XHJcbiAgICBpZiAocXVlcnkudHJpbSgpLmxlbmd0aCA8IDMpIHtcclxuICAgICAgc2V0U2VhcmNoUmVzdWx0cyhbXSk7XHJcbiAgICAgIHNldFNob3dEcm9wZG93bihmYWxzZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldFNlYXJjaGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGBodHRwczovL3Bob3Rvbi5rb21vb3QuaW8vYXBpLz9xPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5KX0mbGltaXQ9MTUmY291bnRyeWNvZGU9aW4mbGF0PSR7cG9zaXRpb25bMF19Jmxvbj0ke3Bvc2l0aW9uWzFdfSZsb2NhdGlvbl9iaWFzX3NjYWxlPTAuNmApO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgbGV0IHJlc3VsdHMgPSBkYXRhPy5mZWF0dXJlcyB8fCBbXTtcclxuXHJcbiAgICAgIC8vIEZpbHRlciBJbmRpYSBzdHJpY3RseSB0byBwcmV2ZW50IGFueSBub2lzZVxyXG4gICAgICByZXN1bHRzID0gcmVzdWx0cy5maWx0ZXIoZmVhdCA9PiB7XHJcbiAgICAgICAgY29uc3QgcHJvcHMgPSBmZWF0LnByb3BlcnRpZXMgfHwge307XHJcbiAgICAgICAgY29uc3QgY291bnRyeSA9IHByb3BzLmNvdW50cnkgfHwgJyc7XHJcbiAgICAgICAgY29uc3QgY291bnRyeUNvZGUgPSBwcm9wcy5jb3VudHJ5Y29kZSB8fCAnJztcclxuICAgICAgICByZXR1cm4gY291bnRyeS50b0xvd2VyQ2FzZSgpID09PSAnaW5kaWEnIHx8IGNvdW50cnlDb2RlLnRvTG93ZXJDYXNlKCkgPT09ICdpbic7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gTm9taW5hdGltIHNlYXJjaCBmYWxsYmFjayBpZiByZXN1bHRzIGFyZSBsb3cgdG8gZ3VhcmFudGVlIFwiR29vZ2xlIE1hcHMtbGlrZVwiIFBPSS9sYW5kbWFyayBsb29rdXBcclxuICAgICAgaWYgKHJlc3VsdHMubGVuZ3RoIDwgNSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBub21TZWFyY2hSZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgYGh0dHBzOi8vbm9taW5hdGltLm9wZW5zdHJlZXRtYXAub3JnL3NlYXJjaD9xPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5KX0mZm9ybWF0PWpzb24mYWRkcmVzc2RldGFpbHM9MSZjb3VudHJ5Y29kZXM9aW4mbGltaXQ9MTAmYWNjZXB0LWxhbmd1YWdlPWVuYCxcclxuICAgICAgICAgICAgeyBoZWFkZXJzOiB7IFwiVXNlci1BZ2VudFwiOiBcIlJhalNlcnZpY2VCb29raW5nLzEuMCAoc2VydmljZS1ib29raW5nLWFwcClcIiB9IH1cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBjb25zdCBub21TZWFyY2hKc29uID0gYXdhaXQgbm9tU2VhcmNoUmVzLmpzb24oKTtcclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG5vbVNlYXJjaEpzb24pICYmIG5vbVNlYXJjaEpzb24ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBjb25zdCBtYXBwZWROb20gPSBub21TZWFyY2hKc29uLm1hcChpdGVtID0+ICh7XHJcbiAgICAgICAgICAgICAgZ2VvbWV0cnk6IHtcclxuICAgICAgICAgICAgICAgIGNvb3JkaW5hdGVzOiBbcGFyc2VGbG9hdChpdGVtLmxvbiksIHBhcnNlRmxvYXQoaXRlbS5sYXQpXVxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgcHJvcGVydGllczoge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogaXRlbS5hZGRyZXNzLmFtZW5pdHkgfHwgaXRlbS5hZGRyZXNzLnNob3AgfHwgaXRlbS5hZGRyZXNzLmJ1aWxkaW5nIHx8IGl0ZW0uYWRkcmVzcy5ob3VzZV9udW1iZXIgfHwgaXRlbS5kaXNwbGF5X25hbWUuc3BsaXQoXCIsXCIpWzBdLFxyXG4gICAgICAgICAgICAgICAgc3RyZWV0OiBpdGVtLmFkZHJlc3Mucm9hZCB8fCBpdGVtLmFkZHJlc3Muc3VidXJiIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBjaXR5OiBpdGVtLmFkZHJlc3MuY2l0eSB8fCBpdGVtLmFkZHJlc3MudG93biB8fCBpdGVtLmFkZHJlc3MudmlsbGFnZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgc3RhdGU6IGl0ZW0uYWRkcmVzcy5zdGF0ZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgcG9zdGNvZGU6IGl0ZW0uYWRkcmVzcy5wb3N0Y29kZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgY291bnRyeTogaXRlbS5hZGRyZXNzLmNvdW50cnkgfHwgXCJJbmRpYVwiLFxyXG4gICAgICAgICAgICAgICAgZGlzdHJpY3Q6IGl0ZW0uYWRkcmVzcy5zdWJ1cmIgfHwgaXRlbS5hZGRyZXNzLm5laWdoYm91cmhvb2QgfHwgXCJcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgLy8gRGVkdXBsaWNhdGUgYWdhaW5zdCBleGlzdGluZyByZXN1bHRzXHJcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nS2V5cyA9IG5ldyBTZXQocmVzdWx0cy5tYXAociA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgbmFtZVBhcnQgPSAoci5wcm9wZXJ0aWVzLm5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgICAgY29uc3QgY2l0eVBhcnQgPSAoci5wcm9wZXJ0aWVzLmNpdHkgfHwgJycpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIGAke25hbWVQYXJ0fXwke2NpdHlQYXJ0fWA7XHJcbiAgICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBtYXBwZWROb20pIHtcclxuICAgICAgICAgICAgICBjb25zdCBrZXkgPSBgJHsoaXRlbS5wcm9wZXJ0aWVzLm5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCl9fCR7KGl0ZW0ucHJvcGVydGllcy5jaXR5IHx8ICcnKS50b0xvd2VyQ2FzZSgpfWA7XHJcbiAgICAgICAgICAgICAgaWYgKCFleGlzdGluZ0tleXMuaGFzKGtleSkpIHtcclxuICAgICAgICAgICAgICAgIHJlc3VsdHMucHVzaChpdGVtKTtcclxuICAgICAgICAgICAgICAgIGV4aXN0aW5nS2V5cy5hZGQoa2V5KTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChub21FcnIpIHtcclxuICAgICAgICAgIGNvbnNvbGUud2FybihcIk5vbWluYXRpbSBzZWFyY2ggZmFsbGJhY2sgZmFpbGVkOlwiLCBub21FcnIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0U2VhcmNoUmVzdWx0cyhyZXN1bHRzLnNsaWNlKDAsIDE1KSk7XHJcbiAgICAgIHNldFNob3dEcm9wZG93bihyZXN1bHRzLmxlbmd0aCA+IDApO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlYXJjaCBlcnJvcjonLCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2VhcmNoaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RTZWFyY2hSZXN1bHQgPSAocmVzdWx0KSA9PiB7XHJcbiAgICBjb25zdCBjb29yZHMgPSByZXN1bHQuZ2VvbWV0cnkuY29vcmRpbmF0ZXM7IC8vIFtsbmcsIGxhdF1cclxuICAgIGNvbnN0IGxhdCA9IGNvb3Jkc1sxXTtcclxuICAgIGNvbnN0IGxuZyA9IGNvb3Jkc1swXTtcclxuXHJcbiAgICBjb25zdCBwUHJvcHMgPSByZXN1bHQucHJvcGVydGllcyB8fCB7fTtcclxuXHJcbiAgICAvLyBFeHRyYWN0IGFueSA2LWRpZ2l0IHBpbmNvZGUgZXhwbGljaXRseSB0eXBlZCBieSB0aGUgdXNlciBpbiB0aGUgc2VhcmNoIHF1ZXJ5XHJcbiAgICBjb25zdCBwaW5jb2RlTWF0Y2ggPSBzZWFyY2hRdWVyeS5tYXRjaCgvXFxiXFxkezZ9XFxiLyk7XHJcbiAgICBjb25zdCBxdWVyeVBpbmNvZGUgPSBwaW5jb2RlTWF0Y2ggPyBwaW5jb2RlTWF0Y2hbMF0gOiBudWxsO1xyXG5cclxuICAgIGNvbnN0IHBvc3Rjb2RlID0gcXVlcnlQaW5jb2RlIHx8IHBQcm9wcy5wb3N0Y29kZSB8fCBcIlwiO1xyXG4gICAgY29uc3QgY2l0eVZhbCA9IHBQcm9wcy5jaXR5IHx8IFwiXCI7XHJcbiAgICBjb25zdCBzdHJlZXRWYWwgPSBwUHJvcHMuc3RyZWV0IHx8IFwiXCI7XHJcbiAgICBjb25zdCBhcmVhVmFsID0gcFByb3BzLmRpc3RyaWN0IHx8IHBQcm9wcy5zdWJ1cmIgfHwgcFByb3BzLmxvY2FsaXR5IHx8IHBQcm9wcy5uYW1lIHx8IFwiXCI7XHJcblxyXG4gICAgc2VhcmNoQ29udGV4dFJlZi5jdXJyZW50ID0ge1xyXG4gICAgICBwaW5jb2RlOiBwb3N0Y29kZSxcclxuICAgICAgYXJlYTogYXJlYVZhbCxcclxuICAgICAgcm9hZDogc3RyZWV0VmFsLFxyXG4gICAgICBjaXR5OiBjaXR5VmFsXHJcbiAgICB9O1xyXG5cclxuICAgIC8vIFBvcHVsYXRlIGVkaXRhYmxlIHN0YXRlcyBpbW1lZGlhdGVseSB0byBhdm9pZCBVSSBmbGlja2VyXHJcbiAgICBzZXRSb2FkKHN0cmVldFZhbCk7XHJcbiAgICBzZXRBcmVhKGFyZWFWYWwpO1xyXG4gICAgc2V0Q2l0eShjaXR5VmFsKTtcclxuICAgIHNldFBpbmNvZGUocG9zdGNvZGUpO1xyXG5cclxuICAgIC8vIFNldCBwb3NpdGlvbiBhbmQgdHJpZ2dlciBhIGhpZ2gtcHJlY2lzaW9uIGdlb2NvZGUgaW1tZWRpYXRlbHkgZm9yIHRoZSBleGFjdCBjb29yZGluYXRlc1xyXG4gICAgc2hvdWxkU2tpcEdlb2NvZGVSZWYuY3VycmVudCA9IHRydWU7IC8vIFRlbGwgcG9zaXRpb24gdXNlRWZmZWN0IHRvIHNraXAgcmVkdW5kYW50IGdlb2NvZGluZ1xyXG4gICAgc2V0UG9zaXRpb24oW2xhdCwgbG5nXSk7XHJcbiAgICBmZXRjaEFkZHJlc3NGcm9tQ29vcmRzKGxhdCwgbG5nKTtcclxuXHJcbiAgICBzZXRTaG93RHJvcGRvd24oZmFsc2UpO1xyXG4gICAgc2V0U2VhcmNoUXVlcnkoJycpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNPcGVuICYmICFkaWRJbml0aWFsaXplUmVmLmN1cnJlbnQpIHtcclxuICAgICAgZGlkSW5pdGlhbGl6ZVJlZi5jdXJyZW50ID0gdHJ1ZTtcclxuICAgICAgaGFuZGxlQ3VycmVudExvY2F0aW9uKCk7XHJcbiAgICAgIHNldEhhc0luaXRpYWxpemVkKHRydWUpO1xyXG4gICAgfVxyXG4gICAgaWYgKCFpc09wZW4pIHtcclxuICAgICAgZGlkSW5pdGlhbGl6ZVJlZi5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIHNldEhhc0luaXRpYWxpemVkKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbaXNPcGVuXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIWlzT3BlbiB8fCBwb3NpdGlvblswXSA9PT0gMjAuNTkzNyAmJiBwb3NpdGlvblsxXSA9PT0gNzguOTYyOSkgcmV0dXJuO1xyXG4gICAgaWYgKHNob3VsZFNraXBHZW9jb2RlUmVmLmN1cnJlbnQpIHtcclxuICAgICAgc2hvdWxkU2tpcEdlb2NvZGVSZWYuY3VycmVudCA9IGZhbHNlO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoZ2VvY29kZVRpbWVyUmVmLmN1cnJlbnQpIGNsZWFyVGltZW91dChnZW9jb2RlVGltZXJSZWYuY3VycmVudCk7XHJcbiAgICBnZW9jb2RlVGltZXJSZWYuY3VycmVudCA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBmZXRjaEFkZHJlc3NGcm9tQ29vcmRzKHBvc2l0aW9uWzBdLCBwb3NpdGlvblsxXSk7XHJcbiAgICB9LCA3MDApO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgaWYgKGdlb2NvZGVUaW1lclJlZi5jdXJyZW50KSBjbGVhclRpbWVvdXQoZ2VvY29kZVRpbWVyUmVmLmN1cnJlbnQpO1xyXG4gICAgfTtcclxuICB9LCBbcG9zaXRpb24sIGlzT3Blbl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXJyZW50TG9jYXRpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoZGV0ZWN0aW5nKSByZXR1cm47XHJcbiAgICBzZXREZXRlY3RpbmcodHJ1ZSk7XHJcbiAgICB0b2FzdC5pbmZvKCdEZXRlY3RpbmcgeW91ciBjdXJyZW50IGxvY2F0aW9uLi4uJyk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZXRlY3RDdXJyZW50TG9jYXRpb24oe1xyXG4gICAgICAgIHRpbWVvdXQ6IDQwMDAsXHJcbiAgICAgICAgdGFyZ2V0QWNjdXJhY3k6IDE1MCxcclxuICAgICAgICBtYXhVcGRhdGVzOiAxLFxyXG4gICAgICAgIG1heFJldHJpZXM6IDBcclxuICAgICAgfSk7XHJcbiAgICAgIHNob3VsZFNraXBHZW9jb2RlUmVmLmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgICBzZXRQb3NpdGlvbihbcmVzdWx0LmxhdGl0dWRlLCByZXN1bHQubG9uZ2l0dWRlXSk7XHJcbiAgICAgIHNldFN0cnVjdHVyZWRBZGRyZXNzKHJlc3VsdC5hZGRyZXNzKTtcclxuICAgICAgc2V0SG91c2VObyhyZXN1bHQuYWRkcmVzcy5ob3VzZU51bWJlciB8fCAnJyk7XHJcbiAgICAgIHNldFJvYWQocmVzdWx0LmFkZHJlc3Mucm9hZCB8fCAnJyk7XHJcbiAgICAgIHNldEFyZWEocmVzdWx0LmFkZHJlc3MuYXJlYSB8fCByZXN1bHQuYWRkcmVzcy5sb2NhbGl0eSB8fCAnJyk7XHJcbiAgICAgIHNldENpdHkocmVzdWx0LmFkZHJlc3MuY2l0eSB8fCAnJyk7XHJcbiAgICAgIHNldFBpbmNvZGUocmVzdWx0LmFkZHJlc3MucGluY29kZSB8fCByZXN1bHQuYWRkcmVzcy5wb3N0YWxDb2RlIHx8ICcnKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICB0b2FzdC5lcnJvcihlcnIubWVzc2FnZSB8fCAnQ291bGQgbm90IGZldGNoIGN1cnJlbnQgbG9jYXRpb24nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldERldGVjdGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBZGRyZXNzRnJvbUNvb3JkcyA9IGFzeW5jIChsYXQsIGxuZykgPT4ge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXZlcnNlR2VvY29kZShsYXQsIGxuZyk7XHJcblxyXG4gICAgICAvLyBNZXJnZSB3aXRoIHNlYXJjaCByZXN1bHQgY29udGV4dCBpZiBhdmFpbGFibGUgdG8gcHJlc2VydmUgdXNlciBxdWVyeSdzIHBpbmNvZGUgYW5kIHN1Yi1sb2NhbGl0eVxyXG4gICAgICBpZiAoc2VhcmNoQ29udGV4dFJlZi5jdXJyZW50KSB7XHJcbiAgICAgICAgY29uc3QgY3R4ID0gc2VhcmNoQ29udGV4dFJlZi5jdXJyZW50O1xyXG5cclxuICAgICAgICAvLyBQcmVzZXJ2ZSBzZWFyY2ggc3VnZ2VzdGlvbiB2YWx1ZXMsIG9ubHkgZmFsbGJhY2sgdG8gZ2VvY29kZWQgb25lcyBpZiBzdWdnZXN0aW9uIGhhZCB0aGVtIGVtcHR5XHJcbiAgICAgICAgY29uc3QgZmluYWxSb2FkVmFsdWUgPSBjdHgucm9hZCB8fCBkYXRhLnJvYWQgfHwgJyc7XHJcbiAgICAgICAgY29uc3QgZmluYWxBcmVhVmFsdWUgPSBjdHguYXJlYSB8fCBkYXRhLmFyZWEgfHwgZGF0YS5sb2NhbGl0eSB8fCAnJztcclxuICAgICAgICBjb25zdCBmaW5hbENpdHlWYWx1ZSA9IGN0eC5jaXR5IHx8IGRhdGEuY2l0eSB8fCAnJztcclxuXHJcbiAgICAgICAgLy8gUmVzb2x2ZSBwaW5jb2RlIHdpdGggc3BlY2lmaWMgZmFsbGJhY2tcclxuICAgICAgICBsZXQgZmluYWxQaW5jb2RlVmFsdWUgPSBjdHgucGluY29kZSB8fCBkYXRhLnBpbmNvZGUgfHwgZGF0YS5wb3N0YWxDb2RlIHx8ICcnO1xyXG4gICAgICAgIGlmIChmaW5hbFBpbmNvZGVWYWx1ZS5lbmRzV2l0aChcIjAwMVwiKSAmJiBjdHgucGluY29kZSAmJiBjdHgucGluY29kZSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgZmluYWxQaW5jb2RlVmFsdWUgPSBjdHgucGluY29kZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldFN0cnVjdHVyZWRBZGRyZXNzKHtcclxuICAgICAgICAgIC4uLmRhdGEsXHJcbiAgICAgICAgICByb2FkOiBmaW5hbFJvYWRWYWx1ZSxcclxuICAgICAgICAgIGFyZWE6IGZpbmFsQXJlYVZhbHVlLFxyXG4gICAgICAgICAgY2l0eTogZmluYWxDaXR5VmFsdWUsXHJcbiAgICAgICAgICBwaW5jb2RlOiBmaW5hbFBpbmNvZGVWYWx1ZSxcclxuICAgICAgICAgIHBvc3RhbENvZGU6IGZpbmFsUGluY29kZVZhbHVlXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldEhvdXNlTm8oZGF0YS5ob3VzZU51bWJlciB8fCAnJyk7XHJcbiAgICAgICAgc2V0Um9hZChmaW5hbFJvYWRWYWx1ZSk7XHJcbiAgICAgICAgc2V0QXJlYShmaW5hbEFyZWFWYWx1ZSk7XHJcbiAgICAgICAgc2V0Q2l0eShmaW5hbENpdHlWYWx1ZSk7XHJcbiAgICAgICAgc2V0UGluY29kZShmaW5hbFBpbmNvZGVWYWx1ZSk7XHJcblxyXG4gICAgICAgIC8vIFJlc2V0IGNvbnRleHRcclxuICAgICAgICBzZWFyY2hDb250ZXh0UmVmLmN1cnJlbnQgPSBudWxsO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIFN0YW5kYXJkIHBpbiBkcmFnIGdlb2NvZGU6IG92ZXJ3cml0ZSBldmVyeXRoaW5nIHdpdGggZnJlc2ggY29vcmRpbmF0ZXMgZGF0YVxyXG4gICAgICAgIHNldFN0cnVjdHVyZWRBZGRyZXNzKGRhdGEpO1xyXG4gICAgICAgIHNldEhvdXNlTm8oZGF0YS5ob3VzZU51bWJlciB8fCAnJyk7XHJcbiAgICAgICAgc2V0Um9hZChkYXRhLnJvYWQgfHwgJycpO1xyXG4gICAgICAgIHNldEFyZWEoZGF0YS5hcmVhIHx8IGRhdGEubG9jYWxpdHkgfHwgJycpO1xyXG4gICAgICAgIHNldENpdHkoZGF0YS5jaXR5IHx8ICcnKTtcclxuICAgICAgICBzZXRQaW5jb2RlKGRhdGEucGluY29kZSB8fCBkYXRhLnBvc3RhbENvZGUgfHwgJycpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyBhZGRyZXNzOicsIGVycm9yKTtcclxuICAgICAgdG9hc3QuZXJyb3IoJ0NvdWxkIG5vdCByZXNvbHZlIGFkZHJlc3MgZm9yIHRoaXMgbG9jYXRpb24nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm0gPSAoKSA9PiB7XHJcbiAgICBpZiAoIXN0cnVjdHVyZWRBZGRyZXNzKSB7XHJcbiAgICAgIHRvYXN0LmVycm9yKCdQbGVhc2Ugd2FpdCBmb3IgYWRkcmVzcyB0byBsb2FkIG9yIHNlbGVjdCBhIHZhbGlkIGxvY2F0aW9uJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB1cGRhdGVkQWRkcmVzcyA9IHtcclxuICAgICAgLi4uc3RydWN0dXJlZEFkZHJlc3MsXHJcbiAgICAgIGhvdXNlTnVtYmVyOiBob3VzZU5vLnRyaW0oKSxcclxuICAgICAgcm9hZDogcm9hZC50cmltKCksXHJcbiAgICAgIGFyZWE6IGFyZWEudHJpbSgpLFxyXG4gICAgICBjaXR5OiBjaXR5LnRyaW0oKSxcclxuICAgICAgcGluY29kZTogcGluY29kZS50cmltKCksXHJcbiAgICAgIHBvc3RhbENvZGU6IHBpbmNvZGUudHJpbSgpLFxyXG4gICAgICBsYXQ6IHBvc2l0aW9uWzBdLFxyXG4gICAgICBsbmc6IHBvc2l0aW9uWzFdXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChob3VzZU5vLnRyaW0oKSkge1xyXG4gICAgICBjb25zdCBzdHJlZXRCYXNlID0gdXBkYXRlZEFkZHJlc3Mucm9hZCB8fCB1cGRhdGVkQWRkcmVzcy5zdHJlZXQgfHwgJyc7XHJcbiAgICAgIGlmIChzdHJlZXRCYXNlKSB7XHJcbiAgICAgICAgaWYgKCFzdHJlZXRCYXNlLmluY2x1ZGVzKGhvdXNlTm8udHJpbSgpKSkge1xyXG4gICAgICAgICAgdXBkYXRlZEFkZHJlc3Muc3RyZWV0ID0gYCR7aG91c2VOby50cmltKCl9LCAke3N0cmVldEJhc2V9YDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdXBkYXRlZEFkZHJlc3Muc3RyZWV0ID0gc3RyZWV0QmFzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdXBkYXRlZEFkZHJlc3Muc3RyZWV0ID0gaG91c2VOby50cmltKCk7XHJcbiAgICAgIH1cclxuICAgICAgdXBkYXRlZEFkZHJlc3MuYWRkcmVzc0xpbmUgPSB1cGRhdGVkQWRkcmVzcy5zdHJlZXQ7XHJcbiAgICB9XHJcblxyXG4gICAgdXBkYXRlZEFkZHJlc3MuZm9ybWF0dGVkQWRkcmVzcyA9IGJ1aWxkQWRkcmVzc1ByZXZpZXcodXBkYXRlZEFkZHJlc3MpIHx8IHNtYXJ0QWRkcmVzc0J1aWxkZXIoXHJcbiAgICAgIHtcclxuICAgICAgICBob3VzZV9udW1iZXI6IGhvdXNlTm8udHJpbSgpLFxyXG4gICAgICAgIHJvYWQ6IHVwZGF0ZWRBZGRyZXNzLnJvYWQsXHJcbiAgICAgICAgcmVzaWRlbnRpYWw6IHVwZGF0ZWRBZGRyZXNzLmFyZWEsXHJcbiAgICAgICAgbmVpZ2hib3VyaG9vZDogdXBkYXRlZEFkZHJlc3MuYXJlYSxcclxuICAgICAgICBzdWJ1cmI6IHVwZGF0ZWRBZGRyZXNzLmFyZWEsXHJcbiAgICAgICAgY2l0eTogdXBkYXRlZEFkZHJlc3MuY2l0eSxcclxuICAgICAgICBzdGF0ZTogdXBkYXRlZEFkZHJlc3Muc3RhdGUsXHJcbiAgICAgICAgcG9zdGNvZGU6IHVwZGF0ZWRBZGRyZXNzLnBpbmNvZGVcclxuICAgICAgfSxcclxuICAgICAgdXBkYXRlZEFkZHJlc3MuX2Rpc3BsYXlOYW1lIHx8IHVwZGF0ZWRBZGRyZXNzLmZvcm1hdHRlZEFkZHJlc3NcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgbGVnYWN5ID0ge1xyXG4gICAgICAuLi50b0xlZ2FjeUFkZHJlc3NGaWVsZHModXBkYXRlZEFkZHJlc3MpLFxyXG4gICAgICBzMkNlbGxJZDogY2VsbElkMTMsXHJcbiAgICAgIHMyQ2VsbElkUHJlY2lzZTogY2VsbElkMjBcclxuICAgIH07XHJcbiAgICBvbkxvY2F0aW9uU2VsZWN0KGxlZ2FjeSk7XHJcbiAgICBvbkNsb3NlKCk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3QgZGlzcGxheVRleHQgPSBzdHJ1Y3R1cmVkQWRkcmVzc1xyXG4gICAgPyBidWlsZEFkZHJlc3NQcmV2aWV3KHtcclxuICAgICAgLi4uc3RydWN0dXJlZEFkZHJlc3MsXHJcbiAgICAgIGhvdXNlTnVtYmVyOiBob3VzZU5vLFxyXG4gICAgICByb2FkOiByb2FkLFxyXG4gICAgICBhcmVhOiBhcmVhLFxyXG4gICAgICBjaXR5OiBjaXR5LFxyXG4gICAgICBwaW5jb2RlOiBwaW5jb2RlXHJcbiAgICB9KSB8fCBzdHJ1Y3R1cmVkQWRkcmVzcy5mb3JtYXR0ZWRBZGRyZXNzXHJcbiAgICA6ICcnO1xyXG5cclxuICByZXR1cm4gY3JlYXRlUG9ydGFsKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzUwIHAtNFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXhsIHctZnVsbCBtYXgtdy0yeGwgb3ZlcmZsb3ctaGlkZGVuIGZsZXggZmxleC1jb2wgaC1bOTB2aF0gbWF4LWgtWzc4MHB4XVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNCBib3JkZXItYiBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnkgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcHJpbWFyeVwiIC8+IFNlbGVjdCBZb3VyIExvY2F0aW9uXHJcbiAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsb3NlfSBjbGFzc05hbWU9XCJwLTEgaG92ZXI6YmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEluZGlhLU9ubHkgQWRkcmVzcyBTZWFyY2ggQXV0b2NvbXBsZXRlIElucHV0ICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBiZy13aGl0ZSB6LVsxMDA1XVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBhZGRyZXNzIGluIEluZGlhLi4uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTAgcHItMTAgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeS8yMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zIGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7c2VhcmNoaW5nICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC0wIHByLTMgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIHJvdW5kZWQtZnVsbCBoLTQgdy00IGJvcmRlci0yIGJvcmRlci1wcmltYXJ5IGJvcmRlci10LXRyYW5zcGFyZW50XCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHshc2VhcmNoaW5nICYmIHNlYXJjaFF1ZXJ5ICYmIChcclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2VhcmNoUXVlcnkoJycpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRTZWFyY2hSZXN1bHRzKFtdKTtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd0Ryb3Bkb3duKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBwci0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMCBib3JkZXItbm9uZSBiZy10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU2VhcmNoIERyb3Bkb3duIE92ZXJsYXkgKi99XHJcbiAgICAgICAgICB7c2hvd0Ryb3Bkb3duICYmIHNlYXJjaFJlc3VsdHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLWZ1bGwgbGVmdC0wIHJpZ2h0LTAgbXQtMSBteC0zIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3cteGwgbWF4LWgtWzIyMHB4XSBvdmVyZmxvdy15LWF1dG8gei1bMTAxMF0gZGl2aWRlLXkgZGl2aWRlLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICB7c2VhcmNoUmVzdWx0cy5tYXAoKHJlc3VsdCwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwcm9wcyA9IHJlc3VsdC5wcm9wZXJ0aWVzIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbmFtZSA9IHByb3BzLm5hbWUgfHwgJyc7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBzdHJlZXQgPSBwcm9wcy5zdHJlZXQgfHwgJyc7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBjaXR5ID0gcHJvcHMuY2l0eSB8fCAnJztcclxuICAgICAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gcHJvcHMuc3RhdGUgfHwgJyc7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwb3N0Y29kZSA9IHByb3BzLnBvc3Rjb2RlIHx8ICcnO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIENvbnN0cnVjdCBhIGJlYXV0aWZ1bCBzcGxpdCBhZGRyZXNzIGZvcm1hdFxyXG4gICAgICAgICAgICAgICAgY29uc3QgbWFpblRpdGxlID0gbmFtZSB8fCBzdHJlZXQgfHwgY2l0eTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHN1YlRpdGxlID0gW1xyXG4gICAgICAgICAgICAgICAgICBuYW1lID8gc3RyZWV0IDogJycsXHJcbiAgICAgICAgICAgICAgICAgIHByb3BzLmRpc3RyaWN0IHx8IHByb3BzLnN1YnVyYiB8fCAnJyxcclxuICAgICAgICAgICAgICAgICAgY2l0eSxcclxuICAgICAgICAgICAgICAgICAgc3RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHBvc3Rjb2RlXHJcbiAgICAgICAgICAgICAgICBdLmZpbHRlcihCb29sZWFuKS5maWx0ZXIocyA9PiBzICE9PSBtYWluVGl0bGUpLmpvaW4oJywgJyk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdFNlYXJjaFJlc3VsdChyZXN1bHQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgcHgtNCBweS0yLjUgaG92ZXI6YmctZ3JheS01MCB0ZXh0LXhzIHRleHQtc2Vjb25kYXJ5IHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNSBib3JkZXItbm9uZSBiZy10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wcmltYXJ5IHNocmluay0wIG10LTAuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnkgdGV4dC14c1wiPnttYWluVGl0bGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3N1YlRpdGxlICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1bMTBweF0gbXQtMC41XCI+e3N1YlRpdGxlfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSByZWxhdGl2ZSBiZy1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgPE1hcENvbnRhaW5lciBjZW50ZXI9e3Bvc2l0aW9ufSB6b29tPXsxNn0gc3R5bGU9e3sgaGVpZ2h0OiAnMTAwJScsIHdpZHRoOiAnMTAwJScgfX0+XHJcbiAgICAgICAgICAgIDxUaWxlTGF5ZXIgYXR0cmlidXRpb249e0xJR0hUX01BUF9BVFRSSUJVVElPTn0gdXJsPXtMSUdIVF9NQVBfVElMRVN9IC8+XHJcbiAgICAgICAgICAgIDxEcmFnZ2FibGVNYXJrZXIgcG9zaXRpb249e3Bvc2l0aW9ufSBzZXRQb3NpdGlvbj17c2V0UG9zaXRpb259IC8+XHJcbiAgICAgICAgICAgIDxNYXBVcGRhdGVyIGNlbnRlcj17cG9zaXRpb259IC8+XHJcbiAgICAgICAgICA8L01hcENvbnRhaW5lcj5cclxuXHJcblxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25Qb2ludGVyRG93bj17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgaGFuZGxlQ3VycmVudExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkZXRlY3Rpbmd9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS00IHJpZ2h0LTQgei1bMTAwMF0gYmctcmVkLTUwMCBob3ZlcjpiZy1yZWQtNjAwIHRleHQtd2hpdGUgcC0zIHJvdW5kZWQtZnVsbCBzaGFkb3ctbGcgc2hhZG93LXJlZC01MDAvMjAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIGJvcmRlci1ub25lIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGRpc2FibGVkOm9wYWNpdHktNzAgZGlzYWJsZWQ6Y3Vyc29yLXdhaXRcIlxyXG4gICAgICAgICAgICB0aXRsZT17ZGV0ZWN0aW5nID8gJ0RldGVjdGluZyBsb2NhdGlvbi4uLicgOiAnTXkgTG9jYXRpb24nfVxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtkZXRlY3RpbmcgPyAnRGV0ZWN0aW5nIGN1cnJlbnQgbG9jYXRpb24nIDogJ0RldGVjdCBjdXJyZW50IGxvY2F0aW9uJ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPE5hdmlnYXRpb24gY2xhc3NOYW1lPXtgdy01IGgtNSAke2RldGVjdGluZyA/ICdhbmltYXRlLXB1bHNlJyA6ICcnfWB9IC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgei1bNDAwXSBiZy13aGl0ZS85MCBiYWNrZHJvcC1ibHVyLXNtIHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgc2hhZG93LW1kIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcG9pbnRlci1ldmVudHMtbm9uZSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICBEcmFnIHRoZSBwaW4gb3IgdGFwIG9uIHRoZSBtYXBcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgYmctd2hpdGUgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgbWItMVwiPkhvdXNlIC8gRmxhdCBOby48L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2hvdXNlTm99XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRIb3VzZU5vKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gMzQ5LCBGbGF0IDRCXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yIHRleHQteHNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHAtMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZm9jdXMtd2l0aGluOmJvcmRlci1wcmltYXJ5LzQwIGZvY3VzLXdpdGhpbjpyaW5nLTIgZm9jdXMtd2l0aGluOnJpbmctcHJpbWFyeS8xMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBmb250LXNlbWlib2xkIGJsb2NrIHRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlJvYWQgLyBTdHJlZXQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3JvYWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvYWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFN0cmVldCAxLCBNYWluIFJvYWRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGJvcmRlci1ub25lIHAtMCBtdC0wLjVcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBmb2N1cy13aXRoaW46Ym9yZGVyLXByaW1hcnkvNDAgZm9jdXMtd2l0aGluOnJpbmctMiBmb2N1cy13aXRoaW46cmluZy1wcmltYXJ5LzEwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+QXJlYSAvIExvY2FsaXR5PC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXthcmVhfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBcmVhKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBVcmJhbiBFc3RhdGUgUGhhc2UgMlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgYm9yZGVyLW5vbmUgcC0wIG10LTAuNVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGZvY3VzLXdpdGhpbjpib3JkZXItcHJpbWFyeS80MCBmb2N1cy13aXRoaW46cmluZy0yIGZvY3VzLXdpdGhpbjpyaW5nLXByaW1hcnkvMTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgZm9udC1zZW1pYm9sZCBibG9jayB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5DaXR5PC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjaXR5fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDaXR5KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBNb2hhbGlcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGJvcmRlci1ub25lIHAtMCBtdC0wLjVcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBmb2N1cy13aXRoaW46Ym9yZGVyLXByaW1hcnkvNDAgZm9jdXMtd2l0aGluOnJpbmctMiBmb2N1cy13aXRoaW46cmluZy1wcmltYXJ5LzEwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+UGluY29kZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGluY29kZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGluY29kZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gMTYwMDYyXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy10cmFuc3BhcmVudCB0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBib3JkZXItbm9uZSBwLTAgbXQtMC41XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgbWItMVwiPkZvcm1hdHRlZCBBZGRyZXNzPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2Vjb25kYXJ5IGxpbmUtY2xhbXAtMyBtaW4taC1bNDhweF0gYmctZ3JheS01MCBwLTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhbmltYXRlLXB1bHNlIHRleHQtZ3JheS00MDBcIj5SZXNvbHZpbmcgYWRkcmVzcy4uLjwvc3Bhbj5cclxuICAgICAgICAgICAgICApIDogZGlzcGxheVRleHQgPyAoXHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5VGV4dFxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAnTW92ZSBtYXAgcGluIHRvIHNlbGVjdCBsb2NhdGlvbidcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29uZmlybX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgIXN0cnVjdHVyZWRBZGRyZXNzfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1wcmltYXJ5IHRleHQtd2hpdGUgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtYm9sZCBob3ZlcjpiZy1wcmltYXJ5LzkwIGRpc2FibGVkOm9wYWNpdHktNTAgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LXNtXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ29uZmlybSBMb2NhdGlvblxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+LFxyXG4gICAgZG9jdW1lbnQuYm9keVxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2NhdGlvblBpY2tlck1vZGFsO1xyXG4iXSwiZmlsZSI6IkM6L1Byb2plY3QvU2VydmljZS9jbGllbnQvc3JjL2NvbXBvbmVudHMvbW9kYWxzL0xvY2F0aW9uUGlja2VyTW9kYWwuanN4In0=
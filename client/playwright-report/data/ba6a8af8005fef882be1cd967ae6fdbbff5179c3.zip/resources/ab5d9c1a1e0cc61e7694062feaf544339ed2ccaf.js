import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AddressSelector.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=38a573e6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Project/Service/client/src/components/AddressSelector.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=38a573e6"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { MapPin, Building, ChevronDown, Home, Briefcase, ShoppingBag } from "/node_modules/.vite/deps/lucide-react.js?v=38a573e6";
import LocationPickerModal from "/src/components/modals/LocationPickerModal.jsx";
import { buildAddressPreview, smartAddressBuilder, buildStreetAddress } from "/src/utils/format.jsx";
import { latLngToS2CellId } from "/src/utils/s2Helper.js";
const AddressSelector = ({
  address = {},
  onChange,
  errors = {},
  className = "",
  compact = false,
  showLabel = false
}) => {
  _s();
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const selectedCountry = "IN";
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  useEffect(() => {
    import("/node_modules/.vite/deps/country-state-city.js?v=38a573e6").then(({ State }) => {
      const countryStates = State.getStatesOfCountry(selectedCountry);
      setStates(countryStates);
    });
  }, [selectedCountry]);
  const currentStateCode = states.find((s) => s.name === address.state)?.isoCode;
  useEffect(() => {
    if (currentStateCode) {
      import("/node_modules/.vite/deps/country-state-city.js?v=38a573e6").then(({ City }) => {
        const stateCities = City.getCitiesOfState(selectedCountry, currentStateCode);
        setCities(stateCities);
      });
    } else {
      setCities([]);
    }
  }, [selectedCountry, currentStateCode]);
  const enrichAddressWithS2Cells = (addr) => {
    const lat = parseFloat(addr.lat);
    const lng = parseFloat(addr.lng);
    if (!isNaN(lat) && !isNaN(lng) && lat !== 0 && lng !== 0) {
      return {
        ...addr,
        s2CellId: latLngToS2CellId(lat, lng, 13),
        s2CellIdPrecise: latLngToS2CellId(lat, lng, 20),
        geoHash: latLngToS2CellId(lat, lng, 13)
        // Map geoHash to level 13 S2 cell key
      };
    }
    return addr;
  };
  const handleFieldChange = (name, value) => {
    const updated = {
      ...address,
      [name]: value
    };
    if (name === "postalCode") {
      updated.pincode = value;
    } else if (name === "pincode") {
      updated.postalCode = value;
    }
    updated.street = buildStreetAddress(updated.houseNumber, updated.road);
    updated.addressLine = updated.street;
    if (!address.isManuallyEdited) {
      updated.formattedAddress = buildAddressPreview(updated) || smartAddressBuilder(
        {
          house_number: updated.houseNumber,
          road: updated.road,
          residential: updated.area,
          neighbourhood: updated.area,
          suburb: updated.area,
          city: updated.city,
          state: updated.state,
          postcode: updated.pincode
        },
        ""
      );
    }
    onChange(enrichAddressWithS2Cells(updated));
  };
  const handleStateChange = (stateName) => {
    const updated = {
      ...address,
      state: stateName,
      city: ""
      // Reset city on state change
    };
    if (!address.isManuallyEdited) {
      updated.formattedAddress = buildAddressPreview(updated) || smartAddressBuilder(
        {
          house_number: updated.houseNumber,
          road: updated.road,
          residential: updated.area,
          neighbourhood: updated.area,
          suburb: updated.area,
          city: updated.city,
          state: updated.state,
          postcode: updated.pincode
        },
        ""
      );
    }
    onChange(enrichAddressWithS2Cells(updated));
  };
  const handleCityChange = (cityName) => {
    const updated = {
      ...address,
      city: cityName
    };
    if (!address.isManuallyEdited) {
      updated.formattedAddress = buildAddressPreview(updated) || smartAddressBuilder(
        {
          house_number: updated.houseNumber,
          road: updated.road,
          residential: updated.area,
          neighbourhood: updated.area,
          suburb: updated.area,
          city: updated.city,
          state: updated.state,
          postcode: updated.pincode
        },
        ""
      );
    }
    onChange(enrichAddressWithS2Cells(updated));
  };
  return /* @__PURE__ */ jsxDEV("div", { className: `${compact ? "space-y-2.5" : "space-y-4"} ${className}`, children: [
    showLabel && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1.5 pb-2 border-b border-gray-100", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "text-[10.5px] font-bold text-gray-500 uppercase tracking-wider", children: "LABEL:" }, void 0, false, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 168,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-1.5", children: [
        { id: "Home", label: "Home", icon: Home },
        { id: "Office", label: "Office", icon: Briefcase },
        { id: "Shop", label: "Shop", icon: ShoppingBag },
        { id: "Other", label: "Other", icon: MapPin }
      ].map((item) => {
        const IconComp = item.icon;
        const isSel = (address.label || "Home") === item.id;
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleFieldChange("label", item.id),
            className: `flex items-center gap-1.5 px-3 py-1 rounded-lg border text-xs font-bold transition-all ${isSel ? "border-primary bg-primary/10 text-primary shadow-xs" : "border-gray-200 text-gray-600 hover:border-gray-300 bg-white"}`,
            children: [
              /* @__PURE__ */ jsxDEV(IconComp, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                lineNumber: 189,
                columnNumber: 19
              }, this),
              item.label
            ]
          },
          item.id,
          true,
          {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 179,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 169,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
      lineNumber: 167,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `flex justify-between items-center ${compact ? "pb-1 border-b border-gray-100" : "pb-2 border-b border-gray-150"}`, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-gray-400 uppercase tracking-wider", children: "Address Details" }, void 0, false, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 200,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setIsMapModalOpen(true),
          className: `bg-red-500 hover:bg-red-600 text-white rounded-full ${compact ? "p-1.5 shadow-md" : "p-2.5 shadow-lg"} shadow-red-500/20 active:scale-95 transition-all flex items-center justify-center`,
          title: "Select Location on Map",
          children: /* @__PURE__ */ jsxDEV(MapPin, { className: compact ? "w-3.5 h-3.5" : "w-5 h-5" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 207,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 201,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
      lineNumber: 199,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `grid grid-cols-2 ${compact ? "gap-2" : "gap-3"}`, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide truncate", children: "House / Flat No. *" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 214,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "houseNumber",
            value: address.houseNumber || "",
            onChange: (e) => handleFieldChange("houseNumber", e.target.value),
            placeholder: "House No., Flat 4B",
            className: `w-full ${compact ? "px-2 py-1 text-xs" : "px-3 py-2 text-sm"} border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white text-secondary font-medium`
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 215,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 213,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide truncate", children: "Road / Street *" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 225,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "road",
            value: address.road || "",
            onChange: (e) => handleFieldChange("road", e.target.value),
            placeholder: "MG Road, Phase 1",
            className: `w-full ${compact ? "px-2 py-1 text-xs" : "px-3 py-2 text-sm"} border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white text-secondary font-medium`
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 226,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 224,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
      lineNumber: 212,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `grid grid-cols-2 ${compact ? "gap-2" : "gap-3"}`, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide truncate", children: "Landmark (Optional)" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 240,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "landmark",
            value: address.landmark || "",
            onChange: (e) => handleFieldChange("landmark", e.target.value),
            placeholder: "Near Temple",
            className: `w-full ${compact ? "px-2 py-1 text-xs" : "px-3 py-2 text-sm"} border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white text-secondary font-medium`
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 241,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 239,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide truncate", children: "Area / Locality" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 251,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "area",
            value: address.area || "",
            onChange: (e) => handleFieldChange("area", e.target.value),
            placeholder: "Sector 15",
            className: `w-full ${compact ? "px-2 py-1 text-xs" : "px-3 py-2 text-sm"} border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white text-secondary font-medium`
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 252,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 250,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
      lineNumber: 238,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `grid grid-cols-2 sm:grid-cols-3 ${compact ? "gap-2" : "gap-3"}`, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "state", className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide", children: "State *" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 267,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(MapPin, { className: "text-gray-400 w-3 h-3" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 270,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 269,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              id: "state",
              name: "state",
              value: address.state || "",
              onChange: (e) => handleStateChange(e.target.value),
              className: `w-full ${compact ? "pl-6 pr-6 py-1 text-xs" : "pl-8 pr-8 py-2 text-sm"} bg-white border border-gray-200 rounded-lg text-secondary focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium appearance-none`,
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "State" }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                  lineNumber: 279,
                  columnNumber: 15
                }, this),
                address.state && !states.some((s) => s.name === address.state) && /* @__PURE__ */ jsxDEV("option", { value: address.state, children: address.state }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                  lineNumber: 281,
                  columnNumber: 15
                }, this),
                states.map(
                  (state) => /* @__PURE__ */ jsxDEV("option", { value: state.name, children: state.name }, state.isoCode, false, {
                    fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                    lineNumber: 284,
                    columnNumber: 15
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
              lineNumber: 272,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 right-0 pr-2 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-3 h-3 text-gray-400" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 290,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 289,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 268,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 266,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "city", className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide", children: "City *" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 297,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(Building, { className: "text-gray-400 w-3 h-3" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 300,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 299,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              id: "city",
              name: "city",
              value: address.city || "",
              onChange: (e) => handleCityChange(e.target.value),
              className: `w-full ${compact ? "pl-6 pr-6 py-1 text-xs" : "pl-8 pr-8 py-2 text-sm"} bg-white border border-gray-200 rounded-lg text-secondary focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium appearance-none disabled:bg-gray-50 disabled:text-gray-400`,
              disabled: !address.state,
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "City" }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                  lineNumber: 310,
                  columnNumber: 15
                }, this),
                address.city && !cities.some((c) => c.name === address.city) && /* @__PURE__ */ jsxDEV("option", { value: address.city, children: address.city }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                  lineNumber: 312,
                  columnNumber: 15
                }, this),
                cities.map(
                  (city) => /* @__PURE__ */ jsxDEV("option", { value: city.name, children: city.name }, city.name, false, {
                    fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
                    lineNumber: 315,
                    columnNumber: 15
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
              lineNumber: 302,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 right-0 pr-2 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-3 h-3 text-gray-400" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 321,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 320,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 298,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 296,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5 w-full col-span-2 sm:col-span-1", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-[10px] sm:text-[10.5px] font-semibold text-secondary uppercase tracking-wide", children: "Pincode *" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 328,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "pincode",
            value: address.pincode || address.postalCode || "",
            onChange: (e) => handleFieldChange("pincode", e.target.value),
            placeholder: "6-digit Pincode",
            maxLength: "6",
            className: `w-full ${compact ? "px-2 py-1 text-xs" : "px-3 py-2 text-sm"} border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary/20 text-secondary font-medium font-mono`
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
            lineNumber: 329,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 327,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
      lineNumber: 264,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "text-[10.5px] font-semibold text-gray-400 uppercase tracking-wide", children: "Address Preview / Edit Manually" }, void 0, false, {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 343,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          name: "formattedAddress",
          value: address.formattedAddress || buildAddressPreview(address) || "",
          onChange: (e) => {
            const val = e.target.value;
            onChange(enrichAddressWithS2Cells({
              ...address,
              formattedAddress: val,
              isManuallyEdited: true
            }));
          },
          placeholder: "Please fill House No. and Road name to construct preview, or edit here manually...",
          rows: compact ? 1 : 2,
          className: `w-full ${compact ? "p-2 text-xs h-12" : "p-3 text-xs"} border border-gray-200 rounded-lg text-secondary font-medium leading-relaxed shadow-inner resize-none focus:ring-2 focus:ring-primary/20 focus:outline-none`
        },
        void 0,
        false,
        {
          fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
          lineNumber: 344,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
      lineNumber: 342,
      columnNumber: 7
    }, this),
    isMapModalOpen && /* @__PURE__ */ jsxDEV(
      LocationPickerModal,
      {
        isOpen: isMapModalOpen,
        onClose: () => setIsMapModalOpen(false),
        onLocationSelect: (loc) => {
          const updated = {
            ...address,
            ...loc
          };
          onChange(enrichAddressWithS2Cells(updated));
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
        lineNumber: 362,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Project/Service/client/src/components/AddressSelector.jsx",
    lineNumber: 164,
    columnNumber: 5
  }, this);
};
_s(AddressSelector, "+LF/p2zoyFgC9Dx3wbihtNkerBQ=");
_c = AddressSelector;
export default AddressSelector;
var _c;
$RefreshReg$(_c, "AddressSelector");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Project/Service/client/src/components/AddressSelector.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Project/Service/client/src/components/AddressSelector.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0pVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBKVixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsUUFBUUMsVUFBVUMsYUFBYUMsTUFBTUMsV0FBV0MsbUJBQW1CO0FBQzVFLE9BQU9DLHlCQUF5QjtBQUNoQyxTQUFTQyxxQkFBcUJDLHFCQUFxQkMsMEJBQTBCO0FBQzdFLFNBQVNDLHdCQUF3QjtBQUVqQyxNQUFNQyxrQkFBa0JBLENBQUM7QUFBQSxFQUN2QkMsVUFBVSxDQUFDO0FBQUEsRUFDWEM7QUFBQUEsRUFDQUMsU0FBUyxDQUFDO0FBQUEsRUFDVkMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQ2QsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJdEIsU0FBUyxLQUFLO0FBQzFELFFBQU11QixrQkFBa0I7QUFDeEIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl6QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMEIsUUFBUUMsU0FBUyxJQUFJM0IsU0FBUyxFQUFFO0FBRXZDQyxZQUFVLE1BQU07QUFDZCxXQUFPLG9CQUFvQixFQUFFMkIsS0FBSyxDQUFDLEVBQUVDLE1BQU0sTUFBTTtBQUMvQyxZQUFNQyxnQkFBZ0JELE1BQU1FLG1CQUFtQlIsZUFBZTtBQUM5REUsZ0JBQVVLLGFBQWE7QUFBQSxJQUN6QixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNQLGVBQWUsQ0FBQztBQUdwQixRQUFNUyxtQkFBbUJSLE9BQU9TLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsU0FBU3JCLFFBQVFzQixLQUFLLEdBQUdDO0FBRXJFcEMsWUFBVSxNQUFNO0FBQ2QsUUFBSStCLGtCQUFrQjtBQUNwQixhQUFPLG9CQUFvQixFQUFFSixLQUFLLENBQUMsRUFBRVUsS0FBSyxNQUFNO0FBQzlDLGNBQU1DLGNBQWNELEtBQUtFLGlCQUFpQmpCLGlCQUFpQlMsZ0JBQWdCO0FBQzNFTCxrQkFBVVksV0FBVztBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTFosZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ0osaUJBQWlCUyxnQkFBZ0IsQ0FBQztBQUd0QyxRQUFNUywyQkFBMkJBLENBQUNDLFNBQVM7QUFDekMsVUFBTUMsTUFBTUMsV0FBV0YsS0FBS0MsR0FBRztBQUMvQixVQUFNRSxNQUFNRCxXQUFXRixLQUFLRyxHQUFHO0FBQy9CLFFBQUksQ0FBQ0MsTUFBTUgsR0FBRyxLQUFLLENBQUNHLE1BQU1ELEdBQUcsS0FBS0YsUUFBUSxLQUFLRSxRQUFRLEdBQUc7QUFDeEQsYUFBTztBQUFBLFFBQ0wsR0FBR0g7QUFBQUEsUUFDSEssVUFBVW5DLGlCQUFpQitCLEtBQUtFLEtBQUssRUFBRTtBQUFBLFFBQ3ZDRyxpQkFBaUJwQyxpQkFBaUIrQixLQUFLRSxLQUFLLEVBQUU7QUFBQSxRQUM5Q0ksU0FBU3JDLGlCQUFpQitCLEtBQUtFLEtBQUssRUFBRTtBQUFBO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsV0FBT0g7QUFBQUEsRUFDVDtBQUVBLFFBQU1RLG9CQUFvQkEsQ0FBQ2YsTUFBTWdCLFVBQVU7QUFDekMsVUFBTUMsVUFBVTtBQUFBLE1BQ2QsR0FBR3RDO0FBQUFBLE1BQ0gsQ0FBQ3FCLElBQUksR0FBR2dCO0FBQUFBLElBQ1Y7QUFHQSxRQUFJaEIsU0FBUyxjQUFjO0FBQ3pCaUIsY0FBUUMsVUFBVUY7QUFBQUEsSUFDcEIsV0FBV2hCLFNBQVMsV0FBVztBQUM3QmlCLGNBQVFFLGFBQWFIO0FBQUFBLElBQ3ZCO0FBR0FDLFlBQVFHLFNBQVM1QyxtQkFBbUJ5QyxRQUFRSSxhQUFhSixRQUFRSyxJQUFJO0FBQ3JFTCxZQUFRTSxjQUFjTixRQUFRRztBQUc5QixRQUFJLENBQUN6QyxRQUFRNkMsa0JBQWtCO0FBQzdCUCxjQUFRUSxtQkFBbUJuRCxvQkFBb0IyQyxPQUFPLEtBQUsxQztBQUFBQSxRQUN6RDtBQUFBLFVBQ0VtRCxjQUFjVCxRQUFRSTtBQUFBQSxVQUN0QkMsTUFBTUwsUUFBUUs7QUFBQUEsVUFDZEssYUFBYVYsUUFBUVc7QUFBQUEsVUFDckJDLGVBQWVaLFFBQVFXO0FBQUFBLFVBQ3ZCRSxRQUFRYixRQUFRVztBQUFBQSxVQUNoQkcsTUFBTWQsUUFBUWM7QUFBQUEsVUFDZDlCLE9BQU9nQixRQUFRaEI7QUFBQUEsVUFDZitCLFVBQVVmLFFBQVFDO0FBQUFBLFFBQ3BCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUF0QyxhQUFTMEIseUJBQXlCVyxPQUFPLENBQUM7QUFBQSxFQUM1QztBQUVBLFFBQU1nQixvQkFBb0JBLENBQUNDLGNBQWM7QUFDdkMsVUFBTWpCLFVBQVU7QUFBQSxNQUNkLEdBQUd0QztBQUFBQSxNQUNIc0IsT0FBT2lDO0FBQUFBLE1BQ1BILE1BQU07QUFBQTtBQUFBLElBQ1I7QUFFQSxRQUFJLENBQUNwRCxRQUFRNkMsa0JBQWtCO0FBQzdCUCxjQUFRUSxtQkFBbUJuRCxvQkFBb0IyQyxPQUFPLEtBQUsxQztBQUFBQSxRQUN6RDtBQUFBLFVBQ0VtRCxjQUFjVCxRQUFRSTtBQUFBQSxVQUN0QkMsTUFBTUwsUUFBUUs7QUFBQUEsVUFDZEssYUFBYVYsUUFBUVc7QUFBQUEsVUFDckJDLGVBQWVaLFFBQVFXO0FBQUFBLFVBQ3ZCRSxRQUFRYixRQUFRVztBQUFBQSxVQUNoQkcsTUFBTWQsUUFBUWM7QUFBQUEsVUFDZDlCLE9BQU9nQixRQUFRaEI7QUFBQUEsVUFDZitCLFVBQVVmLFFBQVFDO0FBQUFBLFFBQ3BCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUF0QyxhQUFTMEIseUJBQXlCVyxPQUFPLENBQUM7QUFBQSxFQUM1QztBQUVBLFFBQU1rQixtQkFBbUJBLENBQUNDLGFBQWE7QUFDckMsVUFBTW5CLFVBQVU7QUFBQSxNQUNkLEdBQUd0QztBQUFBQSxNQUNIb0QsTUFBTUs7QUFBQUEsSUFDUjtBQUVBLFFBQUksQ0FBQ3pELFFBQVE2QyxrQkFBa0I7QUFDN0JQLGNBQVFRLG1CQUFtQm5ELG9CQUFvQjJDLE9BQU8sS0FBSzFDO0FBQUFBLFFBQ3pEO0FBQUEsVUFDRW1ELGNBQWNULFFBQVFJO0FBQUFBLFVBQ3RCQyxNQUFNTCxRQUFRSztBQUFBQSxVQUNkSyxhQUFhVixRQUFRVztBQUFBQSxVQUNyQkMsZUFBZVosUUFBUVc7QUFBQUEsVUFDdkJFLFFBQVFiLFFBQVFXO0FBQUFBLFVBQ2hCRyxNQUFNZCxRQUFRYztBQUFBQSxVQUNkOUIsT0FBT2dCLFFBQVFoQjtBQUFBQSxVQUNmK0IsVUFBVWYsUUFBUUM7QUFBQUEsUUFDcEI7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQXRDLGFBQVMwQix5QkFBeUJXLE9BQU8sQ0FBQztBQUFBLEVBQzVDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVcsR0FBR2xDLFVBQVUsZ0JBQWdCLFdBQVcsSUFBSUQsU0FBUyxJQUVsRUU7QUFBQUEsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGtFQUFpRSxzQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RjtBQUFBLE1BQ3hGLHVCQUFDLFNBQUksV0FBVSx1Q0FDWjtBQUFBLFFBQ0MsRUFBRXFELElBQUksUUFBUUMsT0FBTyxRQUFRQyxNQUFNckUsS0FBSztBQUFBLFFBQ3hDLEVBQUVtRSxJQUFJLFVBQVVDLE9BQU8sVUFBVUMsTUFBTXBFLFVBQVU7QUFBQSxRQUNqRCxFQUFFa0UsSUFBSSxRQUFRQyxPQUFPLFFBQVFDLE1BQU1uRSxZQUFZO0FBQUEsUUFDL0MsRUFBRWlFLElBQUksU0FBU0MsT0FBTyxTQUFTQyxNQUFNeEUsT0FBTztBQUFBLE1BQUMsRUFDN0N5RSxJQUFJLENBQUNDLFNBQVM7QUFDZCxjQUFNQyxXQUFXRCxLQUFLRjtBQUN0QixjQUFNSSxTQUFTaEUsUUFBUTJELFNBQVMsWUFBWUcsS0FBS0o7QUFDakQsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNdEIsa0JBQWtCLFNBQVMwQixLQUFLSixFQUFFO0FBQUEsWUFDakQsV0FBVywwRkFDVE0sUUFDSSx3REFDQSw4REFBOEQ7QUFBQSxZQUdwRTtBQUFBLHFDQUFDLFlBQVMsV0FBVSxpQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUNoQ0YsS0FBS0g7QUFBQUE7QUFBQUE7QUFBQUEsVUFWREcsS0FBS0o7QUFBQUEsVUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxNQUVKLENBQUMsS0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLFNBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVyxxQ0FBcUN0RCxVQUFVLGtDQUFrQywrQkFBK0IsSUFDOUg7QUFBQSw2QkFBQyxVQUFLLFdBQVUsNERBQTJELCtCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBGO0FBQUEsTUFDMUY7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTUksa0JBQWtCLElBQUk7QUFBQSxVQUNyQyxXQUFXLHVEQUF1REosVUFBVSxvQkFBb0IsaUJBQWlCO0FBQUEsVUFDakgsT0FBTTtBQUFBLFVBRU4saUNBQUMsVUFBTyxXQUFXQSxVQUFVLGdCQUFnQixhQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBO0FBQUEsUUFOekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFXLG9CQUFvQkEsVUFBVSxVQUFVLE9BQU8sSUFDN0Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsOEZBQTZGLGtDQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdJO0FBQUEsUUFDaEk7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE1BQUs7QUFBQSxZQUNMLE9BQU9KLFFBQVEwQyxlQUFlO0FBQUEsWUFDOUIsVUFBVSxDQUFDdUIsTUFBTTdCLGtCQUFrQixlQUFlNkIsRUFBRUMsT0FBTzdCLEtBQUs7QUFBQSxZQUNoRSxhQUFZO0FBQUEsWUFDWixXQUFXLFVBQVVqQyxVQUFVLHNCQUFzQixtQkFBbUI7QUFBQTtBQUFBLFVBTjFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU15TTtBQUFBLFdBUjNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLDhGQUE2RiwrQkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SDtBQUFBLFFBQzdIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxPQUFPSixRQUFRMkMsUUFBUTtBQUFBLFlBQ3ZCLFVBQVUsQ0FBQ3NCLE1BQU03QixrQkFBa0IsUUFBUTZCLEVBQUVDLE9BQU83QixLQUFLO0FBQUEsWUFDekQsYUFBWTtBQUFBLFlBQ1osV0FBVyxVQUFVakMsVUFBVSxzQkFBc0IsbUJBQW1CO0FBQUE7QUFBQSxVQU4xRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNeU07QUFBQSxXQVIzTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVcsb0JBQW9CQSxVQUFVLFVBQVUsT0FBTyxJQUM3RDtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSw4RkFBNkYsbUNBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUk7QUFBQSxRQUNqSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsT0FBT0osUUFBUW1FLFlBQVk7QUFBQSxZQUMzQixVQUFVLENBQUNGLE1BQU03QixrQkFBa0IsWUFBWTZCLEVBQUVDLE9BQU83QixLQUFLO0FBQUEsWUFDN0QsYUFBWTtBQUFBLFlBQ1osV0FBVyxVQUFVakMsVUFBVSxzQkFBc0IsbUJBQW1CO0FBQUE7QUFBQSxVQU4xRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNeU07QUFBQSxXQVIzTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSw4RkFBNkYsK0JBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkg7QUFBQSxRQUM3SDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsT0FBT0osUUFBUWlELFFBQVE7QUFBQSxZQUN2QixVQUFVLENBQUNnQixNQUFNN0Isa0JBQWtCLFFBQVE2QixFQUFFQyxPQUFPN0IsS0FBSztBQUFBLFlBQ3pELGFBQVk7QUFBQSxZQUNaLFdBQVcsVUFBVWpDLFVBQVUsc0JBQXNCLG1CQUFtQjtBQUFBO0FBQUEsVUFOMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXlNO0FBQUEsV0FSM007QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFXLG1DQUFtQ0EsVUFBVSxVQUFVLE9BQU8sSUFFNUU7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxXQUFNLFNBQVEsU0FBUSxXQUFVLHFGQUFvRix1QkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0SDtBQUFBLFFBQzVILHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdFQUNiLGlDQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU9KLFFBQVFzQixTQUFTO0FBQUEsY0FDeEIsVUFBVSxDQUFDMkMsTUFBTVgsa0JBQWtCVyxFQUFFQyxPQUFPN0IsS0FBSztBQUFBLGNBQ2pELFdBQVcsVUFBVWpDLFVBQVUsMkJBQTJCLHdCQUF3QjtBQUFBLGNBRWxGO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUcscUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNCO0FBQUEsZ0JBQ3JCSixRQUFRc0IsU0FBUyxDQUFDWixPQUFPMEQsS0FBSyxDQUFBaEQsTUFBS0EsRUFBRUMsU0FBU3JCLFFBQVFzQixLQUFLLEtBQzFELHVCQUFDLFlBQU8sT0FBT3RCLFFBQVFzQixPQUFRdEIsa0JBQVFzQixTQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QztBQUFBLGdCQUU5Q1osT0FBT21EO0FBQUFBLGtCQUFJLENBQUN2QyxVQUNYLHVCQUFDLFlBQTJCLE9BQU9BLE1BQU1ELE1BQ3RDQyxnQkFBTUQsUUFESUMsTUFBTUMsU0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQTtBQUFBLFlBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFdBQU0sU0FBUSxRQUFPLFdBQVUscUZBQW9GLHNCQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBIO0FBQUEsUUFDMUgsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0VBQ2IsaUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT3ZCLFFBQVFvRCxRQUFRO0FBQUEsY0FDdkIsVUFBVSxDQUFDYSxNQUFNVCxpQkFBaUJTLEVBQUVDLE9BQU83QixLQUFLO0FBQUEsY0FDaEQsV0FBVyxVQUFVakMsVUFBVSwyQkFBMkIsd0JBQXdCO0FBQUEsY0FDbEYsVUFBVSxDQUFDSixRQUFRc0I7QUFBQUEsY0FFbkI7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sSUFBRyxvQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUI7QUFBQSxnQkFDcEJ0QixRQUFRb0QsUUFBUSxDQUFDeEMsT0FBT3dELEtBQUssQ0FBQUMsTUFBS0EsRUFBRWhELFNBQVNyQixRQUFRb0QsSUFBSSxLQUN4RCx1QkFBQyxZQUFPLE9BQU9wRCxRQUFRb0QsTUFBT3BELGtCQUFRb0QsUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFFNUN4QyxPQUFPaUQ7QUFBQUEsa0JBQUksQ0FBQ1QsU0FDWCx1QkFBQyxZQUF1QixPQUFPQSxLQUFLL0IsTUFDakMrQixlQUFLL0IsUUFESytCLEtBQUsvQixNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFdBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxxRkFBb0YseUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEc7QUFBQSxRQUM5RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsT0FBT3JCLFFBQVF1QyxXQUFXdkMsUUFBUXdDLGNBQWM7QUFBQSxZQUNoRCxVQUFVLENBQUN5QixNQUFNN0Isa0JBQWtCLFdBQVc2QixFQUFFQyxPQUFPN0IsS0FBSztBQUFBLFlBQzVELGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUNWLFdBQVcsVUFBVWpDLFVBQVUsc0JBQXNCLG1CQUFtQjtBQUFBO0FBQUEsVUFQMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT3VMO0FBQUEsV0FUekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLHFFQUFvRSwrQ0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvSDtBQUFBLE1BQ3BIO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPSixRQUFROEMsb0JBQW9CbkQsb0JBQW9CSyxPQUFPLEtBQUs7QUFBQSxVQUNuRSxVQUFVLENBQUNpRSxNQUFNO0FBQ2Ysa0JBQU1LLE1BQU1MLEVBQUVDLE9BQU83QjtBQUNyQnBDLHFCQUFTMEIseUJBQXlCO0FBQUEsY0FDaEMsR0FBRzNCO0FBQUFBLGNBQ0g4QyxrQkFBa0J3QjtBQUFBQSxjQUNsQnpCLGtCQUFrQjtBQUFBLFlBQ3BCLENBQUMsQ0FBQztBQUFBLFVBQ0o7QUFBQSxVQUNBLGFBQVk7QUFBQSxVQUNaLE1BQU16QyxVQUFVLElBQUk7QUFBQSxVQUNwQixXQUFXLFVBQVVBLFVBQVUscUJBQXFCLGFBQWE7QUFBQTtBQUFBLFFBYm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWFrTztBQUFBLFNBZnBPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUVDRyxrQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBUUE7QUFBQUEsUUFDUixTQUFTLE1BQU1DLGtCQUFrQixLQUFLO0FBQUEsUUFDdEMsa0JBQWtCLENBQUMrRCxRQUFRO0FBQ3pCLGdCQUFNakMsVUFBVTtBQUFBLFlBQ2QsR0FBR3RDO0FBQUFBLFlBQ0gsR0FBR3VFO0FBQUFBLFVBQ0w7QUFDQXRFLG1CQUFTMEIseUJBQXlCVyxPQUFPLENBQUM7QUFBQSxRQUM1QztBQUFBO0FBQUEsTUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTSTtBQUFBLE9BL01SO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrTkE7QUFFSjtBQUFFaEMsR0E5VklQLGlCQUFlO0FBQUEsS0FBZkE7QUFnV04sZUFBZUE7QUFBZ0IsSUFBQXlFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTWFwUGluIiwiQnVpbGRpbmciLCJDaGV2cm9uRG93biIsIkhvbWUiLCJCcmllZmNhc2UiLCJTaG9wcGluZ0JhZyIsIkxvY2F0aW9uUGlja2VyTW9kYWwiLCJidWlsZEFkZHJlc3NQcmV2aWV3Iiwic21hcnRBZGRyZXNzQnVpbGRlciIsImJ1aWxkU3RyZWV0QWRkcmVzcyIsImxhdExuZ1RvUzJDZWxsSWQiLCJBZGRyZXNzU2VsZWN0b3IiLCJhZGRyZXNzIiwib25DaGFuZ2UiLCJlcnJvcnMiLCJjbGFzc05hbWUiLCJjb21wYWN0Iiwic2hvd0xhYmVsIiwiX3MiLCJpc01hcE1vZGFsT3BlbiIsInNldElzTWFwTW9kYWxPcGVuIiwic2VsZWN0ZWRDb3VudHJ5Iiwic3RhdGVzIiwic2V0U3RhdGVzIiwiY2l0aWVzIiwic2V0Q2l0aWVzIiwidGhlbiIsIlN0YXRlIiwiY291bnRyeVN0YXRlcyIsImdldFN0YXRlc09mQ291bnRyeSIsImN1cnJlbnRTdGF0ZUNvZGUiLCJmaW5kIiwicyIsIm5hbWUiLCJzdGF0ZSIsImlzb0NvZGUiLCJDaXR5Iiwic3RhdGVDaXRpZXMiLCJnZXRDaXRpZXNPZlN0YXRlIiwiZW5yaWNoQWRkcmVzc1dpdGhTMkNlbGxzIiwiYWRkciIsImxhdCIsInBhcnNlRmxvYXQiLCJsbmciLCJpc05hTiIsInMyQ2VsbElkIiwiczJDZWxsSWRQcmVjaXNlIiwiZ2VvSGFzaCIsImhhbmRsZUZpZWxkQ2hhbmdlIiwidmFsdWUiLCJ1cGRhdGVkIiwicGluY29kZSIsInBvc3RhbENvZGUiLCJzdHJlZXQiLCJob3VzZU51bWJlciIsInJvYWQiLCJhZGRyZXNzTGluZSIsImlzTWFudWFsbHlFZGl0ZWQiLCJmb3JtYXR0ZWRBZGRyZXNzIiwiaG91c2VfbnVtYmVyIiwicmVzaWRlbnRpYWwiLCJhcmVhIiwibmVpZ2hib3VyaG9vZCIsInN1YnVyYiIsImNpdHkiLCJwb3N0Y29kZSIsImhhbmRsZVN0YXRlQ2hhbmdlIiwic3RhdGVOYW1lIiwiaGFuZGxlQ2l0eUNoYW5nZSIsImNpdHlOYW1lIiwiaWQiLCJsYWJlbCIsImljb24iLCJtYXAiLCJpdGVtIiwiSWNvbkNvbXAiLCJpc1NlbCIsImUiLCJ0YXJnZXQiLCJsYW5kbWFyayIsInNvbWUiLCJjIiwidmFsIiwibG9jIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWRkcmVzc1NlbGVjdG9yLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTWFwUGluLCBCdWlsZGluZywgQ2hldnJvbkRvd24sIEhvbWUsIEJyaWVmY2FzZSwgU2hvcHBpbmdCYWcgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IExvY2F0aW9uUGlja2VyTW9kYWwgZnJvbSAnLi9tb2RhbHMvTG9jYXRpb25QaWNrZXJNb2RhbCc7XG5pbXBvcnQgeyBidWlsZEFkZHJlc3NQcmV2aWV3LCBzbWFydEFkZHJlc3NCdWlsZGVyLCBidWlsZFN0cmVldEFkZHJlc3MgfSBmcm9tICcuLi91dGlscy9mb3JtYXQnO1xuaW1wb3J0IHsgbGF0TG5nVG9TMkNlbGxJZCB9IGZyb20gJy4uL3V0aWxzL3MySGVscGVyJztcblxuY29uc3QgQWRkcmVzc1NlbGVjdG9yID0gKHtcbiAgYWRkcmVzcyA9IHt9LFxuICBvbkNoYW5nZSxcbiAgZXJyb3JzID0ge30sXG4gIGNsYXNzTmFtZSA9IFwiXCIsXG4gIGNvbXBhY3QgPSBmYWxzZSxcbiAgc2hvd0xhYmVsID0gZmFsc2Vcbn0pID0+IHtcbiAgY29uc3QgW2lzTWFwTW9kYWxPcGVuLCBzZXRJc01hcE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHNlbGVjdGVkQ291bnRyeSA9ICdJTic7IC8vIEZpeGVkIHRvIEluZGlhIGZvciBub3dcbiAgY29uc3QgW3N0YXRlcywgc2V0U3RhdGVzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW2NpdGllcywgc2V0Q2l0aWVzXSA9IHVzZVN0YXRlKFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGltcG9ydCgnY291bnRyeS1zdGF0ZS1jaXR5JykudGhlbigoeyBTdGF0ZSB9KSA9PiB7XG4gICAgICBjb25zdCBjb3VudHJ5U3RhdGVzID0gU3RhdGUuZ2V0U3RhdGVzT2ZDb3VudHJ5KHNlbGVjdGVkQ291bnRyeSk7XG4gICAgICBzZXRTdGF0ZXMoY291bnRyeVN0YXRlcyk7XG4gICAgfSk7XG4gIH0sIFtzZWxlY3RlZENvdW50cnldKTtcblxuICAvLyBGaW5kIHN0YXRlIGNvZGUgZnJvbSBzdGF0ZSBuYW1lXG4gIGNvbnN0IGN1cnJlbnRTdGF0ZUNvZGUgPSBzdGF0ZXMuZmluZChzID0+IHMubmFtZSA9PT0gYWRkcmVzcy5zdGF0ZSk/Lmlzb0NvZGU7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY3VycmVudFN0YXRlQ29kZSkge1xuICAgICAgaW1wb3J0KCdjb3VudHJ5LXN0YXRlLWNpdHknKS50aGVuKCh7IENpdHkgfSkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0ZUNpdGllcyA9IENpdHkuZ2V0Q2l0aWVzT2ZTdGF0ZShzZWxlY3RlZENvdW50cnksIGN1cnJlbnRTdGF0ZUNvZGUpO1xuICAgICAgICBzZXRDaXRpZXMoc3RhdGVDaXRpZXMpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENpdGllcyhbXSk7XG4gICAgfVxuICB9LCBbc2VsZWN0ZWRDb3VudHJ5LCBjdXJyZW50U3RhdGVDb2RlXSk7XG5cbiAgLy8gU2hhcmVkIFMyIENlbGwgaGVscGVyIHRvIGVuc3VyZSBzMkNlbGxJZCwgczJDZWxsSWRQcmVjaXNlLCBhbmQgZ2VvSGFzaCBhcmUgY29tcHV0ZWQgaWYgbGF0L2xuZyBhcmUgcHJlc2VudFxuICBjb25zdCBlbnJpY2hBZGRyZXNzV2l0aFMyQ2VsbHMgPSAoYWRkcikgPT4ge1xuICAgIGNvbnN0IGxhdCA9IHBhcnNlRmxvYXQoYWRkci5sYXQpO1xuICAgIGNvbnN0IGxuZyA9IHBhcnNlRmxvYXQoYWRkci5sbmcpO1xuICAgIGlmICghaXNOYU4obGF0KSAmJiAhaXNOYU4obG5nKSAmJiBsYXQgIT09IDAgJiYgbG5nICE9PSAwKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5hZGRyLFxuICAgICAgICBzMkNlbGxJZDogbGF0TG5nVG9TMkNlbGxJZChsYXQsIGxuZywgMTMpLFxuICAgICAgICBzMkNlbGxJZFByZWNpc2U6IGxhdExuZ1RvUzJDZWxsSWQobGF0LCBsbmcsIDIwKSxcbiAgICAgICAgZ2VvSGFzaDogbGF0TG5nVG9TMkNlbGxJZChsYXQsIGxuZywgMTMpIC8vIE1hcCBnZW9IYXNoIHRvIGxldmVsIDEzIFMyIGNlbGwga2V5XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gYWRkcjtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVGaWVsZENoYW5nZSA9IChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWQgPSB7XG4gICAgICAuLi5hZGRyZXNzLFxuICAgICAgW25hbWVdOiB2YWx1ZVxuICAgIH07XG5cbiAgICAvLyBLZWVwIHBvc3RhbENvZGUgYW5kIHBpbmNvZGUgaW4gc3luY1xuICAgIGlmIChuYW1lID09PSAncG9zdGFsQ29kZScpIHtcbiAgICAgIHVwZGF0ZWQucGluY29kZSA9IHZhbHVlO1xuICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ3BpbmNvZGUnKSB7XG4gICAgICB1cGRhdGVkLnBvc3RhbENvZGUgPSB2YWx1ZTtcbiAgICB9XG5cbiAgICAvLyBBdXRvLWNvbnN0cnVjdCBzdHJlZXQgaWYgaG91c2VOdW1iZXIgYW5kIHJvYWQgYXJlIHVwZGF0ZWRcbiAgICB1cGRhdGVkLnN0cmVldCA9IGJ1aWxkU3RyZWV0QWRkcmVzcyh1cGRhdGVkLmhvdXNlTnVtYmVyLCB1cGRhdGVkLnJvYWQpO1xuICAgIHVwZGF0ZWQuYWRkcmVzc0xpbmUgPSB1cGRhdGVkLnN0cmVldDtcblxuICAgIC8vIFJlLWJ1aWxkIGZvcm1hdHRlZEFkZHJlc3MgYmFzZWQgb24gdGhlIGNoYW5nZWQgaW5wdXRzXG4gICAgaWYgKCFhZGRyZXNzLmlzTWFudWFsbHlFZGl0ZWQpIHtcbiAgICAgIHVwZGF0ZWQuZm9ybWF0dGVkQWRkcmVzcyA9IGJ1aWxkQWRkcmVzc1ByZXZpZXcodXBkYXRlZCkgfHwgc21hcnRBZGRyZXNzQnVpbGRlcihcbiAgICAgICAge1xuICAgICAgICAgIGhvdXNlX251bWJlcjogdXBkYXRlZC5ob3VzZU51bWJlcixcbiAgICAgICAgICByb2FkOiB1cGRhdGVkLnJvYWQsXG4gICAgICAgICAgcmVzaWRlbnRpYWw6IHVwZGF0ZWQuYXJlYSxcbiAgICAgICAgICBuZWlnaGJvdXJob29kOiB1cGRhdGVkLmFyZWEsXG4gICAgICAgICAgc3VidXJiOiB1cGRhdGVkLmFyZWEsXG4gICAgICAgICAgY2l0eTogdXBkYXRlZC5jaXR5LFxuICAgICAgICAgIHN0YXRlOiB1cGRhdGVkLnN0YXRlLFxuICAgICAgICAgIHBvc3Rjb2RlOiB1cGRhdGVkLnBpbmNvZGVcbiAgICAgICAgfSxcbiAgICAgICAgXCJcIlxuICAgICAgKTtcbiAgICB9XG5cbiAgICBvbkNoYW5nZShlbnJpY2hBZGRyZXNzV2l0aFMyQ2VsbHModXBkYXRlZCkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN0YXRlQ2hhbmdlID0gKHN0YXRlTmFtZSkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWQgPSB7XG4gICAgICAuLi5hZGRyZXNzLFxuICAgICAgc3RhdGU6IHN0YXRlTmFtZSxcbiAgICAgIGNpdHk6IFwiXCIgLy8gUmVzZXQgY2l0eSBvbiBzdGF0ZSBjaGFuZ2VcbiAgICB9O1xuXG4gICAgaWYgKCFhZGRyZXNzLmlzTWFudWFsbHlFZGl0ZWQpIHtcbiAgICAgIHVwZGF0ZWQuZm9ybWF0dGVkQWRkcmVzcyA9IGJ1aWxkQWRkcmVzc1ByZXZpZXcodXBkYXRlZCkgfHwgc21hcnRBZGRyZXNzQnVpbGRlcihcbiAgICAgICAge1xuICAgICAgICAgIGhvdXNlX251bWJlcjogdXBkYXRlZC5ob3VzZU51bWJlcixcbiAgICAgICAgICByb2FkOiB1cGRhdGVkLnJvYWQsXG4gICAgICAgICAgcmVzaWRlbnRpYWw6IHVwZGF0ZWQuYXJlYSxcbiAgICAgICAgICBuZWlnaGJvdXJob29kOiB1cGRhdGVkLmFyZWEsXG4gICAgICAgICAgc3VidXJiOiB1cGRhdGVkLmFyZWEsXG4gICAgICAgICAgY2l0eTogdXBkYXRlZC5jaXR5LFxuICAgICAgICAgIHN0YXRlOiB1cGRhdGVkLnN0YXRlLFxuICAgICAgICAgIHBvc3Rjb2RlOiB1cGRhdGVkLnBpbmNvZGVcbiAgICAgICAgfSxcbiAgICAgICAgXCJcIlxuICAgICAgKTtcbiAgICB9XG5cbiAgICBvbkNoYW5nZShlbnJpY2hBZGRyZXNzV2l0aFMyQ2VsbHModXBkYXRlZCkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNpdHlDaGFuZ2UgPSAoY2l0eU5hbWUpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkID0ge1xuICAgICAgLi4uYWRkcmVzcyxcbiAgICAgIGNpdHk6IGNpdHlOYW1lXG4gICAgfTtcblxuICAgIGlmICghYWRkcmVzcy5pc01hbnVhbGx5RWRpdGVkKSB7XG4gICAgICB1cGRhdGVkLmZvcm1hdHRlZEFkZHJlc3MgPSBidWlsZEFkZHJlc3NQcmV2aWV3KHVwZGF0ZWQpIHx8IHNtYXJ0QWRkcmVzc0J1aWxkZXIoXG4gICAgICAgIHtcbiAgICAgICAgICBob3VzZV9udW1iZXI6IHVwZGF0ZWQuaG91c2VOdW1iZXIsXG4gICAgICAgICAgcm9hZDogdXBkYXRlZC5yb2FkLFxuICAgICAgICAgIHJlc2lkZW50aWFsOiB1cGRhdGVkLmFyZWEsXG4gICAgICAgICAgbmVpZ2hib3VyaG9vZDogdXBkYXRlZC5hcmVhLFxuICAgICAgICAgIHN1YnVyYjogdXBkYXRlZC5hcmVhLFxuICAgICAgICAgIGNpdHk6IHVwZGF0ZWQuY2l0eSxcbiAgICAgICAgICBzdGF0ZTogdXBkYXRlZC5zdGF0ZSxcbiAgICAgICAgICBwb3N0Y29kZTogdXBkYXRlZC5waW5jb2RlXG4gICAgICAgIH0sXG4gICAgICAgIFwiXCJcbiAgICAgICk7XG4gICAgfVxuXG4gICAgb25DaGFuZ2UoZW5yaWNoQWRkcmVzc1dpdGhTMkNlbGxzKHVwZGF0ZWQpKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjb21wYWN0ID8gJ3NwYWNlLXktMi41JyA6ICdzcGFjZS15LTQnfSAke2NsYXNzTmFtZX1gfT5cbiAgICAgIHsvKiBMYWJlbCBTZWxlY3Rpb24gUm93ICovfVxuICAgICAge3Nob3dMYWJlbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41IHBiLTIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwLjVweF0gZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+TEFCRUw6PC9sYWJlbD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICB7W1xuICAgICAgICAgICAgICB7IGlkOiAnSG9tZScsIGxhYmVsOiAnSG9tZScsIGljb246IEhvbWUgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ09mZmljZScsIGxhYmVsOiAnT2ZmaWNlJywgaWNvbjogQnJpZWZjYXNlIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdTaG9wJywgbGFiZWw6ICdTaG9wJywgaWNvbjogU2hvcHBpbmdCYWcgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ090aGVyJywgbGFiZWw6ICdPdGhlcicsIGljb246IE1hcFBpbiB9XG4gICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBJY29uQ29tcCA9IGl0ZW0uaWNvbjtcbiAgICAgICAgICAgICAgY29uc3QgaXNTZWwgPSAoYWRkcmVzcy5sYWJlbCB8fCAnSG9tZScpID09PSBpdGVtLmlkO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRmllbGRDaGFuZ2UoJ2xhYmVsJywgaXRlbS5pZCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMSByb3VuZGVkLWxnIGJvcmRlciB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICBpc1NlbFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1wcmltYXJ5IGJnLXByaW1hcnkvMTAgdGV4dC1wcmltYXJ5IHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTYwMCBob3Zlcjpib3JkZXItZ3JheS0zMDAgYmctd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8SWNvbkNvbXAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAge2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogU2VjdGlvbiBIZWFkZXIgd2l0aCBNYXAgU2VsZWN0b3IgVHJpZ2dlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyICR7Y29tcGFjdCA/ICdwYi0xIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCcgOiAncGItMiBib3JkZXItYiBib3JkZXItZ3JheS0xNTAnfWB9PlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkFkZHJlc3MgRGV0YWlsczwvc3Bhbj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTWFwTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXJlZC01MDAgaG92ZXI6YmctcmVkLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCAke2NvbXBhY3QgPyAncC0xLjUgc2hhZG93LW1kJyA6ICdwLTIuNSBzaGFkb3ctbGcnfSBzaGFkb3ctcmVkLTUwMC8yMCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJgfVxuICAgICAgICAgIHRpdGxlPVwiU2VsZWN0IExvY2F0aW9uIG9uIE1hcFwiXG4gICAgICAgID5cbiAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT17Y29tcGFjdCA/IFwidy0zLjUgaC0zLjVcIiA6IFwidy01IGgtNVwifSAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUm93IDE6IEhvdXNlIE5vLiAmIFJvYWQgTmFtZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZ3JpZCBncmlkLWNvbHMtMiAke2NvbXBhY3QgPyAnZ2FwLTInIDogJ2dhcC0zJ31gfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0wLjUgdy1mdWxsXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHNtOnRleHQtWzEwLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0cnVuY2F0ZVwiPkhvdXNlIC8gRmxhdCBOby4gKjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBuYW1lPVwiaG91c2VOdW1iZXJcIlxuICAgICAgICAgICAgdmFsdWU9e2FkZHJlc3MuaG91c2VOdW1iZXIgfHwgJyd9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpZWxkQ2hhbmdlKCdob3VzZU51bWJlcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSG91c2UgTm8uLCBGbGF0IDRCXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCAke2NvbXBhY3QgPyAncHgtMiBweS0xIHRleHQteHMnIDogJ3B4LTMgcHktMiB0ZXh0LXNtJ30gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwIGJnLXdoaXRlIHRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtYH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0wLjUgdy1mdWxsXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHNtOnRleHQtWzEwLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0cnVuY2F0ZVwiPlJvYWQgLyBTdHJlZXQgKjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBuYW1lPVwicm9hZFwiXG4gICAgICAgICAgICB2YWx1ZT17YWRkcmVzcy5yb2FkIHx8ICcnfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWVsZENoYW5nZSgncm9hZCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTUcgUm9hZCwgUGhhc2UgMVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgJHtjb21wYWN0ID8gJ3B4LTIgcHktMSB0ZXh0LXhzJyA6ICdweC0zIHB5LTIgdGV4dC1zbSd9IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeS8yMCBiZy13aGl0ZSB0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFJvdyAyOiBMYW5kbWFyayAmIEFyZWEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YGdyaWQgZ3JpZC1jb2xzLTIgJHtjb21wYWN0ID8gJ2dhcC0yJyA6ICdnYXAtMyd9YH0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMC41IHctZnVsbFwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LVsxMC41cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdHJ1bmNhdGVcIj5MYW5kbWFyayAoT3B0aW9uYWwpPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIG5hbWU9XCJsYW5kbWFya1wiXG4gICAgICAgICAgICB2YWx1ZT17YWRkcmVzcy5sYW5kbWFyayB8fCAnJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmllbGRDaGFuZ2UoJ2xhbmRtYXJrJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOZWFyIFRlbXBsZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgJHtjb21wYWN0ID8gJ3B4LTIgcHktMSB0ZXh0LXhzJyA6ICdweC0zIHB5LTIgdGV4dC1zbSd9IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeS8yMCBiZy13aGl0ZSB0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMC41IHctZnVsbFwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBzbTp0ZXh0LVsxMC41cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zZWNvbmRhcnkgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdHJ1bmNhdGVcIj5BcmVhIC8gTG9jYWxpdHk8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgbmFtZT1cImFyZWFcIlxuICAgICAgICAgICAgdmFsdWU9e2FkZHJlc3MuYXJlYSB8fCAnJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmllbGRDaGFuZ2UoJ2FyZWEnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlY3RvciAxNVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgJHtjb21wYWN0ID8gJ3B4LTIgcHktMSB0ZXh0LXhzJyA6ICdweC0zIHB5LTIgdGV4dC1zbSd9IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHJpbWFyeS8yMCBiZy13aGl0ZSB0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFJvdyAzOiBTdGF0ZSAmIENpdHkgJiBQaW5jb2RlIFNlbGVjdG9yICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0zICR7Y29tcGFjdCA/ICdnYXAtMicgOiAnZ2FwLTMnfWB9PlxuICAgICAgICB7LyogU3RhdGUgU2VsZWN0aW9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTAuNSB3LWZ1bGxcIj5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInN0YXRlXCIgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gc206dGV4dC1bMTAuNXB4XSBmb250LXNlbWlib2xkIHRleHQtc2Vjb25kYXJ5IHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+U3RhdGUgKjwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTIgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdy0zIGgtM1wiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgaWQ9XCJzdGF0ZVwiXG4gICAgICAgICAgICAgIG5hbWU9XCJzdGF0ZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXthZGRyZXNzLnN0YXRlIHx8ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVN0YXRlQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsICR7Y29tcGFjdCA/ICdwbC02IHByLTYgcHktMSB0ZXh0LXhzJyA6ICdwbC04IHByLTggcHktMiB0ZXh0LXNtJ30gYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHRleHQtc2Vjb25kYXJ5IGZvY3VzOmJvcmRlci1wcmltYXJ5IGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjAgdHJhbnNpdGlvbi1hbGwgZm9udC1tZWRpdW0gYXBwZWFyYW5jZS1ub25lYH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlN0YXRlPC9vcHRpb24+XG4gICAgICAgICAgICAgIHthZGRyZXNzLnN0YXRlICYmICFzdGF0ZXMuc29tZShzID0+IHMubmFtZSA9PT0gYWRkcmVzcy5zdGF0ZSkgJiYgKFxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9e2FkZHJlc3Muc3RhdGV9PnthZGRyZXNzLnN0YXRlfTwvb3B0aW9uPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICB7c3RhdGVzLm1hcCgoc3RhdGUpID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17c3RhdGUuaXNvQ29kZX0gdmFsdWU9e3N0YXRlLm5hbWV9PlxuICAgICAgICAgICAgICAgICAge3N0YXRlLm5hbWV9XG4gICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC0wIHByLTIgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ2l0eSBTZWxlY3Rpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMC41IHctZnVsbFwiPlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY2l0eVwiIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHNtOnRleHQtWzEwLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPkNpdHkgKjwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTIgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICA8QnVpbGRpbmcgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICBpZD1cImNpdHlcIlxuICAgICAgICAgICAgICBuYW1lPVwiY2l0eVwiXG4gICAgICAgICAgICAgIHZhbHVlPXthZGRyZXNzLmNpdHkgfHwgJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2l0eUNoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCAke2NvbXBhY3QgPyAncGwtNiBwci02IHB5LTEgdGV4dC14cycgOiAncGwtOCBwci04IHB5LTIgdGV4dC1zbSd9IGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyB0ZXh0LXNlY29uZGFyeSBmb2N1czpib3JkZXItcHJpbWFyeSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5LzIwIHRyYW5zaXRpb24tYWxsIGZvbnQtbWVkaXVtIGFwcGVhcmFuY2Utbm9uZSBkaXNhYmxlZDpiZy1ncmF5LTUwIGRpc2FibGVkOnRleHQtZ3JheS00MDBgfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17IWFkZHJlc3Muc3RhdGV9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5DaXR5PC9vcHRpb24+XG4gICAgICAgICAgICAgIHthZGRyZXNzLmNpdHkgJiYgIWNpdGllcy5zb21lKGMgPT4gYy5uYW1lID09PSBhZGRyZXNzLmNpdHkpICYmIChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXthZGRyZXNzLmNpdHl9PnthZGRyZXNzLmNpdHl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIHtjaXRpZXMubWFwKChjaXR5KSA9PiAoXG4gICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NpdHkubmFtZX0gdmFsdWU9e2NpdHkubmFtZX0+XG4gICAgICAgICAgICAgICAgICB7Y2l0eS5uYW1lfVxuICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBwci0yIGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFBpbmNvZGUgU2VsZWN0aW9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTAuNSB3LWZ1bGwgY29sLXNwYW4tMiBzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHNtOnRleHQtWzEwLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNlY29uZGFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlBpbmNvZGUgKjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBuYW1lPVwicGluY29kZVwiXG4gICAgICAgICAgICB2YWx1ZT17YWRkcmVzcy5waW5jb2RlIHx8IGFkZHJlc3MucG9zdGFsQ29kZSB8fCAnJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmllbGRDaGFuZ2UoJ3BpbmNvZGUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjYtZGlnaXQgUGluY29kZVwiXG4gICAgICAgICAgICBtYXhMZW5ndGg9XCI2XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCAke2NvbXBhY3QgPyAncHgtMiBweS0xIHRleHQteHMnIDogJ3B4LTMgcHktMiB0ZXh0LXNtJ30gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjAgdGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gZm9udC1tb25vYH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUm93IDQ6IENhbGN1bGF0ZWQgQWRkcmVzcyBQcmV2aWV3IC8gRWRpdG9yICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0wLjVcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+QWRkcmVzcyBQcmV2aWV3IC8gRWRpdCBNYW51YWxseTwvbGFiZWw+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgIG5hbWU9XCJmb3JtYXR0ZWRBZGRyZXNzXCJcbiAgICAgICAgICB2YWx1ZT17YWRkcmVzcy5mb3JtYXR0ZWRBZGRyZXNzIHx8IGJ1aWxkQWRkcmVzc1ByZXZpZXcoYWRkcmVzcykgfHwgJyd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgIG9uQ2hhbmdlKGVucmljaEFkZHJlc3NXaXRoUzJDZWxscyh7XG4gICAgICAgICAgICAgIC4uLmFkZHJlc3MsXG4gICAgICAgICAgICAgIGZvcm1hdHRlZEFkZHJlc3M6IHZhbCxcbiAgICAgICAgICAgICAgaXNNYW51YWxseUVkaXRlZDogdHJ1ZVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJQbGVhc2UgZmlsbCBIb3VzZSBOby4gYW5kIFJvYWQgbmFtZSB0byBjb25zdHJ1Y3QgcHJldmlldywgb3IgZWRpdCBoZXJlIG1hbnVhbGx5Li4uXCJcbiAgICAgICAgICByb3dzPXtjb21wYWN0ID8gMSA6IDJ9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsICR7Y29tcGFjdCA/ICdwLTIgdGV4dC14cyBoLTEyJyA6ICdwLTMgdGV4dC14cyd9IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyB0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSBsZWFkaW5nLXJlbGF4ZWQgc2hhZG93LWlubmVyIHJlc2l6ZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkvMjAgZm9jdXM6b3V0bGluZS1ub25lYH1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7aXNNYXBNb2RhbE9wZW4gJiYgKFxuICAgICAgICA8TG9jYXRpb25QaWNrZXJNb2RhbFxuICAgICAgICAgIGlzT3Blbj17aXNNYXBNb2RhbE9wZW59XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNNYXBNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgIG9uTG9jYXRpb25TZWxlY3Q9eyhsb2MpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSB7XG4gICAgICAgICAgICAgIC4uLmFkZHJlc3MsXG4gICAgICAgICAgICAgIC4uLmxvY1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIG9uQ2hhbmdlKGVucmljaEFkZHJlc3NXaXRoUzJDZWxscyh1cGRhdGVkKSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBZGRyZXNzU2VsZWN0b3I7XG4iXSwiZmlsZSI6IkM6L1Byb2plY3QvU2VydmljZS9jbGllbnQvc3JjL2NvbXBvbmVudHMvQWRkcmVzc1NlbGVjdG9yLmpzeCJ9
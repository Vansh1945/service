import { getCachedTimeFormat, readCachedSystemSettings } from "/src/utils/systemSettingsCache.js";
import { latLngToS2CellId } from "/src/utils/s2Helper.js";
const FALLBACK = "--";
const parseClockTime = (time) => {
  if (!time || typeof time !== "string") return null;
  const match = time.trim().match(/^(\d{1,2}):(\d{1,2})(?::\d{1,2})?\s*(AM|PM)?$/i);
  if (!match) return null;
  let hour = Number(match[1]);
  const minute = Number(match[2]);
  const meridiem = match[3]?.toUpperCase();
  if (Number.isNaN(hour) || Number.isNaN(minute) || minute > 59) return null;
  if (meridiem) {
    if (hour < 1 || hour > 12) return null;
    if (meridiem === "PM" && hour !== 12) hour += 12;
    if (meridiem === "AM" && hour === 12) hour = 0;
  } else if (hour > 23) {
    return null;
  }
  return { hour, minute };
};
const formatClockTime = ({ hour, minute }, timeFormat = getCachedTimeFormat()) => {
  const formattedMinute = String(minute).padStart(2, "0");
  if (timeFormat === "24h") {
    return `${String(hour).padStart(2, "0")}:${formattedMinute}`;
  }
  const ampm = hour >= 12 ? "PM" : "AM";
  const formattedHour = hour % 12 || 12;
  return `${formattedHour}:${formattedMinute} ${ampm}`;
};
export { parseClockTime, formatClockTime };
export const formatDate = (date, options = {}) => {
  if (!date) return FALLBACK;
  try {
    const d = new Date(date);
    if (isNaN(d.getTime())) return FALLBACK;
    const settings = readCachedSystemSettings();
    const timezone = options.timezone || settings.timezone || "Asia/Kolkata";
    const locale = options.locale || settings.locale || "en-IN";
    return d.toLocaleDateString(locale, {
      day: "numeric",
      month: "short",
      year: "numeric",
      timeZone: timezone,
      ...options
    });
  } catch {
    return FALLBACK;
  }
};
export const fmtDate = formatDate;
export const fmtDateOnly = formatDate;
export const formatTime = (time) => {
  if (!time) return FALLBACK;
  try {
    const timeFormat = getCachedTimeFormat();
    if (time instanceof Date || typeof time === "string" && time.includes("T")) {
      const d = new Date(time);
      if (isNaN(d.getTime())) return FALLBACK;
      const settings = readCachedSystemSettings();
      const timezone = settings.timezone || "Asia/Kolkata";
      const locale = settings.locale || "en-IN";
      return d.toLocaleTimeString(locale, {
        hour: timeFormat === "24h" ? "2-digit" : "numeric",
        minute: "2-digit",
        hour12: timeFormat === "12h",
        timeZone: timezone
      });
    }
    if (typeof time === "string" && time.includes(":")) {
      const parsedTime = parseClockTime(time);
      if (!parsedTime) return FALLBACK;
      return formatClockTime(parsedTime, timeFormat);
    }
    return FALLBACK;
  } catch {
    return FALLBACK;
  }
};
export const formatDateTime = (date) => {
  if (!date) return FALLBACK;
  const d = formatDate(date);
  const t = formatTime(date);
  if (d === FALLBACK || t === FALLBACK) return FALLBACK;
  return `${d}, ${t}`;
};
export const fmtDateTime = formatDateTime;
export const formatRelativeTime = (timestamp) => {
  if (!timestamp) return "Never";
  try {
    const diffMs = Date.now() - new Date(timestamp).getTime();
    if (isNaN(diffMs)) return FALLBACK;
    const diffSec = Math.floor(diffMs / 1e3);
    if (diffSec < 5) return "Just now";
    if (diffSec < 60) return `${diffSec} sec ago`;
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin} min ago`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `${diffHr} hr ago`;
    const diffDay = Math.floor(diffHr / 24);
    if (diffDay < 7) return `${diffDay} d ago`;
    return formatDate(timestamp);
  } catch {
    return FALLBACK;
  }
};
export const fmtRelativeTime = formatRelativeTime;
const currencyFormatters = /* @__PURE__ */ new Map();
const numberFormatters = /* @__PURE__ */ new Map();
export const formatCurrency = (amount, options = {}) => {
  if (amount === null || amount === void 0 || amount === "" || isNaN(amount)) return FALLBACK;
  try {
    const settings = readCachedSystemSettings();
    const currency = options.currency || settings.defaultCurrency || "INR";
    const locale = options.locale || settings.locale || (currency === "INR" ? "en-IN" : "en-US");
    const num = Number(amount);
    if (isNaN(num)) return FALLBACK;
    const minDecimals = options.minDecimals ?? options.decimalPrecision ?? (options.alwaysShowDecimals === false ? 0 : 2);
    const maxDecimals = options.maxDecimals ?? options.decimalPrecision ?? 2;
    const cacheKey = `${locale}-${currency}-${minDecimals}-${maxDecimals}`;
    let formatter = currencyFormatters.get(cacheKey);
    if (!formatter) {
      formatter = new Intl.NumberFormat(locale, {
        style: "currency",
        currency,
        minimumFractionDigits: minDecimals,
        maximumFractionDigits: maxDecimals
      });
      currencyFormatters.set(cacheKey, formatter);
    }
    let formatted = formatter.format(num);
    if (settings.currencySymbol && !formatted.includes(settings.currencySymbol)) {
      const formattedNum = num.toLocaleString(locale, {
        minimumFractionDigits: minDecimals,
        maximumFractionDigits: maxDecimals
      });
      if (settings.currencyPosition === "suffix") {
        formatted = `${formattedNum} ${settings.currencySymbol}`;
      } else if (settings.currencyPosition === "prefix") {
        formatted = `${settings.currencySymbol}${formattedNum}`;
      }
    }
    return formatted;
  } catch {
    return FALLBACK;
  }
};
export const formatAmount = (amount, options = {}) => {
  if (amount === null || amount === void 0 || amount === "" || isNaN(amount)) return FALLBACK;
  const num = Number(amount);
  if (isNaN(num)) return FALLBACK;
  const minDec = options.minDecimals ?? options.decimalPrecision ?? options.decimals ?? 2;
  const maxDec = options.maxDecimals ?? options.decimalPrecision ?? options.decimals ?? 2;
  const locale = options.locale || "en-IN";
  if (options.raw || options.noSymbol) {
    const useGrouping = options.useGrouping ?? !options.noCommas;
    return num.toLocaleString(locale, {
      minimumFractionDigits: minDec,
      maximumFractionDigits: maxDec,
      useGrouping
    });
  }
  return formatCurrency(amount, {
    minDecimals: minDec,
    maxDecimals: maxDec,
    ...options
  });
};
export const formatFinancialReportAmount = (input, fieldOrOptions = {}, options = {}) => {
  let val = input;
  let opts = {};
  if (input && typeof input === "object" && typeof fieldOrOptions === "string") {
    val = input[fieldOrOptions];
    opts = options || {};
  } else if (typeof fieldOrOptions === "object") {
    opts = fieldOrOptions || {};
  }
  if (val === null || val === void 0 || val === "" || isNaN(val)) return FALLBACK;
  const showSymbol = opts.showSymbol ?? (!opts.raw && !opts.noSymbol);
  if (!showSymbol) {
    return formatAmount(val, { raw: true, decimals: 2, ...opts });
  }
  return formatCurrency(val, { alwaysShowDecimals: true, minDecimals: 2, maxDecimals: 2, ...opts });
};
export const fmtFinancialReport = formatFinancialReportAmount;
export const formatFinancialValue = formatFinancialReportAmount;
export const isMonetaryField = (key) => {
  if (!key || typeof key !== "string") return false;
  const k = key.toLowerCase();
  return (k.includes("amount") || k.includes("total") || k.includes("paid") || k.includes("earning") || k.includes("commission") || k.includes("discount") || k.includes("surcharge") || k.includes("fee") || k.includes("impact") || k.includes("value") || k.includes("subtotal") || k.includes("refund") || k.includes("payout") || k.includes("subsidy") || k.includes("reward") || k.includes("balance") || k.includes("collected") || k.includes("tax") || k.includes("gst") || k.includes("receivable") || k.includes("gross") || k.includes("net")) && !k.includes("rate") && !k.includes("percent") && !k.includes("percentage") && !k.includes("id") && !k.includes("count") && !k.includes("date") && !k.includes("status") && !k.includes("type") && !k.includes("code");
};
export const isMonetaryColumnKey = isMonetaryField;
export const isPercentageField = (key) => {
  if (!key || typeof key !== "string") return false;
  const k = key.toLowerCase();
  return k.includes("rate") || k.includes("percent") || k.includes("percentage");
};
export const isPercentageColumnKey = isPercentageField;
export const formatNumber = (num, options = {}) => {
  if (num === null || num === void 0 || num === "" || isNaN(num)) return FALLBACK;
  const n = Number(num);
  if (isNaN(n)) return FALLBACK;
  const settings = readCachedSystemSettings();
  const currency = settings.defaultCurrency || "INR";
  const locale = options.locale || settings.locale || (currency === "INR" ? "en-IN" : "en-US");
  if (options.compact || settings.compactNumbers) {
    if (locale === "en-IN") {
      const abs = Math.abs(n);
      if (abs >= 1e7) return `${(n / 1e7).toFixed(options.decimals ?? 1)}Cr`;
      if (abs >= 1e5) return `${(n / 1e5).toFixed(options.decimals ?? 1)}L`;
      if (abs >= 1e3) return `${(n / 1e3).toFixed(options.decimals ?? 1)}K`;
      return n.toString();
    } else {
      const abs = Math.abs(n);
      if (abs >= 1e9) return `${(n / 1e9).toFixed(options.decimals ?? 1)}B`;
      if (abs >= 1e6) return `${(n / 1e6).toFixed(options.decimals ?? 1)}M`;
      if (abs >= 1e3) return `${(n / 1e3).toFixed(options.decimals ?? 1)}K`;
      return n.toString();
    }
  }
  const minDecimals = options.minDecimals ?? options.decimals ?? (options.forceDecimals ? 2 : 0);
  const maxDecimals = options.maxDecimals ?? options.decimals ?? (options.forceDecimals ? 2 : 2);
  const cacheKey = `${locale}-${minDecimals}-${maxDecimals}`;
  let formatter = numberFormatters.get(cacheKey);
  if (!formatter) {
    formatter = new Intl.NumberFormat(locale, {
      minimumFractionDigits: minDecimals,
      maximumFractionDigits: maxDecimals
    });
    numberFormatters.set(locale, formatter);
  }
  return formatter.format(n);
};
export const formatPercentage = (value, decimals = 1) => {
  if (value === null || value === void 0 || value === "" || isNaN(value)) return FALLBACK;
  return `${parseFloat(value).toFixed(decimals)}%`;
};
export const formatPercent = formatPercentage;
export const formatPhone = (phone) => {
  if (!phone) return FALLBACK;
  const settings = readCachedSystemSettings();
  const companyPhone = settings.phone || "";
  let countryCode = "+91";
  if (companyPhone.startsWith("+")) {
    const match = companyPhone.match(/^(\+\d{1,4})/);
    if (match) countryCode = match[1];
  }
  const cleaned = ("" + phone).replace(/\D/g, "");
  if (cleaned.length === 10) {
    return `${countryCode} ${cleaned.slice(0, 5)} ${cleaned.slice(5)}`;
  }
  if (cleaned.length === 12 && cleaned.startsWith("91")) {
    return `${countryCode} ${cleaned.slice(2, 7)} ${cleaned.slice(7)}`;
  }
  return phone;
};
export const formatEmail = (email) => {
  if (!email || typeof email !== "string") return FALLBACK;
  const trimmed = email.trim().toLowerCase();
  return trimmed || FALLBACK;
};
export const formatDuration = (hours) => {
  if (hours === null || hours === void 0 || isNaN(hours) || hours <= 0) return FALLBACK;
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  const hDisplay = h > 0 ? `${h} hr` : "";
  const mDisplay = m > 0 ? `${m} min` : "";
  return `${hDisplay} ${mDisplay}`.trim() || FALLBACK;
};
export const formatDistance = (metersOrKm, isKm = false) => {
  if (metersOrKm === null || metersOrKm === void 0 || isNaN(metersOrKm)) return FALLBACK;
  const meters = isKm ? metersOrKm * 1e3 : metersOrKm;
  if (meters < 1e3) {
    return `${Math.round(meters)} m`;
  }
  return `${(meters / 1e3).toFixed(1)} km`;
};
export const formatFileSize = (bytes) => {
  if (bytes === null || bytes === void 0 || isNaN(bytes) || bytes < 0) return FALLBACK;
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
};
export const truncateId = (id, chars = 14) => {
  if (!id) return FALLBACK;
  const str = String(id).trim();
  if (str.length <= chars) return str;
  return `${str.slice(0, chars)}…`;
};
export const formatBookingId = (id) => id ? String(id).startsWith("BK-") ? String(id) : `BK-${truncateId(id, 10)}` : FALLBACK;
export const formatPaymentId = (id) => id ? String(id).startsWith("pay_") ? String(id) : truncateId(id, 14) : FALLBACK;
export const formatTransactionId = (id) => id ? String(id).startsWith("TXN-") ? String(id) : `TXN-${truncateId(id, 10)}` : FALLBACK;
export const formatRefundId = (id) => id ? String(id).startsWith("rfnd_") || String(id).startsWith("RFD-") ? String(id) : `RFD-${truncateId(id, 10)}` : FALLBACK;
export const formatSettlementId = (id) => id ? String(id).startsWith("STL-") || String(id).startsWith("set_") ? String(id) : `STL-${truncateId(id, 10)}` : FALLBACK;
export const formatWithdrawalId = (id) => id ? String(id).startsWith("WTD-") || String(id).startsWith("pout_") ? String(id) : `WTD-${truncateId(id, 10)}` : FALLBACK;
export const formatWalletId = (id) => id ? String(id).startsWith("WAL-") ? String(id) : `WAL-${truncateId(id, 10)}` : FALLBACK;
export const formatProviderId = (id) => id ? String(id).startsWith("PRV-") ? String(id) : `PRV-${truncateId(id, 10)}` : FALLBACK;
export const formatCustomerId = (id) => id ? String(id).startsWith("CUST-") ? String(id) : `CUST-${truncateId(id, 10)}` : FALLBACK;
export const formatInvoiceId = (id) => id ? String(id).startsWith("INV-") ? String(id) : `INV-${truncateId(id, 10)}` : FALLBACK;
export const capitalize = (str) => {
  if (!str || typeof str !== "string") return "";
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};
const TITLE_CASE_ACRONYMS = /* @__PURE__ */ new Set(["ID", "UTR", "IFSC", "GST", "API", "PDF", "CSV", "XLSX", "URL", "UPI", "QR"]);
export const titleCase = (str) => {
  if (!str || typeof str !== "string") return "";
  return str.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]+/g, " ").split(" ").filter(Boolean).map((word) => {
    const upper = word.toUpperCase();
    if (TITLE_CASE_ACRONYMS.has(upper)) return upper;
    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }).join(" ");
};
export const safeValue = (val, fallback = FALLBACK) => {
  if (val === null || val === void 0 || val === "" || typeof val === "number" && isNaN(val)) {
    return fallback;
  }
  return val;
};
export const isEmptyValue = (val) => {
  if (val === null || val === void 0 || val === "") return true;
  if (Array.isArray(val)) return val.length === 0;
  if (typeof val === "object") return Object.keys(val).length === 0;
  return false;
};
export const copyToClipboard = async (text) => {
  if (!text) return false;
  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    const success = document.execCommand("copy");
    document.body.removeChild(textArea);
    return success;
  } catch (err) {
    console.error("Failed to copy to clipboard:", err);
    return false;
  }
};
export const downloadFile = (url, fileName = "download") => {
  if (!url) return;
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
export const getOptimizedCloudinaryUrl = (url, width = 800) => {
  if (!url || typeof url !== "string") return url;
  if (!url.startsWith("http") || !url.includes("res.cloudinary.com")) return url;
  if (url.includes("/s--")) return url;
  let cleanUrl = url;
  const uploadRegex = /\/(image\/upload|upload)\/([^/]+)\//;
  const match = cleanUrl.match(uploadRegex);
  if (match) {
    const transformStr = match[2];
    if (transformStr.includes("f_auto") || transformStr.includes("q_auto") || transformStr.includes("w_") || transformStr.includes("c_")) {
      cleanUrl = cleanUrl.replace(`/${match[1]}/${transformStr}/`, `/${match[1]}/`);
    }
  }
  const transform = `f_auto,q_auto,w_${width}`;
  if (cleanUrl.includes("/image/upload/")) {
    return cleanUrl.replace("/image/upload/", `/image/upload/${transform}/`);
  } else if (cleanUrl.includes("/upload/") && !cleanUrl.includes("/raw/upload/") && !cleanUrl.includes("/video/upload/")) {
    return cleanUrl.replace("/upload/", `/upload/${transform}/`);
  }
  return cleanUrl;
};
export const compressImage = (file, options = {}) => {
  return new Promise((resolve) => {
    const { maxWidth = 1600, maxHeight = 1600, quality = 0.82 } = options;
    if (!file || !file.type.startsWith("image/")) return resolve(file);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;
        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round(height * maxWidth / width);
            width = maxWidth;
          } else {
            width = Math.round(width * maxHeight / height);
            height = maxHeight;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob((blob) => {
          if (!blob) return resolve(file);
          const compressedFile = new File([blob], file.name.replace(/\.[^/.]+$/, "") + ".jpeg", {
            type: "image/jpeg",
            lastModified: Date.now()
          });
          resolve(compressedFile.size < file.size ? compressedFile : file);
        }, "image/jpeg", quality);
      };
      img.onerror = () => resolve(file);
      img.src = event.target.result;
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
};
export const buildAddressPreview = (address = {}) => {
  const cleanPart = (val) => {
    if (!val) return "";
    return val.toString().replace(/[\u0900-\u097F\u0A00-\u0A7F]/g, "").replace(/\s+district$/i, "").replace(/^[,.\s-]+|[,.\s-]+$/g, "").trim();
  };
  const houseNumber = cleanPart(address.houseNumber || address.house_number || address.house || address.flat || address.apartment || address.unit || address.office);
  const road = cleanPart(address.road || address.streetName || address.street || address.footway || address.path);
  const landmark = cleanPart(address.landmark);
  const area = cleanPart(address.area || address.locality || address.residential || address.neighbourhood || address.suburb || address.quarter || address.hamlet || address.village);
  const city = cleanPart(address.city || address.town || address.municipality || address.city_district || address.county || address.state_district);
  const pincode = cleanPart(address.pincode || address.postalCode || address.postcode || address.postal_code);
  const parts = [];
  for (const part of [houseNumber, road, landmark, area, city, pincode]) {
    if (!part) continue;
    const partLower = part.toLowerCase();
    let duplicateIndex = -1;
    const isDuplicate = parts.some((existing, index) => {
      const existingLower = existing.toLowerCase();
      const matched = existingLower === partLower || existingLower.includes(partLower) || partLower.includes(existingLower);
      if (matched) duplicateIndex = index;
      return matched;
    });
    if (isDuplicate) {
      if (duplicateIndex !== -1 && part.length > parts[duplicateIndex].length) {
        parts[duplicateIndex] = part;
      }
    } else {
      parts.push(part);
    }
  }
  return parts.join(", ");
};
export const formatAddress = (address) => {
  if (!address) return FALLBACK;
  if (typeof address === "string") return address.trim() || FALLBACK;
  if (typeof address === "object") {
    const preview = buildAddressPreview(address);
    if (preview) return preview;
    return [address.street || address.addressLine, address.city, address.state, address.postalCode || address.pincode, address.country].filter(Boolean).join(", ") || FALLBACK;
  }
  return FALLBACK;
};
export const smartAddressBuilder = (addressObj, displayName = "") => {
  const addr = addressObj || {};
  const cleanPart = (val) => {
    if (!val) return "";
    let s = val.toString().trim();
    s = s.replace(/[\u0900-\u097F\u0A00-\u0A7F]/g, "");
    s = s.replace(/^[,.\s-]+|[,.\s-]+$/g, "").trim();
    return s;
  };
  const isUnwanted = (val) => {
    if (!val) return true;
    const s = val.toString().toLowerCase();
    return s.includes("tahsil") || s.includes("tehsil") || s.includes("तहसील") || s.includes("ਤਹਿਸੀਲ") || s.includes("taluk") || s.includes("taluka") || s.includes("subdistrict") || s.includes("sub-district") || s === "india" || s === "county" || s === "state district" || s === "district" || s === "state_district" || /[\u0900-\u097F\u0A00-\u0A7F]/.test(val);
  };
  let houseNo = cleanPart(addr.house_number || addr.house || addr.flat || addr.apartment || addr.unit || addr.office);
  let building = cleanPart(addr.building || addr.apartments || addr.amenity);
  let road = cleanPart(addr.road || addr.street || addr.footway || addr.path);
  let locality = cleanPart(addr.suburb) || cleanPart(addr.neighbourhood) || cleanPart(addr.residential) || cleanPart(addr.quarter) || cleanPart(addr.hamlet) || "";
  let city = cleanPart(addr.city || addr.town || addr.municipality || addr.city_district || addr.village || addr.county || addr.state_district).replace(/\s+district$/i, "").trim();
  let state = cleanPart(addr.state);
  let pincode = cleanPart(addr.postcode || addr.postal_code);
  const fallbackList = [houseNo, building, road, locality].filter(Boolean);
  const getFallback = (val) => val && val.trim() ? val : fallbackList[0] || "";
  houseNo = getFallback(houseNo);
  building = getFallback(building);
  road = getFallback(road);
  locality = getFallback(locality);
  if (isUnwanted(houseNo)) houseNo = "";
  if (isUnwanted(building)) building = "";
  if (isUnwanted(road)) road = "";
  if (isUnwanted(locality)) locality = "";
  if (isUnwanted(city)) city = "";
  if (isUnwanted(state)) state = "";
  const parts = [];
  let houseBuildingPart = [houseNo, building].filter(Boolean).join(", ");
  if (houseNo && building && (houseNo.toLowerCase().includes(building.toLowerCase()) || building.toLowerCase().includes(houseNo.toLowerCase()))) {
    houseBuildingPart = houseNo.length > building.length ? houseNo : building;
  }
  if (houseBuildingPart) parts.push(houseBuildingPart);
  if (road) parts.push(road);
  if (displayName) {
    const displayParts = displayName.split(",").map(cleanPart).filter((p) => p && !isUnwanted(p));
    const cityLower = city ? city.toLowerCase() : "";
    const stateLower = state ? state.toLowerCase() : "";
    for (const dp of displayParts) {
      const dpLower = dp.toLowerCase();
      if (dpLower.includes("phase") || dpLower.includes("sector") || dpLower.includes("block") || dpLower.includes("colony") || dpLower.includes("estate") || dpLower.includes("town") || dpLower.includes("urban")) {
        const matched = parts.some((p) => p.toLowerCase().includes(dpLower) || dpLower.includes(p.toLowerCase()));
        if (!matched && dpLower !== cityLower && dpLower !== stateLower) parts.push(dp);
      }
    }
  }
  if (locality && !parts.some((p) => p.toLowerCase().includes(locality.toLowerCase()) || locality.toLowerCase().includes(p.toLowerCase()))) parts.push(locality);
  if (city && !parts.some((p) => p.toLowerCase().includes(city.toLowerCase()) || city.toLowerCase().includes(p.toLowerCase()))) parts.push(city);
  if (state) {
    const matched = parts.some((p) => p.toLowerCase().includes(state.toLowerCase()) || state.toLowerCase().includes(p.toLowerCase()));
    let stateString = pincode ? `${state} ${pincode}` : state;
    if (!matched) parts.push(stateString);
    else {
      const idx = parts.findIndex((p) => p.toLowerCase().includes(state.toLowerCase()));
      if (idx !== -1) parts[idx] = stateString;
    }
  } else if (pincode) parts.push(pincode);
  const uniqueParts = [];
  for (const part of parts) {
    if (!uniqueParts.some((p) => p.toLowerCase() === part.toLowerCase())) uniqueParts.push(part);
  }
  return uniqueParts.join(", ");
};
export const cleanAddressFields = (addressObj, displayName = "") => {
  const addr = addressObj || {};
  const cleanPart = (val) => {
    if (!val) return "";
    let s = val.toString().trim();
    s = s.replace(/[\u0900-\u097F\u0A00-\u0A7F]/g, "").replace(/^[,.\s-]+|[,.\s-]+$/g, "").trim();
    return s;
  };
  const isUnwanted = (val) => {
    if (!val) return true;
    const s = val.toString().toLowerCase();
    return s.includes("tahsil") || s.includes("tehsil") || s.includes("subdistrict") || s === "india" || s === "county" || s === "district" || /[\u0900-\u097F\u0A00-\u0A7F]/.test(val);
  };
  let houseNo = cleanPart(addr.house_number || addr.house || addr.flat || addr.apartment || addr.unit || addr.office);
  let building = cleanPart(addr.building || addr.apartments || addr.amenity);
  let road = cleanPart(addr.road || addr.street || addr.footway || addr.path);
  let residential = cleanPart(addr.residential || addr.development);
  let neighbourhood = cleanPart(addr.neighbourhood || addr.quarter);
  let suburb = cleanPart(addr.suburb || addr.village || addr.townland);
  let quarter = cleanPart(addr.quarter);
  let hamlet = cleanPart(addr.hamlet);
  let landmark = cleanPart(addr.landmark || addr.place || addr.commercial || addr.industrial);
  let city = cleanPart(addr.city || addr.town || addr.municipality || addr.city_district || addr.village || addr.county || addr.state_district).replace(/\s+district$/i, "").trim();
  let state = cleanPart(addr.state);
  let pincode = cleanPart(addr.postcode || addr.postal_code);
  let locality = suburb || neighbourhood || residential || quarter || hamlet || "";
  let area = locality || "";
  const fallbackList = [houseNo, building, road, residential, suburb, neighbourhood].filter(Boolean);
  const getFallback = (val) => val && val.trim() ? val : fallbackList[0] || "";
  let finalHouseNumber = getFallback(houseNo);
  let finalBuilding = getFallback(building);
  let finalRoad = getFallback(road);
  let finalLocality = getFallback(locality);
  let finalLandmark = getFallback(landmark);
  let finalArea = getFallback(area);
  let finalCity = city || locality || "";
  let finalState = state || "";
  let finalPincode = pincode || "";
  if (isUnwanted(finalHouseNumber)) finalHouseNumber = "";
  if (isUnwanted(finalBuilding)) finalBuilding = "";
  if (isUnwanted(finalRoad)) finalRoad = "";
  if (isUnwanted(finalLocality)) finalLocality = "";
  if (isUnwanted(finalLandmark)) finalLandmark = "";
  if (isUnwanted(finalArea)) finalArea = "";
  if (isUnwanted(finalCity)) finalCity = "";
  if (isUnwanted(finalState)) finalState = "";
  finalHouseNumber = getFallback(finalHouseNumber);
  finalBuilding = getFallback(finalBuilding);
  finalRoad = getFallback(finalRoad);
  finalLocality = getFallback(finalLocality);
  finalArea = getFallback(finalArea);
  let candidates = [finalHouseNumber, finalBuilding, finalRoad, finalLocality].filter(Boolean);
  if (displayName) {
    const displayParts = displayName.split(",").map(cleanPart).filter((p) => p && !isUnwanted(p));
    const cityLower = finalCity.toLowerCase();
    const stateLower = finalState.toLowerCase();
    const pincodeLower = finalPincode.toLowerCase();
    for (const dp of displayParts) {
      const dpLower = dp.toLowerCase();
      if (dpLower === cityLower || dpLower === stateLower || dpLower === pincodeLower || cityLower && cityLower.includes(dpLower) || stateLower && stateLower.includes(dpLower)) continue;
      const alreadyMatched = candidates.some((c) => {
        const cLower = c.toLowerCase();
        return cLower.includes(dpLower) || dpLower.includes(cLower);
      });
      if (!alreadyMatched) {
        candidates.push(dp);
        if (!finalRoad) finalRoad = dp;
        else if (!finalLocality || finalLocality === finalRoad) finalLocality = dp;
      }
    }
  }
  const uniqueCandidates = [];
  for (const cand of candidates) {
    const candLower = cand.toLowerCase();
    let isDup = false;
    for (let i = 0; i < uniqueCandidates.length; i++) {
      const existingLower = uniqueCandidates[i].toLowerCase();
      if (existingLower === candLower || existingLower.includes(candLower)) {
        isDup = true;
        break;
      }
      if (candLower.includes(existingLower)) {
        uniqueCandidates[i] = cand;
        isDup = true;
        break;
      }
    }
    if (!isDup) uniqueCandidates.push(cand);
  }
  let streetAddress = uniqueCandidates.join(", ");
  const formattedAddress = smartAddressBuilder(addr, displayName);
  const fullAddressPreview = buildAddressPreview({
    houseNumber: finalHouseNumber,
    road: finalRoad,
    area: finalArea || finalLocality,
    city: finalCity,
    pincode: finalPincode
  });
  const hasGranularDetails = !!(houseNo || building || road || residential || neighbourhood || suburb || quarter || hamlet || landmark);
  return {
    street: streetAddress || finalRoad || formattedAddress || "",
    city: finalCity,
    state: finalState,
    postalCode: finalPincode,
    pincode: finalPincode,
    addressLine: streetAddress || finalRoad || "",
    houseNumber: finalHouseNumber || "",
    building: finalBuilding || "",
    road: finalRoad || "",
    locality: finalLocality || "",
    landmark: finalLandmark || "",
    area: finalArea || finalLocality || "",
    country: cleanPart(addr.country) || "India",
    formattedAddress: fullAddressPreview || formattedAddress || streetAddress || "",
    isCityCenterOnly: !hasGranularDetails,
    lat: null,
    lng: null
  };
};
export const LIGHT_MAP_TILES = "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png";
export const LIGHT_MAP_ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';
const GEOCODE_CACHE = /* @__PURE__ */ new Map();
const GEOCODE_CACHE_TTL_MS = 5 * 60 * 1e3;
const GEOCODE_USER_AGENT = "RajServiceBooking/1.0 (service-booking-app)";
const coordCacheKey = (lat, lng) => `${Number(lat).toFixed(5)},${Number(lng).toFixed(5)}`;
const mergePhotonNominatim = (photonProps, nominatimAddr, displayName) => {
  const p = photonProps || {};
  const n = nominatimAddr || {};
  return {
    house_number: p.housenumber || n.house_number || n.house || "",
    building: p.name || n.building || n.apartments || "",
    road: p.street || n.road || n.street || n.footway || "",
    neighbourhood: n.neighbourhood || n.quarter || n.residential || "",
    suburb: p.district || n.suburb || n.city_district || "",
    city: p.city || n.city || n.town || n.municipality || n.city_district || n.village || n.county || n.state_district || "",
    state: p.state || n.state || "",
    postcode: p.postcode || n.postcode || "",
    country: p.country || n.country || "India",
    landmark: n.amenity || n.place || "",
    _displayName: displayName || ""
  };
};
export const reverseGeocode = async (lat, lng) => {
  const cacheKey = coordCacheKey(lat, lng);
  const cached = GEOCODE_CACHE.get(cacheKey);
  if (cached && Date.now() - cached.ts < GEOCODE_CACHE_TTL_MS) {
    return cached.data;
  }
  let photonProps = null;
  let nominatimAddr = null;
  let displayName = "";
  try {
    const nomRes = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1&accept-language=en`,
      { headers: { "User-Agent": GEOCODE_USER_AGENT } }
    );
    const nomJson = await nomRes.json();
    if (nomJson?.address) {
      nominatimAddr = nomJson.address;
      displayName = nomJson.display_name || "";
    }
  } catch {
  }
  if (!nominatimAddr) {
    try {
      const photonRes = await fetch(`https://photon.komoot.io/reverse?lat=${lat}&lon=${lng}&lang=en`);
      const photonJson = await photonRes.json();
      if (photonJson?.features?.[0]?.properties) {
        photonProps = photonJson.features[0].properties;
        const props = photonJson.features[0].properties;
        displayName = props.name || props.street || "";
        if (props.city) displayName += (displayName ? ", " : "") + props.city;
        if (props.state) displayName += (displayName ? ", " : "") + props.state;
      }
    } catch {
    }
  }
  let merged = mergePhotonNominatim(photonProps, nominatimAddr, displayName);
  let structured = cleanAddressFields(merged, displayName);
  structured.lat = lat;
  structured.lng = lng;
  GEOCODE_CACHE.set(cacheKey, { ts: Date.now(), data: structured });
  return structured;
};
export const detectCurrentLocation = (options = {}) => {
  const targetAccuracy = options.targetAccuracy ?? 80;
  const maxUpdates = options.maxUpdates ?? 2;
  const timeoutMs = options.timeout ?? 1e4;
  const maxRetries = options.maxRetries ?? 0;
  let retryCount = 0;
  const executeDetection = () => new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
      return;
    }
    let watchId = null;
    let updateCount = 0;
    let bestPos = null;
    const clearWatchSafe = () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
        watchId = null;
      }
    };
    const timeoutId = setTimeout(() => {
      clearWatchSafe();
      if (bestPos && bestPos.coords.accuracy <= targetAccuracy) {
        resolvePosition(bestPos);
      } else if (bestPos) {
        resolvePosition(bestPos);
      } else {
        navigator.geolocation.getCurrentPosition(
          (fallbackPos) => resolvePosition(fallbackPos),
          (fallbackErr) => reject(new Error("Location request timed out. Please select your address manually.")),
          { enableHighAccuracy: false, timeout: 3e3 }
        );
      }
    }, timeoutMs);
    const resolvePosition = async (pos) => {
      clearTimeout(timeoutId);
      clearWatchSafe();
      try {
        const { latitude, longitude, accuracy } = pos.coords;
        const address = await reverseGeocode(latitude, longitude);
        const s2CellId = latLngToS2CellId(latitude, longitude, 13);
        const s2CellIdPrecise = latLngToS2CellId(latitude, longitude, 20);
        resolve({ latitude, longitude, accuracy, address: { ...address, lat: latitude, lng: longitude, s2CellId, s2CellIdPrecise } });
      } catch (err) {
        reject(err);
      }
    };
    watchId = navigator.geolocation.watchPosition(
      (pos) => {
        updateCount++;
        if (!bestPos || pos.coords.accuracy < bestPos.coords.accuracy) {
          bestPos = pos;
        }
        if (pos.coords.accuracy <= targetAccuracy || updateCount >= maxUpdates) {
          resolvePosition(bestPos || pos);
        }
      },
      (err) => {
        clearTimeout(timeoutId);
        clearWatchSafe();
        if (err.code === 2 || err.code === 3) {
          navigator.geolocation.getCurrentPosition(
            (fallbackPos) => resolvePosition(fallbackPos),
            (fallbackErr) => reject(new Error("Location unavailable. Please select your address manually.")),
            { enableHighAccuracy: false, timeout: 3e3 }
          );
        } else {
          reject(new Error("Location permission denied. Enable GPS in browser settings."));
        }
      },
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 0 }
    );
  });
  return executeDetection();
};
export const toLegacyAddressFields = (structured) => {
  const lat = structured.lat;
  const lng = structured.lng;
  const s2CellId = lat && lng ? latLngToS2CellId(lat, lng, 13) : structured.s2CellId || null;
  const s2CellIdPrecise = lat && lng ? latLngToS2CellId(lat, lng, 20) : structured.s2CellIdPrecise || null;
  const formattedAddress = buildAddressPreview(structured) || structured.formattedAddress || smartAddressBuilder(structured, "");
  return {
    street: structured.street || structured.addressLine || formattedAddress || "",
    city: structured.city || "",
    state: structured.state || "",
    postalCode: structured.postalCode || structured.pincode || "",
    country: structured.country || "India",
    lat,
    lng,
    s2CellId,
    s2CellIdPrecise,
    addressLine: structured.addressLine || structured.street || "",
    houseNumber: structured.houseNumber || "",
    road: structured.road || "",
    landmark: structured.landmark || "",
    area: structured.area || "",
    pincode: structured.pincode || structured.postalCode || "",
    formattedAddress
  };
};
export const filterGPSJitter = (prev, next, minMeters = 8) => {
  if (!prev || prev.lat == null || prev.lng == null) return next;
  const R = 6371e3;
  const dLat = (next.lat - prev.lat) * Math.PI / 180;
  const dLng = (next.lng - prev.lng) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(prev.lat * Math.PI / 180) * Math.cos(next.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  const dist = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return dist < minMeters ? prev : next;
};
export const calculateBearing = (lat1, lon1, lat2, lon2) => {
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const lat1Rad = lat1 * Math.PI / 180;
  const lat2Rad = lat2 * Math.PI / 180;
  const y = Math.sin(dLon) * Math.cos(lat2Rad);
  const x = Math.cos(lat1Rad) * Math.sin(lat2Rad) - Math.sin(lat1Rad) * Math.cos(lat2Rad) * Math.cos(dLon);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
};
export const buildStreetAddress = (houseNumber, road) => {
  const houseNum = (houseNumber || "").trim();
  const rd = (road || "").trim();
  return houseNum && rd ? `${houseNum}, ${rd}` : houseNum || rd;
};
const BANK_NAMES = {
  PUNB: "Punjab National Bank",
  HDFC: "HDFC Bank",
  SBIN: "State Bank of India",
  ICIC: "ICICI Bank",
  UTIB: "Axis Bank",
  AXIS: "Axis Bank",
  KKBK: "Kotak Mahindra Bank",
  BARB: "Bank of Baroda",
  CNRB: "Canara Bank",
  UBIN: "Union Bank of India",
  IDIB: "Indian Bank",
  BKID: "Bank of India",
  IOBA: "Indian Overseas Bank",
  MAHB: "Bank of Maharashtra",
  PSIB: "Punjab & Sind Bank",
  UCOB: "UCO Bank",
  CUB: "City Union Bank",
  CSB: "CSB Bank",
  DCB: "DCB Bank",
  DLXB: "Dhanlaxmi Bank",
  FDRL: "Federal Bank",
  IDFB: "IDFC First Bank",
  INDB: "IndusInd Bank",
  INDUS: "IndusInd Bank",
  JAKA: "Jammu & Kashmir Bank",
  KARB: "Karnataka Bank",
  KVBL: "Karur Vysya Bank",
  KVB: "Karur Vysya Bank",
  NAIN: "Nainital Bank",
  RBL: "RBL Bank",
  SIBL: "South Indian Bank",
  TMBL: "Tamilnad Mercantile Bank",
  YESB: "YES Bank",
  BDBL: "Bandhan Bank",
  AUBL: "AU Small Finance Bank",
  ESFB: "Equitas Small Finance Bank",
  USFB: "Ujjivan Small Finance Bank",
  AIRP: "Airtel Payments Bank",
  IPPB: "India Post Payments Bank",
  PYTM: "Paytm Payments Bank"
};
export const formatBankName = (code) => {
  if (!code) return "N/A";
  const cleanCode = String(code).trim().toUpperCase();
  const baseCode = cleanCode.replace(/_[A-Z0-9]+$/, "");
  const bankName = BANK_NAMES[cleanCode] || BANK_NAMES[baseCode];
  if (bankName) {
    return `${bankName} (${cleanCode})`;
  }
  return cleanCode;
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0EsU0FBU0EscUJBQXFCQyxnQ0FBZ0M7QUFDOUQsU0FBU0Msd0JBQXdCO0FBRWpDLE1BQU1DLFdBQVc7QUFNakIsTUFBTUMsaUJBQWlCQSxDQUFDQyxTQUFTO0FBQy9CLE1BQUksQ0FBQ0EsUUFBUSxPQUFPQSxTQUFTLFNBQVUsUUFBTztBQUM5QyxRQUFNQyxRQUFRRCxLQUFLRSxLQUFLLEVBQUVELE1BQU0sZ0RBQWdEO0FBQ2hGLE1BQUksQ0FBQ0EsTUFBTyxRQUFPO0FBRW5CLE1BQUlFLE9BQU9DLE9BQU9ILE1BQU0sQ0FBQyxDQUFDO0FBQzFCLFFBQU1JLFNBQVNELE9BQU9ILE1BQU0sQ0FBQyxDQUFDO0FBQzlCLFFBQU1LLFdBQVdMLE1BQU0sQ0FBQyxHQUFHTSxZQUFZO0FBRXZDLE1BQUlILE9BQU9JLE1BQU1MLElBQUksS0FBS0MsT0FBT0ksTUFBTUgsTUFBTSxLQUFLQSxTQUFTLEdBQUksUUFBTztBQUV0RSxNQUFJQyxVQUFVO0FBQ1osUUFBSUgsT0FBTyxLQUFLQSxPQUFPLEdBQUksUUFBTztBQUNsQyxRQUFJRyxhQUFhLFFBQVFILFNBQVMsR0FBSUEsU0FBUTtBQUM5QyxRQUFJRyxhQUFhLFFBQVFILFNBQVMsR0FBSUEsUUFBTztBQUFBLEVBQy9DLFdBQVdBLE9BQU8sSUFBSTtBQUNwQixXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sRUFBRUEsTUFBTUUsT0FBTztBQUN4QjtBQUVBLE1BQU1JLGtCQUFrQkEsQ0FBQyxFQUFFTixNQUFNRSxPQUFPLEdBQUdLLGFBQWFmLG9CQUFvQixNQUFNO0FBQ2hGLFFBQU1nQixrQkFBa0JDLE9BQU9QLE1BQU0sRUFBRVEsU0FBUyxHQUFHLEdBQUc7QUFFdEQsTUFBSUgsZUFBZSxPQUFPO0FBQ3hCLFdBQU8sR0FBR0UsT0FBT1QsSUFBSSxFQUFFVSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUlGLGVBQWU7QUFBQSxFQUM1RDtBQUVBLFFBQU1HLE9BQU9YLFFBQVEsS0FBSyxPQUFPO0FBQ2pDLFFBQU1ZLGdCQUFnQlosT0FBTyxNQUFNO0FBQ25DLFNBQU8sR0FBR1ksYUFBYSxJQUFJSixlQUFlLElBQUlHLElBQUk7QUFDcEQ7QUFFQSxTQUFTZixnQkFBZ0JVO0FBWWxCLGFBQU1PLGFBQWFBLENBQUNDLE1BQU1DLFVBQVUsQ0FBQyxNQUFNO0FBQ2hELE1BQUksQ0FBQ0QsS0FBTSxRQUFPbkI7QUFDbEIsTUFBSTtBQUNGLFVBQU1xQixJQUFJLElBQUlDLEtBQUtILElBQUk7QUFDdkIsUUFBSVQsTUFBTVcsRUFBRUUsUUFBUSxDQUFDLEVBQUcsUUFBT3ZCO0FBRS9CLFVBQU13QixXQUFXMUIseUJBQXlCO0FBQzFDLFVBQU0yQixXQUFXTCxRQUFRSyxZQUFZRCxTQUFTQyxZQUFZO0FBQzFELFVBQU1DLFNBQVNOLFFBQVFNLFVBQVVGLFNBQVNFLFVBQVU7QUFHcEQsV0FBT0wsRUFBRU0sbUJBQW1CRCxRQUFRO0FBQUEsTUFDbENFLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsTUFBTTtBQUFBLE1BQ05DLFVBQVVOO0FBQUFBLE1BQ1YsR0FBR0w7QUFBQUEsSUFDTCxDQUFDO0FBQUEsRUFDSCxRQUFRO0FBQ04sV0FBT3BCO0FBQUFBLEVBQ1Q7QUFDRjtBQUVPLGFBQU1nQyxVQUFVZDtBQUNoQixhQUFNZSxjQUFjZjtBQU9wQixhQUFNZ0IsYUFBYUEsQ0FBQ2hDLFNBQVM7QUFDbEMsTUFBSSxDQUFDQSxLQUFNLFFBQU9GO0FBQ2xCLE1BQUk7QUFDRixVQUFNWSxhQUFhZixvQkFBb0I7QUFFdkMsUUFBSUssZ0JBQWdCb0IsUUFBUyxPQUFPcEIsU0FBUyxZQUFZQSxLQUFLaUMsU0FBUyxHQUFHLEdBQUk7QUFDNUUsWUFBTWQsSUFBSSxJQUFJQyxLQUFLcEIsSUFBSTtBQUN2QixVQUFJUSxNQUFNVyxFQUFFRSxRQUFRLENBQUMsRUFBRyxRQUFPdkI7QUFDL0IsWUFBTXdCLFdBQVcxQix5QkFBeUI7QUFDMUMsWUFBTTJCLFdBQVdELFNBQVNDLFlBQVk7QUFDdEMsWUFBTUMsU0FBU0YsU0FBU0UsVUFBVTtBQUVsQyxhQUFPTCxFQUFFZSxtQkFBbUJWLFFBQVE7QUFBQSxRQUNsQ3JCLE1BQU1PLGVBQWUsUUFBUSxZQUFZO0FBQUEsUUFDekNMLFFBQVE7QUFBQSxRQUNSOEIsUUFBUXpCLGVBQWU7QUFBQSxRQUN2Qm1CLFVBQVVOO0FBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFFQSxRQUFJLE9BQU92QixTQUFTLFlBQVlBLEtBQUtpQyxTQUFTLEdBQUcsR0FBRztBQUNsRCxZQUFNRyxhQUFhckMsZUFBZUMsSUFBSTtBQUN0QyxVQUFJLENBQUNvQyxXQUFZLFFBQU90QztBQUN4QixhQUFPVyxnQkFBZ0IyQixZQUFZMUIsVUFBVTtBQUFBLElBQy9DO0FBRUEsV0FBT1o7QUFBQUEsRUFDVCxRQUFRO0FBQ04sV0FBT0E7QUFBQUEsRUFDVDtBQUNGO0FBT08sYUFBTXVDLGlCQUFpQkEsQ0FBQ3BCLFNBQVM7QUFDdEMsTUFBSSxDQUFDQSxLQUFNLFFBQU9uQjtBQUNsQixRQUFNcUIsSUFBSUgsV0FBV0MsSUFBSTtBQUN6QixRQUFNcUIsSUFBSU4sV0FBV2YsSUFBSTtBQUN6QixNQUFJRSxNQUFNckIsWUFBWXdDLE1BQU14QyxTQUFVLFFBQU9BO0FBQzdDLFNBQU8sR0FBR3FCLENBQUMsS0FBS21CLENBQUM7QUFDbkI7QUFFTyxhQUFNQyxjQUFjRjtBQU9wQixhQUFNRyxxQkFBcUJBLENBQUNDLGNBQWM7QUFDL0MsTUFBSSxDQUFDQSxVQUFXLFFBQU87QUFDdkIsTUFBSTtBQUNGLFVBQU1DLFNBQVN0QixLQUFLdUIsSUFBSSxJQUFJLElBQUl2QixLQUFLcUIsU0FBUyxFQUFFcEIsUUFBUTtBQUN4RCxRQUFJYixNQUFNa0MsTUFBTSxFQUFHLFFBQU81QztBQUUxQixVQUFNOEMsVUFBVUMsS0FBS0MsTUFBTUosU0FBUyxHQUFJO0FBQ3hDLFFBQUlFLFVBQVUsRUFBRyxRQUFPO0FBQ3hCLFFBQUlBLFVBQVUsR0FBSSxRQUFPLEdBQUdBLE9BQU87QUFFbkMsVUFBTUcsVUFBVUYsS0FBS0MsTUFBTUYsVUFBVSxFQUFFO0FBQ3ZDLFFBQUlHLFVBQVUsR0FBSSxRQUFPLEdBQUdBLE9BQU87QUFFbkMsVUFBTUMsU0FBU0gsS0FBS0MsTUFBTUMsVUFBVSxFQUFFO0FBQ3RDLFFBQUlDLFNBQVMsR0FBSSxRQUFPLEdBQUdBLE1BQU07QUFFakMsVUFBTUMsVUFBVUosS0FBS0MsTUFBTUUsU0FBUyxFQUFFO0FBQ3RDLFFBQUlDLFVBQVUsRUFBRyxRQUFPLEdBQUdBLE9BQU87QUFFbEMsV0FBT2pDLFdBQVd5QixTQUFTO0FBQUEsRUFDN0IsUUFBUTtBQUNOLFdBQU8zQztBQUFBQSxFQUNUO0FBQ0Y7QUFFTyxhQUFNb0Qsa0JBQWtCVjtBQU0vQixNQUFNVyxxQkFBcUIsb0JBQUlDLElBQUk7QUFDbkMsTUFBTUMsbUJBQW1CLG9CQUFJRCxJQUFJO0FBUTFCLGFBQU1FLGlCQUFpQkEsQ0FBQ0MsUUFBUXJDLFVBQVUsQ0FBQyxNQUFNO0FBQ3RELE1BQUlxQyxXQUFXLFFBQVFBLFdBQVdDLFVBQWFELFdBQVcsTUFBTS9DLE1BQU0rQyxNQUFNLEVBQUcsUUFBT3pEO0FBQ3RGLE1BQUk7QUFDRixVQUFNd0IsV0FBVzFCLHlCQUF5QjtBQUMxQyxVQUFNNkQsV0FBV3ZDLFFBQVF1QyxZQUFZbkMsU0FBU29DLG1CQUFtQjtBQUNqRSxVQUFNbEMsU0FBU04sUUFBUU0sVUFBVUYsU0FBU0UsV0FBV2lDLGFBQWEsUUFBUSxVQUFVO0FBQ3BGLFVBQU1FLE1BQU12RCxPQUFPbUQsTUFBTTtBQUN6QixRQUFJL0MsTUFBTW1ELEdBQUcsRUFBRyxRQUFPN0Q7QUFFdkIsVUFBTThELGNBQWMxQyxRQUFRMEMsZUFBZTFDLFFBQVEyQyxxQkFBcUIzQyxRQUFRNEMsdUJBQXVCLFFBQVEsSUFBSTtBQUNuSCxVQUFNQyxjQUFjN0MsUUFBUTZDLGVBQWU3QyxRQUFRMkMsb0JBQW9CO0FBRXZFLFVBQU1HLFdBQVcsR0FBR3hDLE1BQU0sSUFBSWlDLFFBQVEsSUFBSUcsV0FBVyxJQUFJRyxXQUFXO0FBQ3BFLFFBQUlFLFlBQVlkLG1CQUFtQmUsSUFBSUYsUUFBUTtBQUUvQyxRQUFJLENBQUNDLFdBQVc7QUFDZEEsa0JBQVksSUFBSUUsS0FBS0MsYUFBYTVDLFFBQVE7QUFBQSxRQUN4QzZDLE9BQU87QUFBQSxRQUNQWjtBQUFBQSxRQUNBYSx1QkFBdUJWO0FBQUFBLFFBQ3ZCVyx1QkFBdUJSO0FBQUFBLE1BQ3pCLENBQUM7QUFDRFoseUJBQW1CcUIsSUFBSVIsVUFBVUMsU0FBUztBQUFBLElBQzVDO0FBQ0EsUUFBSVEsWUFBWVIsVUFBVVMsT0FBT2YsR0FBRztBQUVwQyxRQUFJckMsU0FBU3FELGtCQUFrQixDQUFDRixVQUFVeEMsU0FBU1gsU0FBU3FELGNBQWMsR0FBRztBQUMzRSxZQUFNQyxlQUFlakIsSUFBSWtCLGVBQWVyRCxRQUFRO0FBQUEsUUFDOUM4Qyx1QkFBdUJWO0FBQUFBLFFBQ3ZCVyx1QkFBdUJSO0FBQUFBLE1BQ3pCLENBQUM7QUFDRCxVQUFJekMsU0FBU3dELHFCQUFxQixVQUFVO0FBQzFDTCxvQkFBWSxHQUFHRyxZQUFZLElBQUl0RCxTQUFTcUQsY0FBYztBQUFBLE1BQ3hELFdBQVdyRCxTQUFTd0QscUJBQXFCLFVBQVU7QUFDakRMLG9CQUFZLEdBQUduRCxTQUFTcUQsY0FBYyxHQUFHQyxZQUFZO0FBQUEsTUFDdkQ7QUFBQSxJQUNGO0FBRUEsV0FBT0g7QUFBQUEsRUFDVCxRQUFRO0FBQ04sV0FBTzNFO0FBQUFBLEVBQ1Q7QUFDRjtBQVFPLGFBQU1pRixlQUFlQSxDQUFDeEIsUUFBUXJDLFVBQVUsQ0FBQyxNQUFNO0FBQ3BELE1BQUlxQyxXQUFXLFFBQVFBLFdBQVdDLFVBQWFELFdBQVcsTUFBTS9DLE1BQU0rQyxNQUFNLEVBQUcsUUFBT3pEO0FBQ3RGLFFBQU02RCxNQUFNdkQsT0FBT21ELE1BQU07QUFDekIsTUFBSS9DLE1BQU1tRCxHQUFHLEVBQUcsUUFBTzdEO0FBRXZCLFFBQU1rRixTQUFTOUQsUUFBUTBDLGVBQWUxQyxRQUFRMkMsb0JBQW9CM0MsUUFBUStELFlBQVk7QUFDdEYsUUFBTUMsU0FBU2hFLFFBQVE2QyxlQUFlN0MsUUFBUTJDLG9CQUFvQjNDLFFBQVErRCxZQUFZO0FBQ3RGLFFBQU16RCxTQUFTTixRQUFRTSxVQUFVO0FBRWpDLE1BQUlOLFFBQVFpRSxPQUFPakUsUUFBUWtFLFVBQVU7QUFDbkMsVUFBTUMsY0FBY25FLFFBQVFtRSxlQUFnQixDQUFDbkUsUUFBUW9FO0FBQ3JELFdBQU8zQixJQUFJa0IsZUFBZXJELFFBQVE7QUFBQSxNQUNoQzhDLHVCQUF1QlU7QUFBQUEsTUFDdkJULHVCQUF1Qlc7QUFBQUEsTUFDdkJHO0FBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUFPL0IsZUFBZUMsUUFBUTtBQUFBLElBQzVCSyxhQUFhb0I7QUFBQUEsSUFDYmpCLGFBQWFtQjtBQUFBQSxJQUNiLEdBQUdoRTtBQUFBQSxFQUNMLENBQUM7QUFDSDtBQXFCTyxhQUFNcUUsOEJBQThCQSxDQUFDQyxPQUFPQyxpQkFBaUIsQ0FBQyxHQUFHdkUsVUFBVSxDQUFDLE1BQU07QUFDdkYsTUFBSXdFLE1BQU1GO0FBQ1YsTUFBSUcsT0FBTyxDQUFDO0FBRVosTUFBSUgsU0FBUyxPQUFPQSxVQUFVLFlBQVksT0FBT0MsbUJBQW1CLFVBQVU7QUFDNUVDLFVBQU1GLE1BQU1DLGNBQWM7QUFDMUJFLFdBQU96RSxXQUFXLENBQUM7QUFBQSxFQUNyQixXQUFXLE9BQU91RSxtQkFBbUIsVUFBVTtBQUM3Q0UsV0FBT0Ysa0JBQWtCLENBQUM7QUFBQSxFQUM1QjtBQUVBLE1BQUlDLFFBQVEsUUFBUUEsUUFBUWxDLFVBQWFrQyxRQUFRLE1BQU1sRixNQUFNa0YsR0FBRyxFQUFHLFFBQU81RjtBQUUxRSxRQUFNOEYsYUFBYUQsS0FBS0MsZUFBZSxDQUFDRCxLQUFLUixPQUFPLENBQUNRLEtBQUtQO0FBRTFELE1BQUksQ0FBQ1EsWUFBWTtBQUNmLFdBQU9iLGFBQWFXLEtBQUssRUFBRVAsS0FBSyxNQUFNRixVQUFVLEdBQUcsR0FBR1UsS0FBSyxDQUFDO0FBQUEsRUFDOUQ7QUFFQSxTQUFPckMsZUFBZW9DLEtBQUssRUFBRTVCLG9CQUFvQixNQUFNRixhQUFhLEdBQUdHLGFBQWEsR0FBRyxHQUFHNEIsS0FBSyxDQUFDO0FBQ2xHO0FBRU8sYUFBTUUscUJBQXFCTjtBQUMzQixhQUFNTyx1QkFBdUJQO0FBSzdCLGFBQU1RLGtCQUFrQkEsQ0FBQ0MsUUFBUTtBQUN0QyxNQUFJLENBQUNBLE9BQU8sT0FBT0EsUUFBUSxTQUFVLFFBQU87QUFDNUMsUUFBTUMsSUFBSUQsSUFBSUUsWUFBWTtBQUMxQixVQUNFRCxFQUFFaEUsU0FBUyxRQUFRLEtBQ25CZ0UsRUFBRWhFLFNBQVMsT0FBTyxLQUNsQmdFLEVBQUVoRSxTQUFTLE1BQU0sS0FDakJnRSxFQUFFaEUsU0FBUyxTQUFTLEtBQ3BCZ0UsRUFBRWhFLFNBQVMsWUFBWSxLQUN2QmdFLEVBQUVoRSxTQUFTLFVBQVUsS0FDckJnRSxFQUFFaEUsU0FBUyxXQUFXLEtBQ3RCZ0UsRUFBRWhFLFNBQVMsS0FBSyxLQUNoQmdFLEVBQUVoRSxTQUFTLFFBQVEsS0FDbkJnRSxFQUFFaEUsU0FBUyxPQUFPLEtBQ2xCZ0UsRUFBRWhFLFNBQVMsVUFBVSxLQUNyQmdFLEVBQUVoRSxTQUFTLFFBQVEsS0FDbkJnRSxFQUFFaEUsU0FBUyxRQUFRLEtBQ25CZ0UsRUFBRWhFLFNBQVMsU0FBUyxLQUNwQmdFLEVBQUVoRSxTQUFTLFFBQVEsS0FDbkJnRSxFQUFFaEUsU0FBUyxTQUFTLEtBQ3BCZ0UsRUFBRWhFLFNBQVMsV0FBVyxLQUN0QmdFLEVBQUVoRSxTQUFTLEtBQUssS0FDaEJnRSxFQUFFaEUsU0FBUyxLQUFLLEtBQ2hCZ0UsRUFBRWhFLFNBQVMsWUFBWSxLQUN2QmdFLEVBQUVoRSxTQUFTLE9BQU8sS0FDbEJnRSxFQUFFaEUsU0FBUyxLQUFLLE1BQ2IsQ0FBQ2dFLEVBQUVoRSxTQUFTLE1BQU0sS0FBSyxDQUFDZ0UsRUFBRWhFLFNBQVMsU0FBUyxLQUFLLENBQUNnRSxFQUFFaEUsU0FBUyxZQUFZLEtBQUssQ0FBQ2dFLEVBQUVoRSxTQUFTLElBQUksS0FBSyxDQUFDZ0UsRUFBRWhFLFNBQVMsT0FBTyxLQUFLLENBQUNnRSxFQUFFaEUsU0FBUyxNQUFNLEtBQUssQ0FBQ2dFLEVBQUVoRSxTQUFTLFFBQVEsS0FBSyxDQUFDZ0UsRUFBRWhFLFNBQVMsTUFBTSxLQUFLLENBQUNnRSxFQUFFaEUsU0FBUyxNQUFNO0FBQzNOO0FBRU8sYUFBTWtFLHNCQUFzQko7QUFLNUIsYUFBTUssb0JBQW9CQSxDQUFDSixRQUFRO0FBQ3hDLE1BQUksQ0FBQ0EsT0FBTyxPQUFPQSxRQUFRLFNBQVUsUUFBTztBQUM1QyxRQUFNQyxJQUFJRCxJQUFJRSxZQUFZO0FBQzFCLFNBQU9ELEVBQUVoRSxTQUFTLE1BQU0sS0FBS2dFLEVBQUVoRSxTQUFTLFNBQVMsS0FBS2dFLEVBQUVoRSxTQUFTLFlBQVk7QUFDL0U7QUFFTyxhQUFNb0Usd0JBQXdCRDtBQVE5QixhQUFNRSxlQUFlQSxDQUFDM0MsS0FBS3pDLFVBQVUsQ0FBQyxNQUFNO0FBQ2pELE1BQUl5QyxRQUFRLFFBQVFBLFFBQVFILFVBQWFHLFFBQVEsTUFBTW5ELE1BQU1tRCxHQUFHLEVBQUcsUUFBTzdEO0FBQzFFLFFBQU15RyxJQUFJbkcsT0FBT3VELEdBQUc7QUFDcEIsTUFBSW5ELE1BQU0rRixDQUFDLEVBQUcsUUFBT3pHO0FBQ3JCLFFBQU13QixXQUFXMUIseUJBQXlCO0FBQzFDLFFBQU02RCxXQUFXbkMsU0FBU29DLG1CQUFtQjtBQUM3QyxRQUFNbEMsU0FBU04sUUFBUU0sVUFBVUYsU0FBU0UsV0FBV2lDLGFBQWEsUUFBUSxVQUFVO0FBRXBGLE1BQUl2QyxRQUFRc0YsV0FBV2xGLFNBQVNtRixnQkFBZ0I7QUFDOUMsUUFBSWpGLFdBQVcsU0FBUztBQUN0QixZQUFNa0YsTUFBTTdELEtBQUs2RCxJQUFJSCxDQUFDO0FBQ3RCLFVBQUlHLE9BQU8sSUFBVSxRQUFPLElBQUlILElBQUksS0FBVUksUUFBUXpGLFFBQVErRCxZQUFZLENBQUMsQ0FBQztBQUM1RSxVQUFJeUIsT0FBTyxJQUFRLFFBQU8sSUFBSUgsSUFBSSxLQUFRSSxRQUFRekYsUUFBUStELFlBQVksQ0FBQyxDQUFDO0FBQ3hFLFVBQUl5QixPQUFPLElBQU0sUUFBTyxJQUFJSCxJQUFJLEtBQU1JLFFBQVF6RixRQUFRK0QsWUFBWSxDQUFDLENBQUM7QUFDcEUsYUFBT3NCLEVBQUVLLFNBQVM7QUFBQSxJQUNwQixPQUFPO0FBQ0wsWUFBTUYsTUFBTTdELEtBQUs2RCxJQUFJSCxDQUFDO0FBQ3RCLFVBQUlHLE9BQU8sSUFBWSxRQUFPLElBQUlILElBQUksS0FBWUksUUFBUXpGLFFBQVErRCxZQUFZLENBQUMsQ0FBQztBQUNoRixVQUFJeUIsT0FBTyxJQUFTLFFBQU8sSUFBSUgsSUFBSSxLQUFTSSxRQUFRekYsUUFBUStELFlBQVksQ0FBQyxDQUFDO0FBQzFFLFVBQUl5QixPQUFPLElBQU0sUUFBTyxJQUFJSCxJQUFJLEtBQU1JLFFBQVF6RixRQUFRK0QsWUFBWSxDQUFDLENBQUM7QUFDcEUsYUFBT3NCLEVBQUVLLFNBQVM7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNaEQsY0FBYzFDLFFBQVEwQyxlQUFlMUMsUUFBUStELGFBQWEvRCxRQUFRMkYsZ0JBQWdCLElBQUk7QUFDNUYsUUFBTTlDLGNBQWM3QyxRQUFRNkMsZUFBZTdDLFFBQVErRCxhQUFhL0QsUUFBUTJGLGdCQUFnQixJQUFJO0FBRTVGLFFBQU03QyxXQUFXLEdBQUd4QyxNQUFNLElBQUlvQyxXQUFXLElBQUlHLFdBQVc7QUFDeEQsTUFBSUUsWUFBWVosaUJBQWlCYSxJQUFJRixRQUFRO0FBQzdDLE1BQUksQ0FBQ0MsV0FBVztBQUNkQSxnQkFBWSxJQUFJRSxLQUFLQyxhQUFhNUMsUUFBUTtBQUFBLE1BQ3hDOEMsdUJBQXVCVjtBQUFBQSxNQUN2QlcsdUJBQXVCUjtBQUFBQSxJQUN6QixDQUFDO0FBQ0RWLHFCQUFpQm1CLElBQUloRCxRQUFReUMsU0FBUztBQUFBLEVBQ3hDO0FBQ0EsU0FBT0EsVUFBVVMsT0FBTzZCLENBQUM7QUFDM0I7QUFRTyxhQUFNTyxtQkFBbUJBLENBQUNDLE9BQU85QixXQUFXLE1BQU07QUFDdkQsTUFBSThCLFVBQVUsUUFBUUEsVUFBVXZELFVBQWF1RCxVQUFVLE1BQU12RyxNQUFNdUcsS0FBSyxFQUFHLFFBQU9qSDtBQUNsRixTQUFPLEdBQUdrSCxXQUFXRCxLQUFLLEVBQUVKLFFBQVExQixRQUFRLENBQUM7QUFDL0M7QUFFTyxhQUFNZ0MsZ0JBQWdCSDtBQVd0QixhQUFNSSxjQUFjQSxDQUFDQyxVQUFVO0FBQ3BDLE1BQUksQ0FBQ0EsTUFBTyxRQUFPckg7QUFDbkIsUUFBTXdCLFdBQVcxQix5QkFBeUI7QUFDMUMsUUFBTXdILGVBQWU5RixTQUFTNkYsU0FBUztBQUN2QyxNQUFJRSxjQUFjO0FBQ2xCLE1BQUlELGFBQWFFLFdBQVcsR0FBRyxHQUFHO0FBQ2hDLFVBQU1ySCxRQUFRbUgsYUFBYW5ILE1BQU0sY0FBYztBQUMvQyxRQUFJQSxNQUFPb0gsZUFBY3BILE1BQU0sQ0FBQztBQUFBLEVBQ2xDO0FBQ0EsUUFBTXNILFdBQVcsS0FBS0osT0FBT0ssUUFBUSxPQUFPLEVBQUU7QUFDOUMsTUFBSUQsUUFBUUUsV0FBVyxJQUFJO0FBQ3pCLFdBQU8sR0FBR0osV0FBVyxJQUFJRSxRQUFRRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUlILFFBQVFHLE1BQU0sQ0FBQyxDQUFDO0FBQUEsRUFDbEU7QUFDQSxNQUFJSCxRQUFRRSxXQUFXLE1BQU1GLFFBQVFELFdBQVcsSUFBSSxHQUFHO0FBQ3JELFdBQU8sR0FBR0QsV0FBVyxJQUFJRSxRQUFRRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUlILFFBQVFHLE1BQU0sQ0FBQyxDQUFDO0FBQUEsRUFDbEU7QUFDQSxTQUFPUDtBQUNUO0FBT08sYUFBTVEsY0FBY0EsQ0FBQ0MsVUFBVTtBQUNwQyxNQUFJLENBQUNBLFNBQVMsT0FBT0EsVUFBVSxTQUFVLFFBQU85SDtBQUNoRCxRQUFNK0gsVUFBVUQsTUFBTTFILEtBQUssRUFBRWdHLFlBQVk7QUFDekMsU0FBTzJCLFdBQVcvSDtBQUNwQjtBQU9PLGFBQU1nSSxpQkFBaUJBLENBQUNDLFVBQVU7QUFDdkMsTUFBSUEsVUFBVSxRQUFRQSxVQUFVdkUsVUFBYWhELE1BQU11SCxLQUFLLEtBQUtBLFNBQVMsRUFBRyxRQUFPakk7QUFDaEYsUUFBTWtJLElBQUluRixLQUFLQyxNQUFNaUYsS0FBSztBQUMxQixRQUFNRSxJQUFJcEYsS0FBS3FGLE9BQU9ILFFBQVFDLEtBQUssRUFBRTtBQUNyQyxRQUFNRyxXQUFXSCxJQUFJLElBQUksR0FBR0EsQ0FBQyxRQUFRO0FBQ3JDLFFBQU1JLFdBQVdILElBQUksSUFBSSxHQUFHQSxDQUFDLFNBQVM7QUFDdEMsU0FBTyxHQUFHRSxRQUFRLElBQUlDLFFBQVEsR0FBR2xJLEtBQUssS0FBS0o7QUFDN0M7QUFRTyxhQUFNdUksaUJBQWlCQSxDQUFDQyxZQUFZQyxPQUFPLFVBQVU7QUFDMUQsTUFBSUQsZUFBZSxRQUFRQSxlQUFlOUUsVUFBYWhELE1BQU04SCxVQUFVLEVBQUcsUUFBT3hJO0FBQ2pGLFFBQU0wSSxTQUFTRCxPQUFPRCxhQUFhLE1BQU9BO0FBQzFDLE1BQUlFLFNBQVMsS0FBTTtBQUNqQixXQUFPLEdBQUczRixLQUFLcUYsTUFBTU0sTUFBTSxDQUFDO0FBQUEsRUFDOUI7QUFDQSxTQUFPLElBQUlBLFNBQVMsS0FBTTdCLFFBQVEsQ0FBQyxDQUFDO0FBQ3RDO0FBT08sYUFBTThCLGlCQUFpQkEsQ0FBQ0MsVUFBVTtBQUN2QyxNQUFJQSxVQUFVLFFBQVFBLFVBQVVsRixVQUFhaEQsTUFBTWtJLEtBQUssS0FBS0EsUUFBUSxFQUFHLFFBQU81STtBQUMvRSxNQUFJNEksVUFBVSxFQUFHLFFBQU87QUFDeEIsUUFBTXpDLElBQUk7QUFDVixRQUFNMEMsUUFBUSxDQUFDLFNBQVMsTUFBTSxNQUFNLE1BQU0sSUFBSTtBQUM5QyxRQUFNQyxJQUFJL0YsS0FBS0MsTUFBTUQsS0FBS2dHLElBQUlILEtBQUssSUFBSTdGLEtBQUtnRyxJQUFJNUMsQ0FBQyxDQUFDO0FBQ2xELFNBQU8sR0FBR2UsWUFBWTBCLFFBQVE3RixLQUFLaUcsSUFBSTdDLEdBQUcyQyxDQUFDLEdBQUdqQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUlnQyxNQUFNQyxDQUFDLENBQUM7QUFDdkU7QUFZTyxhQUFNRyxhQUFhQSxDQUFDQyxJQUFJQyxRQUFRLE9BQU87QUFDNUMsTUFBSSxDQUFDRCxHQUFJLFFBQU9sSjtBQUNoQixRQUFNb0osTUFBTXRJLE9BQU9vSSxFQUFFLEVBQUU5SSxLQUFLO0FBQzVCLE1BQUlnSixJQUFJekIsVUFBVXdCLE1BQU8sUUFBT0M7QUFDaEMsU0FBTyxHQUFHQSxJQUFJeEIsTUFBTSxHQUFHdUIsS0FBSyxDQUFDO0FBQy9CO0FBRU8sYUFBTUUsa0JBQWtCQSxDQUFDSCxPQUFRQSxLQUFNcEksT0FBT29JLEVBQUUsRUFBRTFCLFdBQVcsS0FBSyxJQUFJMUcsT0FBT29JLEVBQUUsSUFBSSxNQUFNRCxXQUFXQyxJQUFJLEVBQUUsQ0FBQyxLQUFNbEo7QUFDakgsYUFBTXNKLGtCQUFrQkEsQ0FBQ0osT0FBUUEsS0FBTXBJLE9BQU9vSSxFQUFFLEVBQUUxQixXQUFXLE1BQU0sSUFBSTFHLE9BQU9vSSxFQUFFLElBQUlELFdBQVdDLElBQUksRUFBRSxJQUFLbEo7QUFDMUcsYUFBTXVKLHNCQUFzQkEsQ0FBQ0wsT0FBUUEsS0FBTXBJLE9BQU9vSSxFQUFFLEVBQUUxQixXQUFXLE1BQU0sSUFBSTFHLE9BQU9vSSxFQUFFLElBQUksT0FBT0QsV0FBV0MsSUFBSSxFQUFFLENBQUMsS0FBTWxKO0FBQ3ZILGFBQU13SixpQkFBaUJBLENBQUNOLE9BQVFBLEtBQU1wSSxPQUFPb0ksRUFBRSxFQUFFMUIsV0FBVyxPQUFPLEtBQUsxRyxPQUFPb0ksRUFBRSxFQUFFMUIsV0FBVyxNQUFNLElBQUkxRyxPQUFPb0ksRUFBRSxJQUFJLE9BQU9ELFdBQVdDLElBQUksRUFBRSxDQUFDLEtBQU1sSjtBQUNwSixhQUFNeUoscUJBQXFCQSxDQUFDUCxPQUFRQSxLQUFNcEksT0FBT29JLEVBQUUsRUFBRTFCLFdBQVcsTUFBTSxLQUFLMUcsT0FBT29JLEVBQUUsRUFBRTFCLFdBQVcsTUFBTSxJQUFJMUcsT0FBT29JLEVBQUUsSUFBSSxPQUFPRCxXQUFXQyxJQUFJLEVBQUUsQ0FBQyxLQUFNbEo7QUFDdkosYUFBTTBKLHFCQUFxQkEsQ0FBQ1IsT0FBUUEsS0FBTXBJLE9BQU9vSSxFQUFFLEVBQUUxQixXQUFXLE1BQU0sS0FBSzFHLE9BQU9vSSxFQUFFLEVBQUUxQixXQUFXLE9BQU8sSUFBSTFHLE9BQU9vSSxFQUFFLElBQUksT0FBT0QsV0FBV0MsSUFBSSxFQUFFLENBQUMsS0FBTWxKO0FBQ3hKLGFBQU0ySixpQkFBaUJBLENBQUNULE9BQVFBLEtBQU1wSSxPQUFPb0ksRUFBRSxFQUFFMUIsV0FBVyxNQUFNLElBQUkxRyxPQUFPb0ksRUFBRSxJQUFJLE9BQU9ELFdBQVdDLElBQUksRUFBRSxDQUFDLEtBQU1sSjtBQUNsSCxhQUFNNEosbUJBQW1CQSxDQUFDVixPQUFRQSxLQUFNcEksT0FBT29JLEVBQUUsRUFBRTFCLFdBQVcsTUFBTSxJQUFJMUcsT0FBT29JLEVBQUUsSUFBSSxPQUFPRCxXQUFXQyxJQUFJLEVBQUUsQ0FBQyxLQUFNbEo7QUFDcEgsYUFBTTZKLG1CQUFtQkEsQ0FBQ1gsT0FBUUEsS0FBTXBJLE9BQU9vSSxFQUFFLEVBQUUxQixXQUFXLE9BQU8sSUFBSTFHLE9BQU9vSSxFQUFFLElBQUksUUFBUUQsV0FBV0MsSUFBSSxFQUFFLENBQUMsS0FBTWxKO0FBQ3RILGFBQU04SixrQkFBa0JBLENBQUNaLE9BQVFBLEtBQU1wSSxPQUFPb0ksRUFBRSxFQUFFMUIsV0FBVyxNQUFNLElBQUkxRyxPQUFPb0ksRUFBRSxJQUFJLE9BQU9ELFdBQVdDLElBQUksRUFBRSxDQUFDLEtBQU1sSjtBQVduSCxhQUFNK0osYUFBYUEsQ0FBQ1gsUUFBUTtBQUNqQyxNQUFJLENBQUNBLE9BQU8sT0FBT0EsUUFBUSxTQUFVLFFBQU87QUFDNUMsU0FBT0EsSUFBSVksT0FBTyxDQUFDLEVBQUV2SixZQUFZLElBQUkySSxJQUFJeEIsTUFBTSxDQUFDLEVBQUV4QixZQUFZO0FBQ2hFO0FBT0EsTUFBTTZELHNCQUFzQixvQkFBSUMsSUFBSSxDQUFDLE1BQU0sT0FBTyxRQUFRLE9BQU8sT0FBTyxPQUFPLE9BQU8sUUFBUSxPQUFPLE9BQU8sSUFBSSxDQUFDO0FBRTFHLGFBQU1DLFlBQVlBLENBQUNmLFFBQVE7QUFDaEMsTUFBSSxDQUFDQSxPQUFPLE9BQU9BLFFBQVEsU0FBVSxRQUFPO0FBQzVDLFNBQU9BLElBQ0oxQixRQUFRLG1CQUFtQixPQUFPLEVBQ2xDQSxRQUFRLFVBQVUsR0FBRyxFQUNyQjBDLE1BQU0sR0FBRyxFQUNUQyxPQUFPQyxPQUFPLEVBQ2RDLElBQUksQ0FBQ0MsU0FBUztBQUNiLFVBQU1DLFFBQVFELEtBQUsvSixZQUFZO0FBQy9CLFFBQUl3SixvQkFBb0JTLElBQUlELEtBQUssRUFBRyxRQUFPQTtBQUMzQyxXQUFPRCxLQUFLUixPQUFPLENBQUMsRUFBRXZKLFlBQVksSUFBSStKLEtBQUs1QyxNQUFNLENBQUMsRUFBRXhCLFlBQVk7QUFBQSxFQUNsRSxDQUFDLEVBQ0F1RSxLQUFLLEdBQUc7QUFDYjtBQVFPLGFBQU1DLFlBQVlBLENBQUNoRixLQUFLaUYsV0FBVzdLLGFBQWE7QUFDckQsTUFBSTRGLFFBQVEsUUFBUUEsUUFBUWxDLFVBQWFrQyxRQUFRLE1BQU8sT0FBT0EsUUFBUSxZQUFZbEYsTUFBTWtGLEdBQUcsR0FBSTtBQUM5RixXQUFPaUY7QUFBQUEsRUFDVDtBQUNBLFNBQU9qRjtBQUNUO0FBT08sYUFBTWtGLGVBQWVBLENBQUNsRixRQUFRO0FBQ25DLE1BQUlBLFFBQVEsUUFBUUEsUUFBUWxDLFVBQWFrQyxRQUFRLEdBQUksUUFBTztBQUM1RCxNQUFJbUYsTUFBTUMsUUFBUXBGLEdBQUcsRUFBRyxRQUFPQSxJQUFJK0IsV0FBVztBQUM5QyxNQUFJLE9BQU8vQixRQUFRLFNBQVUsUUFBT3FGLE9BQU9DLEtBQUt0RixHQUFHLEVBQUUrQixXQUFXO0FBQ2hFLFNBQU87QUFDVDtBQU9PLGFBQU13RCxrQkFBa0IsT0FBT0MsU0FBUztBQUM3QyxNQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixNQUFJO0FBQ0YsUUFBSUMsV0FBV0MsV0FBV0MsV0FBVztBQUNuQyxZQUFNRixVQUFVQyxVQUFVQyxVQUFVSCxJQUFJO0FBQ3hDLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTUksV0FBV0MsU0FBU0MsY0FBYyxVQUFVO0FBQ2xERixhQUFTdkUsUUFBUW1FO0FBQ2pCSyxhQUFTRSxLQUFLQyxZQUFZSixRQUFRO0FBQ2xDQSxhQUFTSyxPQUFPO0FBQ2hCLFVBQU1DLFVBQVVMLFNBQVNNLFlBQVksTUFBTTtBQUMzQ04sYUFBU0UsS0FBS0ssWUFBWVIsUUFBUTtBQUNsQyxXQUFPTTtBQUFBQSxFQUNULFNBQVNHLEtBQUs7QUFDWkMsWUFBUUMsTUFBTSxnQ0FBZ0NGLEdBQUc7QUFDakQsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQU9PLGFBQU1HLGVBQWVBLENBQUNDLEtBQUtDLFdBQVcsZUFBZTtBQUMxRCxNQUFJLENBQUNELElBQUs7QUFDVixRQUFNRSxPQUFPZCxTQUFTQyxjQUFjLEdBQUc7QUFDdkNhLE9BQUtDLE9BQU9IO0FBQ1pFLE9BQUtFLFdBQVdIO0FBQ2hCYixXQUFTRSxLQUFLQyxZQUFZVyxJQUFJO0FBQzlCQSxPQUFLRyxNQUFNO0FBQ1hqQixXQUFTRSxLQUFLSyxZQUFZTyxJQUFJO0FBQ2hDO0FBTU8sYUFBTUksNEJBQTRCQSxDQUFDTixLQUFLTyxRQUFRLFFBQVE7QUFDN0QsTUFBSSxDQUFDUCxPQUFPLE9BQU9BLFFBQVEsU0FBVSxRQUFPQTtBQUM1QyxNQUFJLENBQUNBLElBQUk3RSxXQUFXLE1BQU0sS0FBSyxDQUFDNkUsSUFBSWxLLFNBQVMsb0JBQW9CLEVBQUcsUUFBT2tLO0FBQzNFLE1BQUlBLElBQUlsSyxTQUFTLE1BQU0sRUFBRyxRQUFPa0s7QUFFakMsTUFBSVEsV0FBV1I7QUFDZixRQUFNUyxjQUFjO0FBQ3BCLFFBQU0zTSxRQUFRME0sU0FBUzFNLE1BQU0yTSxXQUFXO0FBQ3hDLE1BQUkzTSxPQUFPO0FBQ1QsVUFBTTRNLGVBQWU1TSxNQUFNLENBQUM7QUFDNUIsUUFBSTRNLGFBQWE1SyxTQUFTLFFBQVEsS0FBSzRLLGFBQWE1SyxTQUFTLFFBQVEsS0FBSzRLLGFBQWE1SyxTQUFTLElBQUksS0FBSzRLLGFBQWE1SyxTQUFTLElBQUksR0FBRztBQUNwSTBLLGlCQUFXQSxTQUFTbkYsUUFBUSxJQUFJdkgsTUFBTSxDQUFDLENBQUMsSUFBSTRNLFlBQVksS0FBSyxJQUFJNU0sTUFBTSxDQUFDLENBQUMsR0FBRztBQUFBLElBQzlFO0FBQUEsRUFDRjtBQUVBLFFBQU02TSxZQUFZLG1CQUFtQkosS0FBSztBQUMxQyxNQUFJQyxTQUFTMUssU0FBUyxnQkFBZ0IsR0FBRztBQUN2QyxXQUFPMEssU0FBU25GLFFBQVEsa0JBQWtCLGlCQUFpQnNGLFNBQVMsR0FBRztBQUFBLEVBQ3pFLFdBQVdILFNBQVMxSyxTQUFTLFVBQVUsS0FBSyxDQUFDMEssU0FBUzFLLFNBQVMsY0FBYyxLQUFLLENBQUMwSyxTQUFTMUssU0FBUyxnQkFBZ0IsR0FBRztBQUN0SCxXQUFPMEssU0FBU25GLFFBQVEsWUFBWSxXQUFXc0YsU0FBUyxHQUFHO0FBQUEsRUFDN0Q7QUFDQSxTQUFPSDtBQUNUO0FBRU8sYUFBTUksZ0JBQWdCQSxDQUFDQyxNQUFNOUwsVUFBVSxDQUFDLE1BQU07QUFDbkQsU0FBTyxJQUFJK0wsUUFBUSxDQUFDQyxZQUFZO0FBQzlCLFVBQU0sRUFBRUMsV0FBVyxNQUFNQyxZQUFZLE1BQU1DLFVBQVUsS0FBSyxJQUFJbk07QUFDOUQsUUFBSSxDQUFDOEwsUUFBUSxDQUFDQSxLQUFLTSxLQUFLaEcsV0FBVyxRQUFRLEVBQUcsUUFBTzRGLFFBQVFGLElBQUk7QUFFakUsVUFBTU8sU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxXQUFPRSxTQUFTLENBQUNDLFVBQVU7QUFDekIsWUFBTUMsTUFBTSxJQUFJQyxNQUFNO0FBQ3RCRCxVQUFJRixTQUFTLE1BQU07QUFDakIsWUFBSWYsUUFBUWlCLElBQUlqQjtBQUNoQixZQUFJbUIsU0FBU0YsSUFBSUU7QUFDakIsWUFBSW5CLFFBQVFTLFlBQVlVLFNBQVNULFdBQVc7QUFDMUMsY0FBSVYsUUFBUW1CLFFBQVE7QUFDbEJBLHFCQUFTaEwsS0FBS3FGLE1BQU8yRixTQUFTVixXQUFZVCxLQUFLO0FBQy9DQSxvQkFBUVM7QUFBQUEsVUFDVixPQUFPO0FBQ0xULG9CQUFRN0osS0FBS3FGLE1BQU93RSxRQUFRVSxZQUFhUyxNQUFNO0FBQy9DQSxxQkFBU1Q7QUFBQUEsVUFDWDtBQUFBLFFBQ0Y7QUFDQSxjQUFNVSxTQUFTdkMsU0FBU0MsY0FBYyxRQUFRO0FBQzlDc0MsZUFBT3BCLFFBQVFBO0FBQ2ZvQixlQUFPRCxTQUFTQTtBQUNoQixjQUFNRSxNQUFNRCxPQUFPRSxXQUFXLElBQUk7QUFDbENELFlBQUlFLFVBQVVOLEtBQUssR0FBRyxHQUFHakIsT0FBT21CLE1BQU07QUFFdENDLGVBQU9JLE9BQU8sQ0FBQ0MsU0FBUztBQUN0QixjQUFJLENBQUNBLEtBQU0sUUFBT2pCLFFBQVFGLElBQUk7QUFDOUIsZ0JBQU1vQixpQkFBaUIsSUFBSUMsS0FBSyxDQUFDRixJQUFJLEdBQUduQixLQUFLc0IsS0FBSzlHLFFBQVEsYUFBYSxFQUFFLElBQUksU0FBUztBQUFBLFlBQ3BGOEYsTUFBTTtBQUFBLFlBQ05pQixjQUFjbk4sS0FBS3VCLElBQUk7QUFBQSxVQUN6QixDQUFDO0FBQ0R1SyxrQkFBUWtCLGVBQWVJLE9BQU94QixLQUFLd0IsT0FBT0osaUJBQWlCcEIsSUFBSTtBQUFBLFFBQ2pFLEdBQUcsY0FBY0ssT0FBTztBQUFBLE1BQzFCO0FBQ0FNLFVBQUljLFVBQVUsTUFBTXZCLFFBQVFGLElBQUk7QUFDaENXLFVBQUllLE1BQU1oQixNQUFNaUIsT0FBT0M7QUFBQUEsSUFDekI7QUFDQXJCLFdBQU9rQixVQUFVLE1BQU12QixRQUFRRixJQUFJO0FBQ25DTyxXQUFPc0IsY0FBYzdCLElBQUk7QUFBQSxFQUMzQixDQUFDO0FBQ0g7QUFFTyxhQUFNOEIsc0JBQXNCQSxDQUFDQyxVQUFVLENBQUMsTUFBTTtBQUNuRCxRQUFNQyxZQUFZQSxDQUFDdEosUUFBUTtBQUN6QixRQUFJLENBQUNBLElBQUssUUFBTztBQUNqQixXQUFPQSxJQUFJa0IsU0FBUyxFQUNqQlksUUFBUSxpQ0FBaUMsRUFBRSxFQUMzQ0EsUUFBUSxpQkFBaUIsRUFBRSxFQUMzQkEsUUFBUSx3QkFBd0IsRUFBRSxFQUNsQ3RILEtBQUs7QUFBQSxFQUNWO0FBRUEsUUFBTStPLGNBQWNELFVBQVVELFFBQVFFLGVBQWVGLFFBQVFHLGdCQUFnQkgsUUFBUUksU0FBU0osUUFBUUssUUFBUUwsUUFBUU0sYUFBYU4sUUFBUU8sUUFBUVAsUUFBUVEsTUFBTTtBQUNqSyxRQUFNQyxPQUFPUixVQUFVRCxRQUFRUyxRQUFRVCxRQUFRVSxjQUFjVixRQUFRVyxVQUFVWCxRQUFRWSxXQUFXWixRQUFRYSxJQUFJO0FBQzlHLFFBQU1DLFdBQVdiLFVBQVVELFFBQVFjLFFBQVE7QUFDM0MsUUFBTUMsT0FBT2QsVUFBVUQsUUFBUWUsUUFBUWYsUUFBUWdCLFlBQVloQixRQUFRaUIsZUFBZWpCLFFBQVFrQixpQkFBaUJsQixRQUFRbUIsVUFBVW5CLFFBQVFvQixXQUFXcEIsUUFBUXFCLFVBQVVyQixRQUFRc0IsT0FBTztBQUNqTCxRQUFNQyxPQUFPdEIsVUFBVUQsUUFBUXVCLFFBQVF2QixRQUFRd0IsUUFBUXhCLFFBQVF5QixnQkFBZ0J6QixRQUFRMEIsaUJBQWlCMUIsUUFBUTJCLFVBQVUzQixRQUFRNEIsY0FBYztBQUNoSixRQUFNQyxVQUFVNUIsVUFBVUQsUUFBUTZCLFdBQVc3QixRQUFROEIsY0FBYzlCLFFBQVErQixZQUFZL0IsUUFBUWdDLFdBQVc7QUFFMUcsUUFBTUMsUUFBUTtBQUNkLGFBQVdDLFFBQVEsQ0FBQ2hDLGFBQWFPLE1BQU1LLFVBQVVDLE1BQU1RLE1BQU1NLE9BQU8sR0FBRztBQUNyRSxRQUFJLENBQUNLLEtBQU07QUFDWCxVQUFNQyxZQUFZRCxLQUFLL0ssWUFBWTtBQUNuQyxRQUFJaUwsaUJBQWlCO0FBQ3JCLFVBQU1DLGNBQWNKLE1BQU1LLEtBQUssQ0FBQ0MsVUFBVUMsVUFBVTtBQUNsRCxZQUFNQyxnQkFBZ0JGLFNBQVNwTCxZQUFZO0FBQzNDLFlBQU11TCxVQUFVRCxrQkFBa0JOLGFBQWFNLGNBQWN2UCxTQUFTaVAsU0FBUyxLQUFLQSxVQUFValAsU0FBU3VQLGFBQWE7QUFDcEgsVUFBSUMsUUFBU04sa0JBQWlCSTtBQUM5QixhQUFPRTtBQUFBQSxJQUNULENBQUM7QUFDRCxRQUFJTCxhQUFhO0FBQ2YsVUFBSUQsbUJBQW1CLE1BQU1GLEtBQUt4SixTQUFTdUosTUFBTUcsY0FBYyxFQUFFMUosUUFBUTtBQUN2RXVKLGNBQU1HLGNBQWMsSUFBSUY7QUFBQUEsTUFDMUI7QUFBQSxJQUNGLE9BQU87QUFDTEQsWUFBTVUsS0FBS1QsSUFBSTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUNBLFNBQU9ELE1BQU12RyxLQUFLLElBQUk7QUFDeEI7QUFFTyxhQUFNa0gsZ0JBQWdCQSxDQUFDNUMsWUFBWTtBQUN4QyxNQUFJLENBQUNBLFFBQVMsUUFBT2pQO0FBQ3JCLE1BQUksT0FBT2lQLFlBQVksU0FBVSxRQUFPQSxRQUFRN08sS0FBSyxLQUFLSjtBQUMxRCxNQUFJLE9BQU9pUCxZQUFZLFVBQVU7QUFDL0IsVUFBTTZDLFVBQVU5QyxvQkFBb0JDLE9BQU87QUFDM0MsUUFBSTZDLFFBQVMsUUFBT0E7QUFDcEIsV0FBTyxDQUFDN0MsUUFBUVcsVUFBVVgsUUFBUThDLGFBQWE5QyxRQUFRdUIsTUFBTXZCLFFBQVErQyxPQUFPL0MsUUFBUThCLGNBQWM5QixRQUFRNkIsU0FBUzdCLFFBQVFnRCxPQUFPLEVBQy9INUgsT0FBT0MsT0FBTyxFQUNkSyxLQUFLLElBQUksS0FBSzNLO0FBQUFBLEVBQ25CO0FBQ0EsU0FBT0E7QUFDVDtBQUVPLGFBQU1rUyxzQkFBc0JBLENBQUNDLFlBQVlDLGNBQWMsT0FBTztBQUNuRSxRQUFNQyxPQUFPRixjQUFjLENBQUM7QUFDNUIsUUFBTWpELFlBQVlBLENBQUN0SixRQUFRO0FBQ3pCLFFBQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLFFBQUkwTSxJQUFJMU0sSUFBSWtCLFNBQVMsRUFBRTFHLEtBQUs7QUFDNUJrUyxRQUFJQSxFQUFFNUssUUFBUSxpQ0FBaUMsRUFBRTtBQUNqRDRLLFFBQUlBLEVBQUU1SyxRQUFRLHdCQUF3QixFQUFFLEVBQUV0SCxLQUFLO0FBQy9DLFdBQU9rUztBQUFBQSxFQUNUO0FBRUEsUUFBTUMsYUFBYUEsQ0FBQzNNLFFBQVE7QUFDMUIsUUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsVUFBTTBNLElBQUkxTSxJQUFJa0IsU0FBUyxFQUFFVixZQUFZO0FBQ3JDLFdBQ0VrTSxFQUFFblEsU0FBUyxRQUFRLEtBQUttUSxFQUFFblEsU0FBUyxRQUFRLEtBQUttUSxFQUFFblEsU0FBUyxPQUFPLEtBQ2xFbVEsRUFBRW5RLFNBQVMsUUFBUSxLQUFLbVEsRUFBRW5RLFNBQVMsT0FBTyxLQUFLbVEsRUFBRW5RLFNBQVMsUUFBUSxLQUNsRW1RLEVBQUVuUSxTQUFTLGFBQWEsS0FBS21RLEVBQUVuUSxTQUFTLGNBQWMsS0FBS21RLE1BQU0sV0FDakVBLE1BQU0sWUFBWUEsTUFBTSxvQkFBb0JBLE1BQU0sY0FBY0EsTUFBTSxvQkFDdEUsK0JBQStCRSxLQUFLNU0sR0FBRztBQUFBLEVBRTNDO0FBRUEsTUFBSTZNLFVBQVV2RCxVQUFVbUQsS0FBS2pELGdCQUFnQmlELEtBQUtoRCxTQUFTZ0QsS0FBSy9DLFFBQVErQyxLQUFLOUMsYUFBYThDLEtBQUs3QyxRQUFRNkMsS0FBSzVDLE1BQU07QUFDbEgsTUFBSWlELFdBQVd4RCxVQUFVbUQsS0FBS0ssWUFBWUwsS0FBS00sY0FBY04sS0FBS08sT0FBTztBQUN6RSxNQUFJbEQsT0FBT1IsVUFBVW1ELEtBQUszQyxRQUFRMkMsS0FBS3pDLFVBQVV5QyxLQUFLeEMsV0FBV3dDLEtBQUt2QyxJQUFJO0FBQzFFLE1BQUlHLFdBQVdmLFVBQVVtRCxLQUFLakMsTUFBTSxLQUFLbEIsVUFBVW1ELEtBQUtsQyxhQUFhLEtBQUtqQixVQUFVbUQsS0FBS25DLFdBQVcsS0FBS2hCLFVBQVVtRCxLQUFLaEMsT0FBTyxLQUFLbkIsVUFBVW1ELEtBQUsvQixNQUFNLEtBQUs7QUFDOUosTUFBSUUsT0FBT3RCLFVBQVVtRCxLQUFLN0IsUUFBUTZCLEtBQUs1QixRQUFRNEIsS0FBSzNCLGdCQUFnQjJCLEtBQUsxQixpQkFBaUIwQixLQUFLOUIsV0FBVzhCLEtBQUt6QixVQUFVeUIsS0FBS3hCLGNBQWMsRUFBRW5KLFFBQVEsaUJBQWlCLEVBQUUsRUFBRXRILEtBQUs7QUFDaEwsTUFBSTRSLFFBQVE5QyxVQUFVbUQsS0FBS0wsS0FBSztBQUNoQyxNQUFJbEIsVUFBVTVCLFVBQVVtRCxLQUFLckIsWUFBWXFCLEtBQUtwQixXQUFXO0FBRXpELFFBQU00QixlQUFlLENBQUNKLFNBQVNDLFVBQVVoRCxNQUFNTyxRQUFRLEVBQUU1RixPQUFPQyxPQUFPO0FBQ3ZFLFFBQU13SSxjQUFjQSxDQUFDbE4sUUFBU0EsT0FBT0EsSUFBSXhGLEtBQUssSUFBSXdGLE1BQU1pTixhQUFhLENBQUMsS0FBSztBQUUzRUosWUFBVUssWUFBWUwsT0FBTztBQUM3QkMsYUFBV0ksWUFBWUosUUFBUTtBQUMvQmhELFNBQU9vRCxZQUFZcEQsSUFBSTtBQUN2Qk8sYUFBVzZDLFlBQVk3QyxRQUFRO0FBRS9CLE1BQUlzQyxXQUFXRSxPQUFPLEVBQUdBLFdBQVU7QUFDbkMsTUFBSUYsV0FBV0csUUFBUSxFQUFHQSxZQUFXO0FBQ3JDLE1BQUlILFdBQVc3QyxJQUFJLEVBQUdBLFFBQU87QUFDN0IsTUFBSTZDLFdBQVd0QyxRQUFRLEVBQUdBLFlBQVc7QUFDckMsTUFBSXNDLFdBQVcvQixJQUFJLEVBQUdBLFFBQU87QUFDN0IsTUFBSStCLFdBQVdQLEtBQUssRUFBR0EsU0FBUTtBQUUvQixRQUFNZCxRQUFRO0FBQ2QsTUFBSTZCLG9CQUFvQixDQUFDTixTQUFTQyxRQUFRLEVBQUVySSxPQUFPQyxPQUFPLEVBQUVLLEtBQUssSUFBSTtBQUNyRSxNQUFJOEgsV0FBV0MsYUFBYUQsUUFBUXJNLFlBQVksRUFBRWpFLFNBQVN1USxTQUFTdE0sWUFBWSxDQUFDLEtBQUtzTSxTQUFTdE0sWUFBWSxFQUFFakUsU0FBU3NRLFFBQVFyTSxZQUFZLENBQUMsSUFBSTtBQUM3STJNLHdCQUFvQk4sUUFBUTlLLFNBQVMrSyxTQUFTL0ssU0FBUzhLLFVBQVVDO0FBQUFBLEVBQ25FO0FBQ0EsTUFBSUssa0JBQW1CN0IsT0FBTVUsS0FBS21CLGlCQUFpQjtBQUNuRCxNQUFJckQsS0FBTXdCLE9BQU1VLEtBQUtsQyxJQUFJO0FBRXpCLE1BQUkwQyxhQUFhO0FBQ2YsVUFBTVksZUFBZVosWUFBWWhJLE1BQU0sR0FBRyxFQUFFRyxJQUFJMkUsU0FBUyxFQUFFN0UsT0FBTyxDQUFBNEksTUFBS0EsS0FBSyxDQUFDVixXQUFXVSxDQUFDLENBQUM7QUFDMUYsVUFBTUMsWUFBWTFDLE9BQU9BLEtBQUtwSyxZQUFZLElBQUk7QUFDOUMsVUFBTStNLGFBQWFuQixRQUFRQSxNQUFNNUwsWUFBWSxJQUFJO0FBQ2pELGVBQVdnTixNQUFNSixjQUFjO0FBQzdCLFlBQU1LLFVBQVVELEdBQUdoTixZQUFZO0FBQy9CLFVBQUlpTixRQUFRbFIsU0FBUyxPQUFPLEtBQUtrUixRQUFRbFIsU0FBUyxRQUFRLEtBQUtrUixRQUFRbFIsU0FBUyxPQUFPLEtBQUtrUixRQUFRbFIsU0FBUyxRQUFRLEtBQUtrUixRQUFRbFIsU0FBUyxRQUFRLEtBQUtrUixRQUFRbFIsU0FBUyxNQUFNLEtBQUtrUixRQUFRbFIsU0FBUyxPQUFPLEdBQUc7QUFDN00sY0FBTXdQLFVBQVVULE1BQU1LLEtBQUssQ0FBQTBCLE1BQUtBLEVBQUU3TSxZQUFZLEVBQUVqRSxTQUFTa1IsT0FBTyxLQUFLQSxRQUFRbFIsU0FBUzhRLEVBQUU3TSxZQUFZLENBQUMsQ0FBQztBQUN0RyxZQUFJLENBQUN1TCxXQUFXMEIsWUFBWUgsYUFBYUcsWUFBWUYsV0FBWWpDLE9BQU1VLEtBQUt3QixFQUFFO0FBQUEsTUFDaEY7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUluRCxZQUFZLENBQUNpQixNQUFNSyxLQUFLLENBQUEwQixNQUFLQSxFQUFFN00sWUFBWSxFQUFFakUsU0FBUzhOLFNBQVM3SixZQUFZLENBQUMsS0FBSzZKLFNBQVM3SixZQUFZLEVBQUVqRSxTQUFTOFEsRUFBRTdNLFlBQVksQ0FBQyxDQUFDLEVBQUc4SyxPQUFNVSxLQUFLM0IsUUFBUTtBQUMzSixNQUFJTyxRQUFRLENBQUNVLE1BQU1LLEtBQUssQ0FBQTBCLE1BQUtBLEVBQUU3TSxZQUFZLEVBQUVqRSxTQUFTcU8sS0FBS3BLLFlBQVksQ0FBQyxLQUFLb0ssS0FBS3BLLFlBQVksRUFBRWpFLFNBQVM4USxFQUFFN00sWUFBWSxDQUFDLENBQUMsRUFBRzhLLE9BQU1VLEtBQUtwQixJQUFJO0FBQzNJLE1BQUl3QixPQUFPO0FBQ1QsVUFBTUwsVUFBVVQsTUFBTUssS0FBSyxDQUFBMEIsTUFBS0EsRUFBRTdNLFlBQVksRUFBRWpFLFNBQVM2UCxNQUFNNUwsWUFBWSxDQUFDLEtBQUs0TCxNQUFNNUwsWUFBWSxFQUFFakUsU0FBUzhRLEVBQUU3TSxZQUFZLENBQUMsQ0FBQztBQUM5SCxRQUFJa04sY0FBY3hDLFVBQVUsR0FBR2tCLEtBQUssSUFBSWxCLE9BQU8sS0FBS2tCO0FBQ3BELFFBQUksQ0FBQ0wsUUFBU1QsT0FBTVUsS0FBSzBCLFdBQVc7QUFBQSxTQUMvQjtBQUNILFlBQU1DLE1BQU1yQyxNQUFNc0MsVUFBVSxDQUFBUCxNQUFLQSxFQUFFN00sWUFBWSxFQUFFakUsU0FBUzZQLE1BQU01TCxZQUFZLENBQUMsQ0FBQztBQUM5RSxVQUFJbU4sUUFBUSxHQUFJckMsT0FBTXFDLEdBQUcsSUFBSUQ7QUFBQUEsSUFDL0I7QUFBQSxFQUNGLFdBQVd4QyxRQUFTSSxPQUFNVSxLQUFLZCxPQUFPO0FBRXRDLFFBQU0yQyxjQUFjO0FBQ3BCLGFBQVd0QyxRQUFRRCxPQUFPO0FBQ3hCLFFBQUksQ0FBQ3VDLFlBQVlsQyxLQUFLLENBQUEwQixNQUFLQSxFQUFFN00sWUFBWSxNQUFNK0ssS0FBSy9LLFlBQVksQ0FBQyxFQUFHcU4sYUFBWTdCLEtBQUtULElBQUk7QUFBQSxFQUMzRjtBQUNBLFNBQU9zQyxZQUFZOUksS0FBSyxJQUFJO0FBQzlCO0FBRU8sYUFBTStJLHFCQUFxQkEsQ0FBQ3ZCLFlBQVlDLGNBQWMsT0FBTztBQUNsRSxRQUFNQyxPQUFPRixjQUFjLENBQUM7QUFDNUIsUUFBTWpELFlBQVlBLENBQUN0SixRQUFRO0FBQ3pCLFFBQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLFFBQUkwTSxJQUFJMU0sSUFBSWtCLFNBQVMsRUFBRTFHLEtBQUs7QUFDNUJrUyxRQUFJQSxFQUFFNUssUUFBUSxpQ0FBaUMsRUFBRSxFQUFFQSxRQUFRLHdCQUF3QixFQUFFLEVBQUV0SCxLQUFLO0FBQzVGLFdBQU9rUztBQUFBQSxFQUNUO0FBRUEsUUFBTUMsYUFBYUEsQ0FBQzNNLFFBQVE7QUFDMUIsUUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsVUFBTTBNLElBQUkxTSxJQUFJa0IsU0FBUyxFQUFFVixZQUFZO0FBQ3JDLFdBQU9rTSxFQUFFblEsU0FBUyxRQUFRLEtBQUttUSxFQUFFblEsU0FBUyxRQUFRLEtBQUttUSxFQUFFblEsU0FBUyxhQUFhLEtBQUttUSxNQUFNLFdBQVdBLE1BQU0sWUFBWUEsTUFBTSxjQUFjLCtCQUErQkUsS0FBSzVNLEdBQUc7QUFBQSxFQUNwTDtBQUVBLE1BQUk2TSxVQUFVdkQsVUFBVW1ELEtBQUtqRCxnQkFBZ0JpRCxLQUFLaEQsU0FBU2dELEtBQUsvQyxRQUFRK0MsS0FBSzlDLGFBQWE4QyxLQUFLN0MsUUFBUTZDLEtBQUs1QyxNQUFNO0FBQ2xILE1BQUlpRCxXQUFXeEQsVUFBVW1ELEtBQUtLLFlBQVlMLEtBQUtNLGNBQWNOLEtBQUtPLE9BQU87QUFDekUsTUFBSWxELE9BQU9SLFVBQVVtRCxLQUFLM0MsUUFBUTJDLEtBQUt6QyxVQUFVeUMsS0FBS3hDLFdBQVd3QyxLQUFLdkMsSUFBSTtBQUMxRSxNQUFJSSxjQUFjaEIsVUFBVW1ELEtBQUtuQyxlQUFlbUMsS0FBS3NCLFdBQVc7QUFDaEUsTUFBSXhELGdCQUFnQmpCLFVBQVVtRCxLQUFLbEMsaUJBQWlCa0MsS0FBS2hDLE9BQU87QUFDaEUsTUFBSUQsU0FBU2xCLFVBQVVtRCxLQUFLakMsVUFBVWlDLEtBQUs5QixXQUFXOEIsS0FBS3VCLFFBQVE7QUFDbkUsTUFBSXZELFVBQVVuQixVQUFVbUQsS0FBS2hDLE9BQU87QUFDcEMsTUFBSUMsU0FBU3BCLFVBQVVtRCxLQUFLL0IsTUFBTTtBQUNsQyxNQUFJUCxXQUFXYixVQUFVbUQsS0FBS3RDLFlBQVlzQyxLQUFLd0IsU0FBU3hCLEtBQUt5QixjQUFjekIsS0FBSzBCLFVBQVU7QUFDMUYsTUFBSXZELE9BQU90QixVQUFVbUQsS0FBSzdCLFFBQVE2QixLQUFLNUIsUUFBUTRCLEtBQUszQixnQkFBZ0IyQixLQUFLMUIsaUJBQWlCMEIsS0FBSzlCLFdBQVc4QixLQUFLekIsVUFBVXlCLEtBQUt4QixjQUFjLEVBQUVuSixRQUFRLGlCQUFpQixFQUFFLEVBQUV0SCxLQUFLO0FBQ2hMLE1BQUk0UixRQUFROUMsVUFBVW1ELEtBQUtMLEtBQUs7QUFDaEMsTUFBSWxCLFVBQVU1QixVQUFVbUQsS0FBS3JCLFlBQVlxQixLQUFLcEIsV0FBVztBQUV6RCxNQUFJaEIsV0FBV0csVUFBVUQsaUJBQWlCRCxlQUFlRyxXQUFXQyxVQUFVO0FBQzlFLE1BQUlOLE9BQU9DLFlBQVk7QUFDdkIsUUFBTTRDLGVBQWUsQ0FBQ0osU0FBU0MsVUFBVWhELE1BQU1RLGFBQWFFLFFBQVFELGFBQWEsRUFBRTlGLE9BQU9DLE9BQU87QUFDakcsUUFBTXdJLGNBQWNBLENBQUNsTixRQUFTQSxPQUFPQSxJQUFJeEYsS0FBSyxJQUFJd0YsTUFBTWlOLGFBQWEsQ0FBQyxLQUFLO0FBRTNFLE1BQUltQixtQkFBbUJsQixZQUFZTCxPQUFPO0FBQzFDLE1BQUl3QixnQkFBZ0JuQixZQUFZSixRQUFRO0FBQ3hDLE1BQUl3QixZQUFZcEIsWUFBWXBELElBQUk7QUFDaEMsTUFBSXlFLGdCQUFnQnJCLFlBQVk3QyxRQUFRO0FBQ3hDLE1BQUltRSxnQkFBZ0J0QixZQUFZL0MsUUFBUTtBQUN4QyxNQUFJc0UsWUFBWXZCLFlBQVk5QyxJQUFJO0FBQ2hDLE1BQUlzRSxZQUFZOUQsUUFBUVAsWUFBWTtBQUNwQyxNQUFJc0UsYUFBYXZDLFNBQVM7QUFDMUIsTUFBSXdDLGVBQWUxRCxXQUFXO0FBRTlCLE1BQUl5QixXQUFXeUIsZ0JBQWdCLEVBQUdBLG9CQUFtQjtBQUNyRCxNQUFJekIsV0FBVzBCLGFBQWEsRUFBR0EsaUJBQWdCO0FBQy9DLE1BQUkxQixXQUFXMkIsU0FBUyxFQUFHQSxhQUFZO0FBQ3ZDLE1BQUkzQixXQUFXNEIsYUFBYSxFQUFHQSxpQkFBZ0I7QUFDL0MsTUFBSTVCLFdBQVc2QixhQUFhLEVBQUdBLGlCQUFnQjtBQUMvQyxNQUFJN0IsV0FBVzhCLFNBQVMsRUFBR0EsYUFBWTtBQUN2QyxNQUFJOUIsV0FBVytCLFNBQVMsRUFBR0EsYUFBWTtBQUN2QyxNQUFJL0IsV0FBV2dDLFVBQVUsRUFBR0EsY0FBYTtBQUV6Q1AscUJBQW1CbEIsWUFBWWtCLGdCQUFnQjtBQUMvQ0Msa0JBQWdCbkIsWUFBWW1CLGFBQWE7QUFDekNDLGNBQVlwQixZQUFZb0IsU0FBUztBQUNqQ0Msa0JBQWdCckIsWUFBWXFCLGFBQWE7QUFDekNFLGNBQVl2QixZQUFZdUIsU0FBUztBQUVqQyxNQUFJSSxhQUFhLENBQUNULGtCQUFrQkMsZUFBZUMsV0FBV0MsYUFBYSxFQUFFOUosT0FBT0MsT0FBTztBQUMzRixNQUFJOEgsYUFBYTtBQUNmLFVBQU1ZLGVBQWVaLFlBQVloSSxNQUFNLEdBQUcsRUFBRUcsSUFBSTJFLFNBQVMsRUFBRTdFLE9BQU8sQ0FBQTRJLE1BQUtBLEtBQUssQ0FBQ1YsV0FBV1UsQ0FBQyxDQUFDO0FBQzFGLFVBQU1DLFlBQVlvQixVQUFVbE8sWUFBWTtBQUN4QyxVQUFNK00sYUFBYW9CLFdBQVduTyxZQUFZO0FBQzFDLFVBQU1zTyxlQUFlRixhQUFhcE8sWUFBWTtBQUU5QyxlQUFXZ04sTUFBTUosY0FBYztBQUM3QixZQUFNSyxVQUFVRCxHQUFHaE4sWUFBWTtBQUMvQixVQUFJaU4sWUFBWUgsYUFBYUcsWUFBWUYsY0FBY0UsWUFBWXFCLGdCQUFpQnhCLGFBQWFBLFVBQVUvUSxTQUFTa1IsT0FBTyxLQUFPRixjQUFjQSxXQUFXaFIsU0FBU2tSLE9BQU8sRUFBSTtBQUMvSyxZQUFNc0IsaUJBQWlCRixXQUFXbEQsS0FBSyxDQUFBcUQsTUFBSztBQUMxQyxjQUFNQyxTQUFTRCxFQUFFeE8sWUFBWTtBQUM3QixlQUFPeU8sT0FBTzFTLFNBQVNrUixPQUFPLEtBQUtBLFFBQVFsUixTQUFTMFMsTUFBTTtBQUFBLE1BQzVELENBQUM7QUFDRCxVQUFJLENBQUNGLGdCQUFnQjtBQUNuQkYsbUJBQVc3QyxLQUFLd0IsRUFBRTtBQUNsQixZQUFJLENBQUNjLFVBQVdBLGFBQVlkO0FBQUFBLGlCQUNuQixDQUFDZSxpQkFBaUJBLGtCQUFrQkQsVUFBV0MsaUJBQWdCZjtBQUFBQSxNQUMxRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTTBCLG1CQUFtQjtBQUN6QixhQUFXQyxRQUFRTixZQUFZO0FBQzdCLFVBQU1PLFlBQVlELEtBQUszTyxZQUFZO0FBQ25DLFFBQUk2TyxRQUFRO0FBQ1osYUFBU25NLElBQUksR0FBR0EsSUFBSWdNLGlCQUFpQm5OLFFBQVFtQixLQUFLO0FBQ2hELFlBQU00SSxnQkFBZ0JvRCxpQkFBaUJoTSxDQUFDLEVBQUUxQyxZQUFZO0FBQ3RELFVBQUlzTCxrQkFBa0JzRCxhQUFhdEQsY0FBY3ZQLFNBQVM2UyxTQUFTLEdBQUc7QUFDcEVDLGdCQUFRO0FBQ1I7QUFBQSxNQUNGO0FBQ0EsVUFBSUQsVUFBVTdTLFNBQVN1UCxhQUFhLEdBQUc7QUFDckNvRCx5QkFBaUJoTSxDQUFDLElBQUlpTTtBQUN0QkUsZ0JBQVE7QUFDUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDQSxNQUFPSCxrQkFBaUJsRCxLQUFLbUQsSUFBSTtBQUFBLEVBQ3hDO0FBRUEsTUFBSUcsZ0JBQWdCSixpQkFBaUJuSyxLQUFLLElBQUk7QUFDOUMsUUFBTXdLLG1CQUFtQmpELG9CQUFvQkcsTUFBTUQsV0FBVztBQUM5RCxRQUFNZ0QscUJBQXFCcEcsb0JBQW9CO0FBQUEsSUFDN0NHLGFBQWE2RTtBQUFBQSxJQUNidEUsTUFBTXdFO0FBQUFBLElBQ05sRSxNQUFNcUUsYUFBYUY7QUFBQUEsSUFDbkIzRCxNQUFNOEQ7QUFBQUEsSUFDTnhELFNBQVMwRDtBQUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNYSxxQkFBcUIsQ0FBQyxFQUFFNUMsV0FBV0MsWUFBWWhELFFBQVFRLGVBQWVDLGlCQUFpQkMsVUFBVUMsV0FBV0MsVUFBVVA7QUFFNUgsU0FBTztBQUFBLElBQ0xILFFBQVFzRixpQkFBaUJoQixhQUFhaUIsb0JBQW9CO0FBQUEsSUFDMUQzRSxNQUFNOEQ7QUFBQUEsSUFDTnRDLE9BQU91QztBQUFBQSxJQUNQeEQsWUFBWXlEO0FBQUFBLElBQ1oxRCxTQUFTMEQ7QUFBQUEsSUFDVHpDLGFBQWFtRCxpQkFBaUJoQixhQUFhO0FBQUEsSUFDM0MvRSxhQUFhNkUsb0JBQW9CO0FBQUEsSUFDakN0QixVQUFVdUIsaUJBQWlCO0FBQUEsSUFDM0J2RSxNQUFNd0UsYUFBYTtBQUFBLElBQ25CakUsVUFBVWtFLGlCQUFpQjtBQUFBLElBQzNCcEUsVUFBVXFFLGlCQUFpQjtBQUFBLElBQzNCcEUsTUFBTXFFLGFBQWFGLGlCQUFpQjtBQUFBLElBQ3BDbEMsU0FBUy9DLFVBQVVtRCxLQUFLSixPQUFPLEtBQUs7QUFBQSxJQUNwQ2tELGtCQUFrQkMsc0JBQXNCRCxvQkFBb0JELGlCQUFpQjtBQUFBLElBQzdFSSxrQkFBa0IsQ0FBQ0Q7QUFBQUEsSUFDbkJFLEtBQUs7QUFBQSxJQUNMQyxLQUFLO0FBQUEsRUFDUDtBQUNGO0FBRU8sYUFBTUMsa0JBQWtCO0FBQ3hCLGFBQU1DLHdCQUF3QjtBQUVyQyxNQUFNQyxnQkFBZ0Isb0JBQUlyUyxJQUFJO0FBQzlCLE1BQU1zUyx1QkFBdUIsSUFBSSxLQUFLO0FBQ3RDLE1BQU1DLHFCQUFxQjtBQUMzQixNQUFNQyxnQkFBZ0JBLENBQUNQLEtBQUtDLFFBQVEsR0FBR2xWLE9BQU9pVixHQUFHLEVBQUUxTyxRQUFRLENBQUMsQ0FBQyxJQUFJdkcsT0FBT2tWLEdBQUcsRUFBRTNPLFFBQVEsQ0FBQyxDQUFDO0FBRXZGLE1BQU1rUCx1QkFBdUJBLENBQUNDLGFBQWFDLGVBQWU3RCxnQkFBZ0I7QUFDeEUsUUFBTWEsSUFBSStDLGVBQWUsQ0FBQztBQUMxQixRQUFNdlAsSUFBSXdQLGlCQUFpQixDQUFDO0FBQzVCLFNBQU87QUFBQSxJQUNMN0csY0FBYzZELEVBQUVpRCxlQUFlelAsRUFBRTJJLGdCQUFnQjNJLEVBQUU0SSxTQUFTO0FBQUEsSUFDNURxRCxVQUFVTyxFQUFFekUsUUFBUS9ILEVBQUVpTSxZQUFZak0sRUFBRWtNLGNBQWM7QUFBQSxJQUNsRGpELE1BQU11RCxFQUFFckQsVUFBVW5KLEVBQUVpSixRQUFRakosRUFBRW1KLFVBQVVuSixFQUFFb0osV0FBVztBQUFBLElBQ3JETSxlQUFlMUosRUFBRTBKLGlCQUFpQjFKLEVBQUU0SixXQUFXNUosRUFBRXlKLGVBQWU7QUFBQSxJQUNoRUUsUUFBUTZDLEVBQUVrRCxZQUFZMVAsRUFBRTJKLFVBQVUzSixFQUFFa0ssaUJBQWlCO0FBQUEsSUFDckRILE1BQU15QyxFQUFFekMsUUFBUS9KLEVBQUUrSixRQUFRL0osRUFBRWdLLFFBQVFoSyxFQUFFaUssZ0JBQWdCakssRUFBRWtLLGlCQUFpQmxLLEVBQUU4SixXQUFXOUosRUFBRW1LLFVBQVVuSyxFQUFFb0ssa0JBQWtCO0FBQUEsSUFDdEhtQixPQUFPaUIsRUFBRWpCLFNBQVN2TCxFQUFFdUwsU0FBUztBQUFBLElBQzdCaEIsVUFBVWlDLEVBQUVqQyxZQUFZdkssRUFBRXVLLFlBQVk7QUFBQSxJQUN0Q2lCLFNBQVNnQixFQUFFaEIsV0FBV3hMLEVBQUV3TCxXQUFXO0FBQUEsSUFDbkNsQyxVQUFVdEosRUFBRW1NLFdBQVduTSxFQUFFb04sU0FBUztBQUFBLElBQ2xDdUMsY0FBY2hFLGVBQWU7QUFBQSxFQUMvQjtBQUNGO0FBRU8sYUFBTWlFLGlCQUFpQixPQUFPZCxLQUFLQyxRQUFRO0FBQ2hELFFBQU10UixXQUFXNFIsY0FBY1AsS0FBS0MsR0FBRztBQUN2QyxRQUFNYyxTQUFTWCxjQUFjdlIsSUFBSUYsUUFBUTtBQUN6QyxNQUFJb1MsVUFBVWhWLEtBQUt1QixJQUFJLElBQUl5VCxPQUFPQyxLQUFLWCxzQkFBc0I7QUFDM0QsV0FBT1UsT0FBT0U7QUFBQUEsRUFDaEI7QUFFQSxNQUFJUixjQUFjO0FBQ2xCLE1BQUlDLGdCQUFnQjtBQUNwQixNQUFJN0QsY0FBYztBQUVsQixNQUFJO0FBQ0YsVUFBTXFFLFNBQVMsTUFBTUM7QUFBQUEsTUFDbkIsaUVBQWlFbkIsR0FBRyxRQUFRQyxHQUFHO0FBQUEsTUFDL0UsRUFBRW1CLFNBQVMsRUFBRSxjQUFjZCxtQkFBbUIsRUFBRTtBQUFBLElBQ2xEO0FBQ0EsVUFBTWUsVUFBVSxNQUFNSCxPQUFPSSxLQUFLO0FBQ2xDLFFBQUlELFNBQVMzSCxTQUFTO0FBQ3BCZ0gsc0JBQWdCVyxRQUFRM0g7QUFDeEJtRCxvQkFBY3dFLFFBQVFFLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixRQUFRO0FBQUEsRUFBRTtBQUVWLE1BQUksQ0FBQ2IsZUFBZTtBQUNsQixRQUFJO0FBQ0YsWUFBTWMsWUFBWSxNQUFNTCxNQUFNLHdDQUF3Q25CLEdBQUcsUUFBUUMsR0FBRyxVQUFVO0FBQzlGLFlBQU13QixhQUFhLE1BQU1ELFVBQVVGLEtBQUs7QUFDeEMsVUFBSUcsWUFBWUMsV0FBVyxDQUFDLEdBQUdDLFlBQVk7QUFDekNsQixzQkFBY2dCLFdBQVdDLFNBQVMsQ0FBQyxFQUFFQztBQUNyQyxjQUFNQyxRQUFRSCxXQUFXQyxTQUFTLENBQUMsRUFBRUM7QUFDckM5RSxzQkFBYytFLE1BQU0zSSxRQUFRMkksTUFBTXZILFVBQVU7QUFDNUMsWUFBSXVILE1BQU0zRyxLQUFNNEIsaUJBQWdCQSxjQUFjLE9BQU8sTUFBTStFLE1BQU0zRztBQUNqRSxZQUFJMkcsTUFBTW5GLE1BQU9JLGlCQUFnQkEsY0FBYyxPQUFPLE1BQU0rRSxNQUFNbkY7QUFBQUEsTUFDcEU7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUFFO0FBQUEsRUFDWjtBQUVBLE1BQUlvRixTQUFTckIscUJBQXFCQyxhQUFhQyxlQUFlN0QsV0FBVztBQUN6RSxNQUFJaUYsYUFBYTNELG1CQUFtQjBELFFBQVFoRixXQUFXO0FBQ3ZEaUYsYUFBVzlCLE1BQU1BO0FBQ2pCOEIsYUFBVzdCLE1BQU1BO0FBRWpCRyxnQkFBY2pSLElBQUlSLFVBQVUsRUFBRXFTLElBQUlqVixLQUFLdUIsSUFBSSxHQUFHMlQsTUFBTWEsV0FBVyxDQUFDO0FBQ2hFLFNBQU9BO0FBQ1Q7QUFFTyxhQUFNQyx3QkFBd0JBLENBQUNsVyxVQUFVLENBQUMsTUFBTTtBQUNyRCxRQUFNbVcsaUJBQWlCblcsUUFBUW1XLGtCQUFrQjtBQUNqRCxRQUFNQyxhQUFhcFcsUUFBUW9XLGNBQWM7QUFDekMsUUFBTUMsWUFBWXJXLFFBQVFzVyxXQUFXO0FBQ3JDLFFBQU1DLGFBQWF2VyxRQUFRdVcsY0FBYztBQUN6QyxNQUFJQyxhQUFhO0FBRWpCLFFBQU1DLG1CQUFtQkEsTUFDdkIsSUFBSTFLLFFBQVEsQ0FBQ0MsU0FBUzBLLFdBQVc7QUFDL0IsUUFBSSxDQUFDek0sVUFBVTBNLGFBQWE7QUFDMUJELGFBQU8sSUFBSUUsTUFBTSw4Q0FBOEMsQ0FBQztBQUNoRTtBQUFBLElBQ0Y7QUFDQSxRQUFJQyxVQUFVO0FBQ2QsUUFBSUMsY0FBYztBQUNsQixRQUFJQyxVQUFVO0FBRWQsVUFBTUMsaUJBQWlCQSxNQUFNO0FBQzNCLFVBQUlILFlBQVksTUFBTTtBQUNwQjVNLGtCQUFVME0sWUFBWU0sV0FBV0osT0FBTztBQUN4Q0Esa0JBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUVBLFVBQU1LLFlBQVlDLFdBQVcsTUFBTTtBQUNqQ0gscUJBQWU7QUFDZixVQUFJRCxXQUFXQSxRQUFRSyxPQUFPQyxZQUFZbEIsZ0JBQWdCO0FBQ3hEbUIsd0JBQWdCUCxPQUFPO0FBQUEsTUFDekIsV0FBV0EsU0FBUztBQUNsQk8sd0JBQWdCUCxPQUFPO0FBQUEsTUFDekIsT0FBTztBQUNMOU0sa0JBQVUwTSxZQUFZWTtBQUFBQSxVQUNwQixDQUFDQyxnQkFBZ0JGLGdCQUFnQkUsV0FBVztBQUFBLFVBQzVDLENBQUNDLGdCQUFnQmYsT0FBTyxJQUFJRSxNQUFNLGtFQUFrRSxDQUFDO0FBQUEsVUFDckcsRUFBRWMsb0JBQW9CLE9BQU9wQixTQUFTLElBQUs7QUFBQSxRQUM3QztBQUFBLE1BQ0Y7QUFBQSxJQUNGLEdBQUdELFNBQVM7QUFFWixVQUFNaUIsa0JBQWtCLE9BQU9LLFFBQVE7QUFDckNDLG1CQUFhVixTQUFTO0FBQ3RCRixxQkFBZTtBQUNmLFVBQUk7QUFDRixjQUFNLEVBQUVhLFVBQVVDLFdBQVdULFNBQVMsSUFBSU0sSUFBSVA7QUFDOUMsY0FBTXZKLFVBQVUsTUFBTW9ILGVBQWU0QyxVQUFVQyxTQUFTO0FBQ3hELGNBQU1DLFdBQVdwWixpQkFBaUJrWixVQUFVQyxXQUFXLEVBQUU7QUFDekQsY0FBTUUsa0JBQWtCclosaUJBQWlCa1osVUFBVUMsV0FBVyxFQUFFO0FBQ2hFOUwsZ0JBQVEsRUFBRTZMLFVBQVVDLFdBQVdULFVBQVV4SixTQUFTLEVBQUUsR0FBR0EsU0FBU3NHLEtBQUswRCxVQUFVekQsS0FBSzBELFdBQVdDLFVBQVVDLGdCQUFnQixFQUFFLENBQUM7QUFBQSxNQUM5SCxTQUFTbk4sS0FBSztBQUNaNkwsZUFBTzdMLEdBQUc7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUVBZ00sY0FBVTVNLFVBQVUwTSxZQUFZc0I7QUFBQUEsTUFDOUIsQ0FBQ04sUUFBUTtBQUNQYjtBQUNBLFlBQUksQ0FBQ0MsV0FBV1ksSUFBSVAsT0FBT0MsV0FBV04sUUFBUUssT0FBT0MsVUFBVTtBQUM3RE4sb0JBQVVZO0FBQUFBLFFBQ1o7QUFDQSxZQUFJQSxJQUFJUCxPQUFPQyxZQUFZbEIsa0JBQWtCVyxlQUFlVixZQUFZO0FBQ3RFa0IsMEJBQWdCUCxXQUFXWSxHQUFHO0FBQUEsUUFDaEM7QUFBQSxNQUNGO0FBQUEsTUFDQSxDQUFDOU0sUUFBUTtBQUNQK00scUJBQWFWLFNBQVM7QUFDdEJGLHVCQUFlO0FBQ2YsWUFBSW5NLElBQUlxTixTQUFTLEtBQUtyTixJQUFJcU4sU0FBUyxHQUFHO0FBQ3BDak8sb0JBQVUwTSxZQUFZWTtBQUFBQSxZQUNwQixDQUFDQyxnQkFBZ0JGLGdCQUFnQkUsV0FBVztBQUFBLFlBQzVDLENBQUNDLGdCQUFnQmYsT0FBTyxJQUFJRSxNQUFNLDREQUE0RCxDQUFDO0FBQUEsWUFDL0YsRUFBRWMsb0JBQW9CLE9BQU9wQixTQUFTLElBQUs7QUFBQSxVQUM3QztBQUFBLFFBQ0YsT0FBTztBQUNMSSxpQkFBTyxJQUFJRSxNQUFNLDZEQUE2RCxDQUFDO0FBQUEsUUFDakY7QUFBQSxNQUNGO0FBQUEsTUFDQSxFQUFFYyxvQkFBb0IsTUFBTXBCLFNBQVNELFdBQVc4QixZQUFZLEVBQUU7QUFBQSxJQUNoRTtBQUFBLEVBQ0YsQ0FBQztBQUVILFNBQU8xQixpQkFBaUI7QUFDMUI7QUFFTyxhQUFNMkIsd0JBQXdCQSxDQUFDbkMsZUFBZTtBQUNuRCxRQUFNOUIsTUFBTThCLFdBQVc5QjtBQUN2QixRQUFNQyxNQUFNNkIsV0FBVzdCO0FBQ3ZCLFFBQU0yRCxXQUFZNUQsT0FBT0MsTUFBT3pWLGlCQUFpQndWLEtBQUtDLEtBQUssRUFBRSxJQUFLNkIsV0FBVzhCLFlBQVk7QUFDekYsUUFBTUMsa0JBQW1CN0QsT0FBT0MsTUFBT3pWLGlCQUFpQndWLEtBQUtDLEtBQUssRUFBRSxJQUFLNkIsV0FBVytCLG1CQUFtQjtBQUN2RyxRQUFNakUsbUJBQW1Cbkcsb0JBQW9CcUksVUFBVSxLQUFLQSxXQUFXbEMsb0JBQW9CakQsb0JBQW9CbUYsWUFBWSxFQUFFO0FBQzdILFNBQU87QUFBQSxJQUNMekgsUUFBUXlILFdBQVd6SCxVQUFVeUgsV0FBV3RGLGVBQWVvRCxvQkFBb0I7QUFBQSxJQUMzRTNFLE1BQU02RyxXQUFXN0csUUFBUTtBQUFBLElBQ3pCd0IsT0FBT3FGLFdBQVdyRixTQUFTO0FBQUEsSUFDM0JqQixZQUFZc0csV0FBV3RHLGNBQWNzRyxXQUFXdkcsV0FBVztBQUFBLElBQzNEbUIsU0FBU29GLFdBQVdwRixXQUFXO0FBQUEsSUFDL0JzRDtBQUFBQSxJQUNBQztBQUFBQSxJQUNBMkQ7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQXJILGFBQWFzRixXQUFXdEYsZUFBZXNGLFdBQVd6SCxVQUFVO0FBQUEsSUFDNURULGFBQWFrSSxXQUFXbEksZUFBZTtBQUFBLElBQ3ZDTyxNQUFNMkgsV0FBVzNILFFBQVE7QUFBQSxJQUN6QkssVUFBVXNILFdBQVd0SCxZQUFZO0FBQUEsSUFDakNDLE1BQU1xSCxXQUFXckgsUUFBUTtBQUFBLElBQ3pCYyxTQUFTdUcsV0FBV3ZHLFdBQVd1RyxXQUFXdEcsY0FBYztBQUFBLElBQ3hEb0U7QUFBQUEsRUFDRjtBQUNGO0FBRU8sYUFBTXNFLGtCQUFrQkEsQ0FBQ0MsTUFBTUMsTUFBTUMsWUFBWSxNQUFNO0FBQzVELE1BQUksQ0FBQ0YsUUFBUUEsS0FBS25FLE9BQU8sUUFBUW1FLEtBQUtsRSxPQUFPLEtBQU0sUUFBT21FO0FBQzFELFFBQU1FLElBQUk7QUFDVixRQUFNQyxRQUFTSCxLQUFLcEUsTUFBTW1FLEtBQUtuRSxPQUFPeFMsS0FBS2dYLEtBQU07QUFDakQsUUFBTUMsUUFBU0wsS0FBS25FLE1BQU1rRSxLQUFLbEUsT0FBT3pTLEtBQUtnWCxLQUFNO0FBQ2pELFFBQU1FLElBQUlsWCxLQUFLbVgsSUFBSUosT0FBTyxDQUFDLEtBQUssSUFBSS9XLEtBQUtvWCxJQUFLVCxLQUFLbkUsTUFBTXhTLEtBQUtnWCxLQUFNLEdBQUcsSUFBSWhYLEtBQUtvWCxJQUFLUixLQUFLcEUsTUFBTXhTLEtBQUtnWCxLQUFNLEdBQUcsSUFBSWhYLEtBQUttWCxJQUFJRixPQUFPLENBQUMsS0FBSztBQUN4SSxRQUFNSSxPQUFPUCxJQUFJLElBQUk5VyxLQUFLc1gsTUFBTXRYLEtBQUt1WCxLQUFLTCxDQUFDLEdBQUdsWCxLQUFLdVgsS0FBSyxJQUFJTCxDQUFDLENBQUM7QUFDOUQsU0FBT0csT0FBT1IsWUFBWUYsT0FBT0M7QUFDbkM7QUFFTyxhQUFNWSxtQkFBbUJBLENBQUNDLE1BQU1DLE1BQU1DLE1BQU1DLFNBQVM7QUFDMUQsUUFBTUMsUUFBU0QsT0FBT0YsUUFBUTFYLEtBQUtnWCxLQUFNO0FBQ3pDLFFBQU1jLFVBQVdMLE9BQU96WCxLQUFLZ1gsS0FBTTtBQUNuQyxRQUFNZSxVQUFXSixPQUFPM1gsS0FBS2dYLEtBQU07QUFDbkMsUUFBTWdCLElBQUloWSxLQUFLbVgsSUFBSVUsSUFBSSxJQUFJN1gsS0FBS29YLElBQUlXLE9BQU87QUFDM0MsUUFBTUUsSUFBSWpZLEtBQUtvWCxJQUFJVSxPQUFPLElBQUk5WCxLQUFLbVgsSUFBSVksT0FBTyxJQUFJL1gsS0FBS21YLElBQUlXLE9BQU8sSUFBSTlYLEtBQUtvWCxJQUFJVyxPQUFPLElBQUkvWCxLQUFLb1gsSUFBSVMsSUFBSTtBQUN2RyxVQUFTN1gsS0FBS3NYLE1BQU1VLEdBQUdDLENBQUMsSUFBSSxNQUFPalksS0FBS2dYLEtBQUssT0FBTztBQUN0RDtBQUVPLGFBQU1rQixxQkFBcUJBLENBQUM5TCxhQUFhTyxTQUFTO0FBQ3ZELFFBQU13TCxZQUFZL0wsZUFBZSxJQUFJL08sS0FBSztBQUMxQyxRQUFNK2EsTUFBTXpMLFFBQVEsSUFBSXRQLEtBQUs7QUFDN0IsU0FBTzhhLFlBQVlDLEtBQUssR0FBR0QsUUFBUSxLQUFLQyxFQUFFLEtBQU1ELFlBQVlDO0FBQzlEO0FBRUEsTUFBTUMsYUFBYTtBQUFBLEVBQ2pCQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsS0FBSztBQUFBLEVBQ0xDLEtBQUs7QUFBQSxFQUNMQyxLQUFLO0FBQUEsRUFDTEMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxLQUFLO0FBQUEsRUFDTEMsTUFBTTtBQUFBLEVBQ05DLEtBQUs7QUFBQSxFQUNMQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLE1BQU07QUFBQSxFQUNOQyxNQUFNO0FBQ1I7QUFFTyxhQUFNQyxpQkFBaUJBLENBQUN2RSxTQUFTO0FBQ3RDLE1BQUksQ0FBQ0EsS0FBTSxRQUFPO0FBQ2xCLFFBQU13RSxZQUFZaGQsT0FBT3dZLElBQUksRUFBRWxaLEtBQUssRUFBRUssWUFBWTtBQUNsRCxRQUFNc2QsV0FBV0QsVUFBVXBXLFFBQVEsZUFBZSxFQUFFO0FBQ3BELFFBQU1zVyxXQUFXNUMsV0FBVzBDLFNBQVMsS0FBSzFDLFdBQVcyQyxRQUFRO0FBQzdELE1BQUlDLFVBQVU7QUFDWixXQUFPLEdBQUdBLFFBQVEsS0FBS0YsU0FBUztBQUFBLEVBQ2xDO0FBQ0EsU0FBT0E7QUFDVCIsIm5hbWVzIjpbImdldENhY2hlZFRpbWVGb3JtYXQiLCJyZWFkQ2FjaGVkU3lzdGVtU2V0dGluZ3MiLCJsYXRMbmdUb1MyQ2VsbElkIiwiRkFMTEJBQ0siLCJwYXJzZUNsb2NrVGltZSIsInRpbWUiLCJtYXRjaCIsInRyaW0iLCJob3VyIiwiTnVtYmVyIiwibWludXRlIiwibWVyaWRpZW0iLCJ0b1VwcGVyQ2FzZSIsImlzTmFOIiwiZm9ybWF0Q2xvY2tUaW1lIiwidGltZUZvcm1hdCIsImZvcm1hdHRlZE1pbnV0ZSIsIlN0cmluZyIsInBhZFN0YXJ0IiwiYW1wbSIsImZvcm1hdHRlZEhvdXIiLCJmb3JtYXREYXRlIiwiZGF0ZSIsIm9wdGlvbnMiLCJkIiwiRGF0ZSIsImdldFRpbWUiLCJzZXR0aW5ncyIsInRpbWV6b25lIiwibG9jYWxlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwidGltZVpvbmUiLCJmbXREYXRlIiwiZm10RGF0ZU9ubHkiLCJmb3JtYXRUaW1lIiwiaW5jbHVkZXMiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyMTIiLCJwYXJzZWRUaW1lIiwiZm9ybWF0RGF0ZVRpbWUiLCJ0IiwiZm10RGF0ZVRpbWUiLCJmb3JtYXRSZWxhdGl2ZVRpbWUiLCJ0aW1lc3RhbXAiLCJkaWZmTXMiLCJub3ciLCJkaWZmU2VjIiwiTWF0aCIsImZsb29yIiwiZGlmZk1pbiIsImRpZmZIciIsImRpZmZEYXkiLCJmbXRSZWxhdGl2ZVRpbWUiLCJjdXJyZW5jeUZvcm1hdHRlcnMiLCJNYXAiLCJudW1iZXJGb3JtYXR0ZXJzIiwiZm9ybWF0Q3VycmVuY3kiLCJhbW91bnQiLCJ1bmRlZmluZWQiLCJjdXJyZW5jeSIsImRlZmF1bHRDdXJyZW5jeSIsIm51bSIsIm1pbkRlY2ltYWxzIiwiZGVjaW1hbFByZWNpc2lvbiIsImFsd2F5c1Nob3dEZWNpbWFscyIsIm1heERlY2ltYWxzIiwiY2FjaGVLZXkiLCJmb3JtYXR0ZXIiLCJnZXQiLCJJbnRsIiwiTnVtYmVyRm9ybWF0Iiwic3R5bGUiLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJzZXQiLCJmb3JtYXR0ZWQiLCJmb3JtYXQiLCJjdXJyZW5jeVN5bWJvbCIsImZvcm1hdHRlZE51bSIsInRvTG9jYWxlU3RyaW5nIiwiY3VycmVuY3lQb3NpdGlvbiIsImZvcm1hdEFtb3VudCIsIm1pbkRlYyIsImRlY2ltYWxzIiwibWF4RGVjIiwicmF3Iiwibm9TeW1ib2wiLCJ1c2VHcm91cGluZyIsIm5vQ29tbWFzIiwiZm9ybWF0RmluYW5jaWFsUmVwb3J0QW1vdW50IiwiaW5wdXQiLCJmaWVsZE9yT3B0aW9ucyIsInZhbCIsIm9wdHMiLCJzaG93U3ltYm9sIiwiZm10RmluYW5jaWFsUmVwb3J0IiwiZm9ybWF0RmluYW5jaWFsVmFsdWUiLCJpc01vbmV0YXJ5RmllbGQiLCJrZXkiLCJrIiwidG9Mb3dlckNhc2UiLCJpc01vbmV0YXJ5Q29sdW1uS2V5IiwiaXNQZXJjZW50YWdlRmllbGQiLCJpc1BlcmNlbnRhZ2VDb2x1bW5LZXkiLCJmb3JtYXROdW1iZXIiLCJuIiwiY29tcGFjdCIsImNvbXBhY3ROdW1iZXJzIiwiYWJzIiwidG9GaXhlZCIsInRvU3RyaW5nIiwiZm9yY2VEZWNpbWFscyIsImZvcm1hdFBlcmNlbnRhZ2UiLCJ2YWx1ZSIsInBhcnNlRmxvYXQiLCJmb3JtYXRQZXJjZW50IiwiZm9ybWF0UGhvbmUiLCJwaG9uZSIsImNvbXBhbnlQaG9uZSIsImNvdW50cnlDb2RlIiwic3RhcnRzV2l0aCIsImNsZWFuZWQiLCJyZXBsYWNlIiwibGVuZ3RoIiwic2xpY2UiLCJmb3JtYXRFbWFpbCIsImVtYWlsIiwidHJpbW1lZCIsImZvcm1hdER1cmF0aW9uIiwiaG91cnMiLCJoIiwibSIsInJvdW5kIiwiaERpc3BsYXkiLCJtRGlzcGxheSIsImZvcm1hdERpc3RhbmNlIiwibWV0ZXJzT3JLbSIsImlzS20iLCJtZXRlcnMiLCJmb3JtYXRGaWxlU2l6ZSIsImJ5dGVzIiwic2l6ZXMiLCJpIiwibG9nIiwicG93IiwidHJ1bmNhdGVJZCIsImlkIiwiY2hhcnMiLCJzdHIiLCJmb3JtYXRCb29raW5nSWQiLCJmb3JtYXRQYXltZW50SWQiLCJmb3JtYXRUcmFuc2FjdGlvbklkIiwiZm9ybWF0UmVmdW5kSWQiLCJmb3JtYXRTZXR0bGVtZW50SWQiLCJmb3JtYXRXaXRoZHJhd2FsSWQiLCJmb3JtYXRXYWxsZXRJZCIsImZvcm1hdFByb3ZpZGVySWQiLCJmb3JtYXRDdXN0b21lcklkIiwiZm9ybWF0SW52b2ljZUlkIiwiY2FwaXRhbGl6ZSIsImNoYXJBdCIsIlRJVExFX0NBU0VfQUNST05ZTVMiLCJTZXQiLCJ0aXRsZUNhc2UiLCJzcGxpdCIsImZpbHRlciIsIkJvb2xlYW4iLCJtYXAiLCJ3b3JkIiwidXBwZXIiLCJoYXMiLCJqb2luIiwic2FmZVZhbHVlIiwiZmFsbGJhY2siLCJpc0VtcHR5VmFsdWUiLCJBcnJheSIsImlzQXJyYXkiLCJPYmplY3QiLCJrZXlzIiwiY29weVRvQ2xpcGJvYXJkIiwidGV4dCIsIm5hdmlnYXRvciIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsInRleHRBcmVhIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiYm9keSIsImFwcGVuZENoaWxkIiwic2VsZWN0Iiwic3VjY2VzcyIsImV4ZWNDb21tYW5kIiwicmVtb3ZlQ2hpbGQiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJkb3dubG9hZEZpbGUiLCJ1cmwiLCJmaWxlTmFtZSIsImxpbmsiLCJocmVmIiwiZG93bmxvYWQiLCJjbGljayIsImdldE9wdGltaXplZENsb3VkaW5hcnlVcmwiLCJ3aWR0aCIsImNsZWFuVXJsIiwidXBsb2FkUmVnZXgiLCJ0cmFuc2Zvcm1TdHIiLCJ0cmFuc2Zvcm0iLCJjb21wcmVzc0ltYWdlIiwiZmlsZSIsIlByb21pc2UiLCJyZXNvbHZlIiwibWF4V2lkdGgiLCJtYXhIZWlnaHQiLCJxdWFsaXR5IiwidHlwZSIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWQiLCJldmVudCIsImltZyIsIkltYWdlIiwiaGVpZ2h0IiwiY2FudmFzIiwiY3R4IiwiZ2V0Q29udGV4dCIsImRyYXdJbWFnZSIsInRvQmxvYiIsImJsb2IiLCJjb21wcmVzc2VkRmlsZSIsIkZpbGUiLCJuYW1lIiwibGFzdE1vZGlmaWVkIiwic2l6ZSIsIm9uZXJyb3IiLCJzcmMiLCJ0YXJnZXQiLCJyZXN1bHQiLCJyZWFkQXNEYXRhVVJMIiwiYnVpbGRBZGRyZXNzUHJldmlldyIsImFkZHJlc3MiLCJjbGVhblBhcnQiLCJob3VzZU51bWJlciIsImhvdXNlX251bWJlciIsImhvdXNlIiwiZmxhdCIsImFwYXJ0bWVudCIsInVuaXQiLCJvZmZpY2UiLCJyb2FkIiwic3RyZWV0TmFtZSIsInN0cmVldCIsImZvb3R3YXkiLCJwYXRoIiwibGFuZG1hcmsiLCJhcmVhIiwibG9jYWxpdHkiLCJyZXNpZGVudGlhbCIsIm5laWdoYm91cmhvb2QiLCJzdWJ1cmIiLCJxdWFydGVyIiwiaGFtbGV0IiwidmlsbGFnZSIsImNpdHkiLCJ0b3duIiwibXVuaWNpcGFsaXR5IiwiY2l0eV9kaXN0cmljdCIsImNvdW50eSIsInN0YXRlX2Rpc3RyaWN0IiwicGluY29kZSIsInBvc3RhbENvZGUiLCJwb3N0Y29kZSIsInBvc3RhbF9jb2RlIiwicGFydHMiLCJwYXJ0IiwicGFydExvd2VyIiwiZHVwbGljYXRlSW5kZXgiLCJpc0R1cGxpY2F0ZSIsInNvbWUiLCJleGlzdGluZyIsImluZGV4IiwiZXhpc3RpbmdMb3dlciIsIm1hdGNoZWQiLCJwdXNoIiwiZm9ybWF0QWRkcmVzcyIsInByZXZpZXciLCJhZGRyZXNzTGluZSIsInN0YXRlIiwiY291bnRyeSIsInNtYXJ0QWRkcmVzc0J1aWxkZXIiLCJhZGRyZXNzT2JqIiwiZGlzcGxheU5hbWUiLCJhZGRyIiwicyIsImlzVW53YW50ZWQiLCJ0ZXN0IiwiaG91c2VObyIsImJ1aWxkaW5nIiwiYXBhcnRtZW50cyIsImFtZW5pdHkiLCJmYWxsYmFja0xpc3QiLCJnZXRGYWxsYmFjayIsImhvdXNlQnVpbGRpbmdQYXJ0IiwiZGlzcGxheVBhcnRzIiwicCIsImNpdHlMb3dlciIsInN0YXRlTG93ZXIiLCJkcCIsImRwTG93ZXIiLCJzdGF0ZVN0cmluZyIsImlkeCIsImZpbmRJbmRleCIsInVuaXF1ZVBhcnRzIiwiY2xlYW5BZGRyZXNzRmllbGRzIiwiZGV2ZWxvcG1lbnQiLCJ0b3dubGFuZCIsInBsYWNlIiwiY29tbWVyY2lhbCIsImluZHVzdHJpYWwiLCJmaW5hbEhvdXNlTnVtYmVyIiwiZmluYWxCdWlsZGluZyIsImZpbmFsUm9hZCIsImZpbmFsTG9jYWxpdHkiLCJmaW5hbExhbmRtYXJrIiwiZmluYWxBcmVhIiwiZmluYWxDaXR5IiwiZmluYWxTdGF0ZSIsImZpbmFsUGluY29kZSIsImNhbmRpZGF0ZXMiLCJwaW5jb2RlTG93ZXIiLCJhbHJlYWR5TWF0Y2hlZCIsImMiLCJjTG93ZXIiLCJ1bmlxdWVDYW5kaWRhdGVzIiwiY2FuZCIsImNhbmRMb3dlciIsImlzRHVwIiwic3RyZWV0QWRkcmVzcyIsImZvcm1hdHRlZEFkZHJlc3MiLCJmdWxsQWRkcmVzc1ByZXZpZXciLCJoYXNHcmFudWxhckRldGFpbHMiLCJpc0NpdHlDZW50ZXJPbmx5IiwibGF0IiwibG5nIiwiTElHSFRfTUFQX1RJTEVTIiwiTElHSFRfTUFQX0FUVFJJQlVUSU9OIiwiR0VPQ09ERV9DQUNIRSIsIkdFT0NPREVfQ0FDSEVfVFRMX01TIiwiR0VPQ09ERV9VU0VSX0FHRU5UIiwiY29vcmRDYWNoZUtleSIsIm1lcmdlUGhvdG9uTm9taW5hdGltIiwicGhvdG9uUHJvcHMiLCJub21pbmF0aW1BZGRyIiwiaG91c2VudW1iZXIiLCJkaXN0cmljdCIsIl9kaXNwbGF5TmFtZSIsInJldmVyc2VHZW9jb2RlIiwiY2FjaGVkIiwidHMiLCJkYXRhIiwibm9tUmVzIiwiZmV0Y2giLCJoZWFkZXJzIiwibm9tSnNvbiIsImpzb24iLCJkaXNwbGF5X25hbWUiLCJwaG90b25SZXMiLCJwaG90b25Kc29uIiwiZmVhdHVyZXMiLCJwcm9wZXJ0aWVzIiwicHJvcHMiLCJtZXJnZWQiLCJzdHJ1Y3R1cmVkIiwiZGV0ZWN0Q3VycmVudExvY2F0aW9uIiwidGFyZ2V0QWNjdXJhY3kiLCJtYXhVcGRhdGVzIiwidGltZW91dE1zIiwidGltZW91dCIsIm1heFJldHJpZXMiLCJyZXRyeUNvdW50IiwiZXhlY3V0ZURldGVjdGlvbiIsInJlamVjdCIsImdlb2xvY2F0aW9uIiwiRXJyb3IiLCJ3YXRjaElkIiwidXBkYXRlQ291bnQiLCJiZXN0UG9zIiwiY2xlYXJXYXRjaFNhZmUiLCJjbGVhcldhdGNoIiwidGltZW91dElkIiwic2V0VGltZW91dCIsImNvb3JkcyIsImFjY3VyYWN5IiwicmVzb2x2ZVBvc2l0aW9uIiwiZ2V0Q3VycmVudFBvc2l0aW9uIiwiZmFsbGJhY2tQb3MiLCJmYWxsYmFja0VyciIsImVuYWJsZUhpZ2hBY2N1cmFjeSIsInBvcyIsImNsZWFyVGltZW91dCIsImxhdGl0dWRlIiwibG9uZ2l0dWRlIiwiczJDZWxsSWQiLCJzMkNlbGxJZFByZWNpc2UiLCJ3YXRjaFBvc2l0aW9uIiwiY29kZSIsIm1heGltdW1BZ2UiLCJ0b0xlZ2FjeUFkZHJlc3NGaWVsZHMiLCJmaWx0ZXJHUFNKaXR0ZXIiLCJwcmV2IiwibmV4dCIsIm1pbk1ldGVycyIsIlIiLCJkTGF0IiwiUEkiLCJkTG5nIiwiYSIsInNpbiIsImNvcyIsImRpc3QiLCJhdGFuMiIsInNxcnQiLCJjYWxjdWxhdGVCZWFyaW5nIiwibGF0MSIsImxvbjEiLCJsYXQyIiwibG9uMiIsImRMb24iLCJsYXQxUmFkIiwibGF0MlJhZCIsInkiLCJ4IiwiYnVpbGRTdHJlZXRBZGRyZXNzIiwiaG91c2VOdW0iLCJyZCIsIkJBTktfTkFNRVMiLCJQVU5CIiwiSERGQyIsIlNCSU4iLCJJQ0lDIiwiVVRJQiIsIkFYSVMiLCJLS0JLIiwiQkFSQiIsIkNOUkIiLCJVQklOIiwiSURJQiIsIkJLSUQiLCJJT0JBIiwiTUFIQiIsIlBTSUIiLCJVQ09CIiwiQ1VCIiwiQ1NCIiwiRENCIiwiRExYQiIsIkZEUkwiLCJJREZCIiwiSU5EQiIsIklORFVTIiwiSkFLQSIsIktBUkIiLCJLVkJMIiwiS1ZCIiwiTkFJTiIsIlJCTCIsIlNJQkwiLCJUTUJMIiwiWUVTQiIsIkJEQkwiLCJBVUJMIiwiRVNGQiIsIlVTRkIiLCJBSVJQIiwiSVBQQiIsIlBZVE0iLCJmb3JtYXRCYW5rTmFtZSIsImNsZWFuQ29kZSIsImJhc2VDb2RlIiwiYmFua05hbWUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiZm9ybWF0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFN0YW5kYXJkIFNpbmdsZSBTb3VyY2Ugb2YgVHJ1dGggZm9yIERhdGEgJiBWYWx1ZSBGb3JtYXR0aW5nLlxuICogQWxsIGRhdGEgZm9ybWF0dGluZyAoRGF0ZXMsIFRpbWVzLCBDdXJyZW5jaWVzLCBOdW1iZXJzLCBQaG9uZSwgQWRkcmVzcywgSURzLCBGaWxlcylcbiAqIG11c3QgYmUgZG9uZSB0aHJvdWdoIHRoZXNlIGZ1bmN0aW9ucyB0byBndWFyYW50ZWUgYXBwbGljYXRpb24td2lkZSBjb25zaXN0ZW5jeS5cbiAqL1xuaW1wb3J0IHsgZ2V0Q2FjaGVkVGltZUZvcm1hdCwgcmVhZENhY2hlZFN5c3RlbVNldHRpbmdzIH0gZnJvbSAnLi9zeXN0ZW1TZXR0aW5nc0NhY2hlJztcbmltcG9ydCB7IGxhdExuZ1RvUzJDZWxsSWQgfSBmcm9tICcuL3MySGVscGVyJztcblxuY29uc3QgRkFMTEJBQ0sgPSBcIi0tXCI7XG5cbi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgQ0xPQ0sgJiBUSU1FIFBBUlNJTkcgSEVMUEVSU1xuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXG5cbmNvbnN0IHBhcnNlQ2xvY2tUaW1lID0gKHRpbWUpID0+IHtcbiAgaWYgKCF0aW1lIHx8IHR5cGVvZiB0aW1lICE9PSBcInN0cmluZ1wiKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgbWF0Y2ggPSB0aW1lLnRyaW0oKS5tYXRjaCgvXihcXGR7MSwyfSk6KFxcZHsxLDJ9KSg/OjpcXGR7MSwyfSk/XFxzKihBTXxQTSk/JC9pKTtcbiAgaWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cbiAgbGV0IGhvdXIgPSBOdW1iZXIobWF0Y2hbMV0pO1xuICBjb25zdCBtaW51dGUgPSBOdW1iZXIobWF0Y2hbMl0pO1xuICBjb25zdCBtZXJpZGllbSA9IG1hdGNoWzNdPy50b1VwcGVyQ2FzZSgpO1xuXG4gIGlmIChOdW1iZXIuaXNOYU4oaG91cikgfHwgTnVtYmVyLmlzTmFOKG1pbnV0ZSkgfHwgbWludXRlID4gNTkpIHJldHVybiBudWxsO1xuXG4gIGlmIChtZXJpZGllbSkge1xuICAgIGlmIChob3VyIDwgMSB8fCBob3VyID4gMTIpIHJldHVybiBudWxsO1xuICAgIGlmIChtZXJpZGllbSA9PT0gXCJQTVwiICYmIGhvdXIgIT09IDEyKSBob3VyICs9IDEyO1xuICAgIGlmIChtZXJpZGllbSA9PT0gXCJBTVwiICYmIGhvdXIgPT09IDEyKSBob3VyID0gMDtcbiAgfSBlbHNlIGlmIChob3VyID4gMjMpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiB7IGhvdXIsIG1pbnV0ZSB9O1xufTtcblxuY29uc3QgZm9ybWF0Q2xvY2tUaW1lID0gKHsgaG91ciwgbWludXRlIH0sIHRpbWVGb3JtYXQgPSBnZXRDYWNoZWRUaW1lRm9ybWF0KCkpID0+IHtcbiAgY29uc3QgZm9ybWF0dGVkTWludXRlID0gU3RyaW5nKG1pbnV0ZSkucGFkU3RhcnQoMiwgXCIwXCIpO1xuXG4gIGlmICh0aW1lRm9ybWF0ID09PSBcIjI0aFwiKSB7XG4gICAgcmV0dXJuIGAke1N0cmluZyhob3VyKS5wYWRTdGFydCgyLCBcIjBcIil9OiR7Zm9ybWF0dGVkTWludXRlfWA7XG4gIH1cblxuICBjb25zdCBhbXBtID0gaG91ciA+PSAxMiA/IFwiUE1cIiA6IFwiQU1cIjtcbiAgY29uc3QgZm9ybWF0dGVkSG91ciA9IGhvdXIgJSAxMiB8fCAxMjtcbiAgcmV0dXJuIGAke2Zvcm1hdHRlZEhvdXJ9OiR7Zm9ybWF0dGVkTWludXRlfSAke2FtcG19YDtcbn07XG5cbmV4cG9ydCB7IHBhcnNlQ2xvY2tUaW1lLCBmb3JtYXRDbG9ja1RpbWUgfTtcblxuLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICBEQVRFICYgVElNRSBGT1JNQVRURVJTIChTWVNURU0gU0VUVElOR1MgUkVBQ1RJVkUpXG4gICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cblxuLyoqXG4gKiBGb3JtYXQgZGF0ZSB0byBhIHJlYWRhYmxlIHN0cmluZyBiYXNlZCBvbiBTeXN0ZW0gU2V0dGluZ3MgKGUuZy4sIDE1IE1heSAyMDI0IG9yIEREL01NL1lZWVkpXG4gKiBAcGFyYW0ge0RhdGV8c3RyaW5nfG51bWJlcn0gZGF0ZSAtIFRoZSBkYXRlIHRvIGZvcm1hdFxuICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSAtIE9wdGlvbmFsIG92ZXJyaWRlc1xuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIGRhdGUgc3RyaW5nXG4gKi9cbmV4cG9ydCBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICBpZiAoIWRhdGUpIHJldHVybiBGQUxMQkFDSztcbiAgdHJ5IHtcbiAgICBjb25zdCBkID0gbmV3IERhdGUoZGF0ZSk7XG4gICAgaWYgKGlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIEZBTExCQUNLO1xuXG4gICAgY29uc3Qgc2V0dGluZ3MgPSByZWFkQ2FjaGVkU3lzdGVtU2V0dGluZ3MoKTtcbiAgICBjb25zdCB0aW1lem9uZSA9IG9wdGlvbnMudGltZXpvbmUgfHwgc2V0dGluZ3MudGltZXpvbmUgfHwgXCJBc2lhL0tvbGthdGFcIjtcbiAgICBjb25zdCBsb2NhbGUgPSBvcHRpb25zLmxvY2FsZSB8fCBzZXR0aW5ncy5sb2NhbGUgfHwgXCJlbi1JTlwiO1xuXG4gICAgLy8gU3RhbmRhcmQgbG9jYWxpemVkIGRhdGUgc3RyaW5nXG4gICAgcmV0dXJuIGQudG9Mb2NhbGVEYXRlU3RyaW5nKGxvY2FsZSwge1xuICAgICAgZGF5OiBcIm51bWVyaWNcIixcbiAgICAgIG1vbnRoOiBcInNob3J0XCIsXG4gICAgICB5ZWFyOiBcIm51bWVyaWNcIixcbiAgICAgIHRpbWVab25lOiB0aW1lem9uZSxcbiAgICAgIC4uLm9wdGlvbnNcbiAgICB9KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIEZBTExCQUNLO1xuICB9XG59O1xuXG5leHBvcnQgY29uc3QgZm10RGF0ZSA9IGZvcm1hdERhdGU7XG5leHBvcnQgY29uc3QgZm10RGF0ZU9ubHkgPSBmb3JtYXREYXRlO1xuXG4vKipcbiAqIEZvcm1hdCB0aW1lIHVzaW5nIGNvbmZpZ3VyZWQgU3lzdGVtIFNldHRpbmdzIChlLmcuLCAxMDozMCBBTSBvciAyMjozMClcbiAqIEBwYXJhbSB7RGF0ZXxzdHJpbmd9IHRpbWUgLSBUaGUgdGltZSB0byBmb3JtYXRcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEZvcm1hdHRlZCB0aW1lIHN0cmluZ1xuICovXG5leHBvcnQgY29uc3QgZm9ybWF0VGltZSA9ICh0aW1lKSA9PiB7XG4gIGlmICghdGltZSkgcmV0dXJuIEZBTExCQUNLO1xuICB0cnkge1xuICAgIGNvbnN0IHRpbWVGb3JtYXQgPSBnZXRDYWNoZWRUaW1lRm9ybWF0KCk7XG5cbiAgICBpZiAodGltZSBpbnN0YW5jZW9mIERhdGUgfHwgKHR5cGVvZiB0aW1lID09PSBcInN0cmluZ1wiICYmIHRpbWUuaW5jbHVkZXMoXCJUXCIpKSkge1xuICAgICAgY29uc3QgZCA9IG5ldyBEYXRlKHRpbWUpO1xuICAgICAgaWYgKGlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIEZBTExCQUNLO1xuICAgICAgY29uc3Qgc2V0dGluZ3MgPSByZWFkQ2FjaGVkU3lzdGVtU2V0dGluZ3MoKTtcbiAgICAgIGNvbnN0IHRpbWV6b25lID0gc2V0dGluZ3MudGltZXpvbmUgfHwgXCJBc2lhL0tvbGthdGFcIjtcbiAgICAgIGNvbnN0IGxvY2FsZSA9IHNldHRpbmdzLmxvY2FsZSB8fCBcImVuLUlOXCI7XG5cbiAgICAgIHJldHVybiBkLnRvTG9jYWxlVGltZVN0cmluZyhsb2NhbGUsIHtcbiAgICAgICAgaG91cjogdGltZUZvcm1hdCA9PT0gXCIyNGhcIiA/IFwiMi1kaWdpdFwiIDogXCJudW1lcmljXCIsXG4gICAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXG4gICAgICAgIGhvdXIxMjogdGltZUZvcm1hdCA9PT0gXCIxMmhcIixcbiAgICAgICAgdGltZVpvbmU6IHRpbWV6b25lXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIHRpbWUgPT09IFwic3RyaW5nXCIgJiYgdGltZS5pbmNsdWRlcyhcIjpcIikpIHtcbiAgICAgIGNvbnN0IHBhcnNlZFRpbWUgPSBwYXJzZUNsb2NrVGltZSh0aW1lKTtcbiAgICAgIGlmICghcGFyc2VkVGltZSkgcmV0dXJuIEZBTExCQUNLO1xuICAgICAgcmV0dXJuIGZvcm1hdENsb2NrVGltZShwYXJzZWRUaW1lLCB0aW1lRm9ybWF0KTtcbiAgICB9XG5cbiAgICByZXR1cm4gRkFMTEJBQ0s7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBGQUxMQkFDSztcbiAgfVxufTtcblxuLyoqXG4gKiBGb3JtYXQgZGF0ZSBhbmQgdGltZSB0b2dldGhlciAoZS5nLiwgMTUgTWF5IDIwMjQsIDEwOjMwIEFNKVxuICogQHBhcmFtIHtEYXRlfHN0cmluZ30gZGF0ZSAtIFRoZSBkYXRldGltZSB0byBmb3JtYXRcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEZvcm1hdHRlZCBkYXRldGltZSBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGZvcm1hdERhdGVUaW1lID0gKGRhdGUpID0+IHtcbiAgaWYgKCFkYXRlKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGNvbnN0IGQgPSBmb3JtYXREYXRlKGRhdGUpO1xuICBjb25zdCB0ID0gZm9ybWF0VGltZShkYXRlKTtcbiAgaWYgKGQgPT09IEZBTExCQUNLIHx8IHQgPT09IEZBTExCQUNLKSByZXR1cm4gRkFMTEJBQ0s7XG4gIHJldHVybiBgJHtkfSwgJHt0fWA7XG59O1xuXG5leHBvcnQgY29uc3QgZm10RGF0ZVRpbWUgPSBmb3JtYXREYXRlVGltZTtcblxuLyoqXG4gKiBGb3JtYXQgcmVsYXRpdmUgdGltZSAoZS5nLiBKdXN0IG5vdywgNSBzZWMgYWdvLCAxMCBtaW4gYWdvLCAyIGhyIGFnbywgMyBkIGFnbylcbiAqIEBwYXJhbSB7RGF0ZXxzdHJpbmd8bnVtYmVyfSB0aW1lc3RhbXAgLSBUaGUgdGltZXN0YW1wIHRvIGZvcm1hdFxuICogQHJldHVybnMge3N0cmluZ30gUmVsYXRpdmUgdGltZSBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGZvcm1hdFJlbGF0aXZlVGltZSA9ICh0aW1lc3RhbXApID0+IHtcbiAgaWYgKCF0aW1lc3RhbXApIHJldHVybiBcIk5ldmVyXCI7XG4gIHRyeSB7XG4gICAgY29uc3QgZGlmZk1zID0gRGF0ZS5ub3coKSAtIG5ldyBEYXRlKHRpbWVzdGFtcCkuZ2V0VGltZSgpO1xuICAgIGlmIChpc05hTihkaWZmTXMpKSByZXR1cm4gRkFMTEJBQ0s7XG5cbiAgICBjb25zdCBkaWZmU2VjID0gTWF0aC5mbG9vcihkaWZmTXMgLyAxMDAwKTtcbiAgICBpZiAoZGlmZlNlYyA8IDUpIHJldHVybiBcIkp1c3Qgbm93XCI7XG4gICAgaWYgKGRpZmZTZWMgPCA2MCkgcmV0dXJuIGAke2RpZmZTZWN9IHNlYyBhZ29gO1xuXG4gICAgY29uc3QgZGlmZk1pbiA9IE1hdGguZmxvb3IoZGlmZlNlYyAvIDYwKTtcbiAgICBpZiAoZGlmZk1pbiA8IDYwKSByZXR1cm4gYCR7ZGlmZk1pbn0gbWluIGFnb2A7XG5cbiAgICBjb25zdCBkaWZmSHIgPSBNYXRoLmZsb29yKGRpZmZNaW4gLyA2MCk7XG4gICAgaWYgKGRpZmZIciA8IDI0KSByZXR1cm4gYCR7ZGlmZkhyfSBociBhZ29gO1xuXG4gICAgY29uc3QgZGlmZkRheSA9IE1hdGguZmxvb3IoZGlmZkhyIC8gMjQpO1xuICAgIGlmIChkaWZmRGF5IDwgNykgcmV0dXJuIGAke2RpZmZEYXl9IGQgYWdvYDtcblxuICAgIHJldHVybiBmb3JtYXREYXRlKHRpbWVzdGFtcCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBGQUxMQkFDSztcbiAgfVxufTtcblxuZXhwb3J0IGNvbnN0IGZtdFJlbGF0aXZlVGltZSA9IGZvcm1hdFJlbGF0aXZlVGltZTtcblxuLyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICBDVVJSRU5DWSwgQU1PVU5UICYgTlVNQkVSIEZPUk1BVFRFUlMgKFNZU1RFTSBTRVRUSU5HUylcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xuXG5jb25zdCBjdXJyZW5jeUZvcm1hdHRlcnMgPSBuZXcgTWFwKCk7XG5jb25zdCBudW1iZXJGb3JtYXR0ZXJzID0gbmV3IE1hcCgpO1xuXG4vKipcbiAqIEZvcm1hdCBjdXJyZW5jeSBkeW5hbWljYWxseSB1c2luZyBTeXN0ZW0gU2V0dGluZ3MgY29uZmlndXJhdGlvblxuICogQHBhcmFtIHtudW1iZXJ8c3RyaW5nfSBhbW91bnQgLSBUaGUgYW1vdW50IHRvIGZvcm1hdFxuICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSAtIEN1c3RvbSBmb3JtYXR0aW5nIG92ZXJyaWRlc1xuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIGN1cnJlbmN5IHN0cmluZ1xuICovXG5leHBvcnQgY29uc3QgZm9ybWF0Q3VycmVuY3kgPSAoYW1vdW50LCBvcHRpb25zID0ge30pID0+IHtcbiAgaWYgKGFtb3VudCA9PT0gbnVsbCB8fCBhbW91bnQgPT09IHVuZGVmaW5lZCB8fCBhbW91bnQgPT09IFwiXCIgfHwgaXNOYU4oYW1vdW50KSkgcmV0dXJuIEZBTExCQUNLO1xuICB0cnkge1xuICAgIGNvbnN0IHNldHRpbmdzID0gcmVhZENhY2hlZFN5c3RlbVNldHRpbmdzKCk7XG4gICAgY29uc3QgY3VycmVuY3kgPSBvcHRpb25zLmN1cnJlbmN5IHx8IHNldHRpbmdzLmRlZmF1bHRDdXJyZW5jeSB8fCBcIklOUlwiO1xuICAgIGNvbnN0IGxvY2FsZSA9IG9wdGlvbnMubG9jYWxlIHx8IHNldHRpbmdzLmxvY2FsZSB8fCAoY3VycmVuY3kgPT09IFwiSU5SXCIgPyBcImVuLUlOXCIgOiBcImVuLVVTXCIpO1xuICAgIGNvbnN0IG51bSA9IE51bWJlcihhbW91bnQpO1xuICAgIGlmIChpc05hTihudW0pKSByZXR1cm4gRkFMTEJBQ0s7XG5cbiAgICBjb25zdCBtaW5EZWNpbWFscyA9IG9wdGlvbnMubWluRGVjaW1hbHMgPz8gb3B0aW9ucy5kZWNpbWFsUHJlY2lzaW9uID8/IChvcHRpb25zLmFsd2F5c1Nob3dEZWNpbWFscyA9PT0gZmFsc2UgPyAwIDogMik7XG4gICAgY29uc3QgbWF4RGVjaW1hbHMgPSBvcHRpb25zLm1heERlY2ltYWxzID8/IG9wdGlvbnMuZGVjaW1hbFByZWNpc2lvbiA/PyAyO1xuXG4gICAgY29uc3QgY2FjaGVLZXkgPSBgJHtsb2NhbGV9LSR7Y3VycmVuY3l9LSR7bWluRGVjaW1hbHN9LSR7bWF4RGVjaW1hbHN9YDtcbiAgICBsZXQgZm9ybWF0dGVyID0gY3VycmVuY3lGb3JtYXR0ZXJzLmdldChjYWNoZUtleSk7XG5cbiAgICBpZiAoIWZvcm1hdHRlcikge1xuICAgICAgZm9ybWF0dGVyID0gbmV3IEludGwuTnVtYmVyRm9ybWF0KGxvY2FsZSwge1xuICAgICAgICBzdHlsZTogXCJjdXJyZW5jeVwiLFxuICAgICAgICBjdXJyZW5jeTogY3VycmVuY3ksXG4gICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogbWluRGVjaW1hbHMsXG4gICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogbWF4RGVjaW1hbHMsXG4gICAgICB9KTtcbiAgICAgIGN1cnJlbmN5Rm9ybWF0dGVycy5zZXQoY2FjaGVLZXksIGZvcm1hdHRlcik7XG4gICAgfVxuICAgIGxldCBmb3JtYXR0ZWQgPSBmb3JtYXR0ZXIuZm9ybWF0KG51bSk7XG5cbiAgICBpZiAoc2V0dGluZ3MuY3VycmVuY3lTeW1ib2wgJiYgIWZvcm1hdHRlZC5pbmNsdWRlcyhzZXR0aW5ncy5jdXJyZW5jeVN5bWJvbCkpIHtcbiAgICAgIGNvbnN0IGZvcm1hdHRlZE51bSA9IG51bS50b0xvY2FsZVN0cmluZyhsb2NhbGUsIHtcbiAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiBtaW5EZWNpbWFscyxcbiAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiBtYXhEZWNpbWFscyxcbiAgICAgIH0pO1xuICAgICAgaWYgKHNldHRpbmdzLmN1cnJlbmN5UG9zaXRpb24gPT09IFwic3VmZml4XCIpIHtcbiAgICAgICAgZm9ybWF0dGVkID0gYCR7Zm9ybWF0dGVkTnVtfSAke3NldHRpbmdzLmN1cnJlbmN5U3ltYm9sfWA7XG4gICAgICB9IGVsc2UgaWYgKHNldHRpbmdzLmN1cnJlbmN5UG9zaXRpb24gPT09IFwicHJlZml4XCIpIHtcbiAgICAgICAgZm9ybWF0dGVkID0gYCR7c2V0dGluZ3MuY3VycmVuY3lTeW1ib2x9JHtmb3JtYXR0ZWROdW19YDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZm9ybWF0dGVkO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gRkFMTEJBQ0s7XG4gIH1cbn07XG5cbi8qKlxuICogRm9ybWF0IHJhdyBhbW91bnQgd2l0aCBvcHRpb25hbCBjdXJyZW5jeSBzeW1ib2wgb3IgZGVjaW1hbHNcbiAqIEBwYXJhbSB7bnVtYmVyfHN0cmluZ30gYW1vdW50IC0gQW1vdW50IHZhbHVlXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdIC0gT3ZlcnJpZGUgb3B0aW9uc1xuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIGFtb3VudCBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGZvcm1hdEFtb3VudCA9IChhbW91bnQsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICBpZiAoYW1vdW50ID09PSBudWxsIHx8IGFtb3VudCA9PT0gdW5kZWZpbmVkIHx8IGFtb3VudCA9PT0gXCJcIiB8fCBpc05hTihhbW91bnQpKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGNvbnN0IG51bSA9IE51bWJlcihhbW91bnQpO1xuICBpZiAoaXNOYU4obnVtKSkgcmV0dXJuIEZBTExCQUNLO1xuXG4gIGNvbnN0IG1pbkRlYyA9IG9wdGlvbnMubWluRGVjaW1hbHMgPz8gb3B0aW9ucy5kZWNpbWFsUHJlY2lzaW9uID8/IG9wdGlvbnMuZGVjaW1hbHMgPz8gMjtcbiAgY29uc3QgbWF4RGVjID0gb3B0aW9ucy5tYXhEZWNpbWFscyA/PyBvcHRpb25zLmRlY2ltYWxQcmVjaXNpb24gPz8gb3B0aW9ucy5kZWNpbWFscyA/PyAyO1xuICBjb25zdCBsb2NhbGUgPSBvcHRpb25zLmxvY2FsZSB8fCBcImVuLUlOXCI7XG5cbiAgaWYgKG9wdGlvbnMucmF3IHx8IG9wdGlvbnMubm9TeW1ib2wpIHtcbiAgICBjb25zdCB1c2VHcm91cGluZyA9IG9wdGlvbnMudXNlR3JvdXBpbmcgPz8gKCFvcHRpb25zLm5vQ29tbWFzKTtcbiAgICByZXR1cm4gbnVtLnRvTG9jYWxlU3RyaW5nKGxvY2FsZSwge1xuICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiBtaW5EZWMsXG4gICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IG1heERlYyxcbiAgICAgIHVzZUdyb3VwaW5nLFxuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIGZvcm1hdEN1cnJlbmN5KGFtb3VudCwge1xuICAgIG1pbkRlY2ltYWxzOiBtaW5EZWMsXG4gICAgbWF4RGVjaW1hbHM6IG1heERlYyxcbiAgICAuLi5vcHRpb25zXG4gIH0pO1xufTtcblxuLyoqXG4gKiBVbml2ZXJzYWwgRmluYW5jaWFsIFJlcG9ydCBBbW91bnQgRm9ybWF0dGVyLlxuICogRm9ybWF0cyBhbnkgZmluYW5jaWFsIHJlcG9ydCBmaWVsZCAoZ3Jvc3NBbW91bnQsIHRvdGFsQW1vdW50LCBzdWJ0b3RhbCwgZGlzY291bnQsIHN1cmNoYXJnZSxcbiAqIGNvbW1pc3Npb25BbW91bnQsIGNvbW1pc3Npb24sIG5ldEFtb3VudCwgcHJvdmlkZXJFYXJuaW5ncywgcGxhdGZvcm1GZWUsIHZpc2l0aW5nQ2hhcmdlLFxuICogcmFpbkNoYXJnZSwgdHJhZmZpY0NoYXJnZSwgbmlnaHRDaGFyZ2UsIGRlbWFuZFN1cmdlLCBwcm92aWRlclN1cmdlU2hhcmUsIGNvbXBhbnlTdXJnZVNoYXJlLFxuICogcmVmdW5kQW1vdW50LCB3YWxsZXRSZWZ1bmQsIGdhdGV3YXlSZWZ1bmQsIHBheW91dEFtb3VudCwgd2l0aGRyYXduQW1vdW50LCBvdXRzdGFuZGluZ0JhbGFuY2UsXG4gKiBjb2xsZWN0ZWRBbW91bnQsIGF0dGVtcHRlZEFtb3VudCwgY2FzaENvbGxlY3RlZCwgY291cG9uU3Vic2lkeSwgcmVmZXJyYWxSZXdhcmQsIHRheCwgZXRjLilcbiAqIGNvbnNpc3RlbnRseSBkaXNwbGF5aW5nIGV4YWN0bHkgMiBkZWNpbWFsIHBsYWNlcy5cbiAqXG4gKiBSZXNwZWN0cyBwcm9qZWN0IGNvbnZlbnRpb25zOlxuICogLSBJZiBzaG93U3ltYm9sOiB0cnVlIChkZWZhdWx0IGZvciBjdXJyZW5jeSBkaXNwbGF5cyksIGZvcm1hdHMgd2l0aCBjdXJyZW5jeSBzeW1ib2wgKGUuZy4g4oK5NzEuMDApLlxuICogLSBJZiBzaG93U3ltYm9sOiBmYWxzZSBvciByYXc6IHRydWUgb3Igbm9TeW1ib2w6IHRydWUgKHVzZWQgd2hlbiB0YWJsZSBoZWFkZXJzIGluY2x1ZGUgY3VycmVuY3kgc3ltYm9sKSxcbiAqICAgZm9ybWF0cyBhcyByYXcgMi1kZWNpbWFsIHN0cmluZyAoZS5nLiA3MS4wMCBvciAxLDAwMC4wMCkuXG4gKlxuICogQHBhcmFtIHtudW1iZXJ8c3RyaW5nfE9iamVjdH0gaW5wdXQgLSBGaW5hbmNpYWwgdmFsdWUgb3Igb2JqZWN0IGNvbnRhaW5pbmcgZmluYW5jaWFsIGZpZWxkXG4gKiBAcGFyYW0ge3N0cmluZ3xPYmplY3R9IFtmaWVsZE9yT3B0aW9uc10gLSBGaWVsZCBuYW1lIGlmIGlucHV0IGlzIG9iamVjdCwgb3Igb3B0aW9ucyBvYmplY3RcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gLSBBZGRpdGlvbmFsIGZvcm1hdHRpbmcgb3B0aW9uc1xuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIDItZGVjaW1hbCBmaW5hbmNpYWwgcmVwb3J0IGRpc3BsYXkgc3RyaW5nXG4gKi9cbmV4cG9ydCBjb25zdCBmb3JtYXRGaW5hbmNpYWxSZXBvcnRBbW91bnQgPSAoaW5wdXQsIGZpZWxkT3JPcHRpb25zID0ge30sIG9wdGlvbnMgPSB7fSkgPT4ge1xuICBsZXQgdmFsID0gaW5wdXQ7XG4gIGxldCBvcHRzID0ge307XG5cbiAgaWYgKGlucHV0ICYmIHR5cGVvZiBpbnB1dCA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIGZpZWxkT3JPcHRpb25zID09PSAnc3RyaW5nJykge1xuICAgIHZhbCA9IGlucHV0W2ZpZWxkT3JPcHRpb25zXTtcbiAgICBvcHRzID0gb3B0aW9ucyB8fCB7fTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgZmllbGRPck9wdGlvbnMgPT09ICdvYmplY3QnKSB7XG4gICAgb3B0cyA9IGZpZWxkT3JPcHRpb25zIHx8IHt9O1xuICB9XG5cbiAgaWYgKHZhbCA9PT0gbnVsbCB8fCB2YWwgPT09IHVuZGVmaW5lZCB8fCB2YWwgPT09IFwiXCIgfHwgaXNOYU4odmFsKSkgcmV0dXJuIEZBTExCQUNLO1xuXG4gIGNvbnN0IHNob3dTeW1ib2wgPSBvcHRzLnNob3dTeW1ib2wgPz8gKCFvcHRzLnJhdyAmJiAhb3B0cy5ub1N5bWJvbCk7XG5cbiAgaWYgKCFzaG93U3ltYm9sKSB7XG4gICAgcmV0dXJuIGZvcm1hdEFtb3VudCh2YWwsIHsgcmF3OiB0cnVlLCBkZWNpbWFsczogMiwgLi4ub3B0cyB9KTtcbiAgfVxuXG4gIHJldHVybiBmb3JtYXRDdXJyZW5jeSh2YWwsIHsgYWx3YXlzU2hvd0RlY2ltYWxzOiB0cnVlLCBtaW5EZWNpbWFsczogMiwgbWF4RGVjaW1hbHM6IDIsIC4uLm9wdHMgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgZm10RmluYW5jaWFsUmVwb3J0ID0gZm9ybWF0RmluYW5jaWFsUmVwb3J0QW1vdW50O1xuZXhwb3J0IGNvbnN0IGZvcm1hdEZpbmFuY2lhbFZhbHVlID0gZm9ybWF0RmluYW5jaWFsUmVwb3J0QW1vdW50O1xuXG4vKipcbiAqIFV0aWxpdHkgdG8gaWRlbnRpZnkgbW9uZXRhcnkgY29sdW1uIGZpZWxkIG5hbWVzXG4gKi9cbmV4cG9ydCBjb25zdCBpc01vbmV0YXJ5RmllbGQgPSAoa2V5KSA9PiB7XG4gIGlmICgha2V5IHx8IHR5cGVvZiBrZXkgIT09ICdzdHJpbmcnKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGsgPSBrZXkudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIChcbiAgICBrLmluY2x1ZGVzKCdhbW91bnQnKSB8fFxuICAgIGsuaW5jbHVkZXMoJ3RvdGFsJykgfHxcbiAgICBrLmluY2x1ZGVzKCdwYWlkJykgfHxcbiAgICBrLmluY2x1ZGVzKCdlYXJuaW5nJykgfHxcbiAgICBrLmluY2x1ZGVzKCdjb21taXNzaW9uJykgfHxcbiAgICBrLmluY2x1ZGVzKCdkaXNjb3VudCcpIHx8XG4gICAgay5pbmNsdWRlcygnc3VyY2hhcmdlJykgfHxcbiAgICBrLmluY2x1ZGVzKCdmZWUnKSB8fFxuICAgIGsuaW5jbHVkZXMoJ2ltcGFjdCcpIHx8XG4gICAgay5pbmNsdWRlcygndmFsdWUnKSB8fFxuICAgIGsuaW5jbHVkZXMoJ3N1YnRvdGFsJykgfHxcbiAgICBrLmluY2x1ZGVzKCdyZWZ1bmQnKSB8fFxuICAgIGsuaW5jbHVkZXMoJ3BheW91dCcpIHx8XG4gICAgay5pbmNsdWRlcygnc3Vic2lkeScpIHx8XG4gICAgay5pbmNsdWRlcygncmV3YXJkJykgfHxcbiAgICBrLmluY2x1ZGVzKCdiYWxhbmNlJykgfHxcbiAgICBrLmluY2x1ZGVzKCdjb2xsZWN0ZWQnKSB8fFxuICAgIGsuaW5jbHVkZXMoJ3RheCcpIHx8XG4gICAgay5pbmNsdWRlcygnZ3N0JykgfHxcbiAgICBrLmluY2x1ZGVzKCdyZWNlaXZhYmxlJykgfHxcbiAgICBrLmluY2x1ZGVzKCdncm9zcycpIHx8XG4gICAgay5pbmNsdWRlcygnbmV0JylcbiAgKSAmJiAhay5pbmNsdWRlcygncmF0ZScpICYmICFrLmluY2x1ZGVzKCdwZXJjZW50JykgJiYgIWsuaW5jbHVkZXMoJ3BlcmNlbnRhZ2UnKSAmJiAhay5pbmNsdWRlcygnaWQnKSAmJiAhay5pbmNsdWRlcygnY291bnQnKSAmJiAhay5pbmNsdWRlcygnZGF0ZScpICYmICFrLmluY2x1ZGVzKCdzdGF0dXMnKSAmJiAhay5pbmNsdWRlcygndHlwZScpICYmICFrLmluY2x1ZGVzKCdjb2RlJyk7XG59O1xuXG5leHBvcnQgY29uc3QgaXNNb25ldGFyeUNvbHVtbktleSA9IGlzTW9uZXRhcnlGaWVsZDtcblxuLyoqXG4gKiBVdGlsaXR5IHRvIGlkZW50aWZ5IHBlcmNlbnRhZ2UgY29sdW1uIGZpZWxkIG5hbWVzXG4gKi9cbmV4cG9ydCBjb25zdCBpc1BlcmNlbnRhZ2VGaWVsZCA9IChrZXkpID0+IHtcbiAgaWYgKCFrZXkgfHwgdHlwZW9mIGtleSAhPT0gJ3N0cmluZycpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgayA9IGtleS50b0xvd2VyQ2FzZSgpO1xuICByZXR1cm4gay5pbmNsdWRlcygncmF0ZScpIHx8IGsuaW5jbHVkZXMoJ3BlcmNlbnQnKSB8fCBrLmluY2x1ZGVzKCdwZXJjZW50YWdlJyk7XG59O1xuXG5leHBvcnQgY29uc3QgaXNQZXJjZW50YWdlQ29sdW1uS2V5ID0gaXNQZXJjZW50YWdlRmllbGQ7XG5cbi8qKlxuICogRm9ybWF0IG51bWJlcnMgd2l0aCBjb21tYSBzZXBhcmF0b3JzIG9yIGNvbXBhY3Qgbm90YXRpb24gKDEuMkssIDIuNUwsIDMuMkNyIC8gMTAwSylcbiAqIEBwYXJhbSB7bnVtYmVyfHN0cmluZ30gbnVtIC0gVGhlIG51bWJlciB0byBmb3JtYXRcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gLSB7IGNvbXBhY3Q6IGJvb2xlYW4sIGRlY2ltYWxzOiBudW1iZXIgfVxuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIG51bWJlciBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGZvcm1hdE51bWJlciA9IChudW0sIG9wdGlvbnMgPSB7fSkgPT4ge1xuICBpZiAobnVtID09PSBudWxsIHx8IG51bSA9PT0gdW5kZWZpbmVkIHx8IG51bSA9PT0gXCJcIiB8fCBpc05hTihudW0pKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGNvbnN0IG4gPSBOdW1iZXIobnVtKTtcbiAgaWYgKGlzTmFOKG4pKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGNvbnN0IHNldHRpbmdzID0gcmVhZENhY2hlZFN5c3RlbVNldHRpbmdzKCk7XG4gIGNvbnN0IGN1cnJlbmN5ID0gc2V0dGluZ3MuZGVmYXVsdEN1cnJlbmN5IHx8IFwiSU5SXCI7XG4gIGNvbnN0IGxvY2FsZSA9IG9wdGlvbnMubG9jYWxlIHx8IHNldHRpbmdzLmxvY2FsZSB8fCAoY3VycmVuY3kgPT09IFwiSU5SXCIgPyBcImVuLUlOXCIgOiBcImVuLVVTXCIpO1xuXG4gIGlmIChvcHRpb25zLmNvbXBhY3QgfHwgc2V0dGluZ3MuY29tcGFjdE51bWJlcnMpIHtcbiAgICBpZiAobG9jYWxlID09PSBcImVuLUlOXCIpIHtcbiAgICAgIGNvbnN0IGFicyA9IE1hdGguYWJzKG4pO1xuICAgICAgaWYgKGFicyA+PSAxMDAwMDAwMCkgcmV0dXJuIGAkeyhuIC8gMTAwMDAwMDApLnRvRml4ZWQob3B0aW9ucy5kZWNpbWFscyA/PyAxKX1DcmA7XG4gICAgICBpZiAoYWJzID49IDEwMDAwMCkgcmV0dXJuIGAkeyhuIC8gMTAwMDAwKS50b0ZpeGVkKG9wdGlvbnMuZGVjaW1hbHMgPz8gMSl9TGA7XG4gICAgICBpZiAoYWJzID49IDEwMDApIHJldHVybiBgJHsobiAvIDEwMDApLnRvRml4ZWQob3B0aW9ucy5kZWNpbWFscyA/PyAxKX1LYDtcbiAgICAgIHJldHVybiBuLnRvU3RyaW5nKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGFicyA9IE1hdGguYWJzKG4pO1xuICAgICAgaWYgKGFicyA+PSAxMDAwMDAwMDAwKSByZXR1cm4gYCR7KG4gLyAxMDAwMDAwMDAwKS50b0ZpeGVkKG9wdGlvbnMuZGVjaW1hbHMgPz8gMSl9QmA7XG4gICAgICBpZiAoYWJzID49IDEwMDAwMDApIHJldHVybiBgJHsobiAvIDEwMDAwMDApLnRvRml4ZWQob3B0aW9ucy5kZWNpbWFscyA/PyAxKX1NYDtcbiAgICAgIGlmIChhYnMgPj0gMTAwMCkgcmV0dXJuIGAkeyhuIC8gMTAwMCkudG9GaXhlZChvcHRpb25zLmRlY2ltYWxzID8/IDEpfUtgO1xuICAgICAgcmV0dXJuIG4udG9TdHJpbmcoKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBtaW5EZWNpbWFscyA9IG9wdGlvbnMubWluRGVjaW1hbHMgPz8gb3B0aW9ucy5kZWNpbWFscyA/PyAob3B0aW9ucy5mb3JjZURlY2ltYWxzID8gMiA6IDApO1xuICBjb25zdCBtYXhEZWNpbWFscyA9IG9wdGlvbnMubWF4RGVjaW1hbHMgPz8gb3B0aW9ucy5kZWNpbWFscyA/PyAob3B0aW9ucy5mb3JjZURlY2ltYWxzID8gMiA6IDIpO1xuXG4gIGNvbnN0IGNhY2hlS2V5ID0gYCR7bG9jYWxlfS0ke21pbkRlY2ltYWxzfS0ke21heERlY2ltYWxzfWA7XG4gIGxldCBmb3JtYXR0ZXIgPSBudW1iZXJGb3JtYXR0ZXJzLmdldChjYWNoZUtleSk7XG4gIGlmICghZm9ybWF0dGVyKSB7XG4gICAgZm9ybWF0dGVyID0gbmV3IEludGwuTnVtYmVyRm9ybWF0KGxvY2FsZSwge1xuICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiBtaW5EZWNpbWFscyxcbiAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogbWF4RGVjaW1hbHMsXG4gICAgfSk7XG4gICAgbnVtYmVyRm9ybWF0dGVycy5zZXQobG9jYWxlLCBmb3JtYXR0ZXIpO1xuICB9XG4gIHJldHVybiBmb3JtYXR0ZXIuZm9ybWF0KG4pO1xufTtcblxuLyoqXG4gKiBGb3JtYXQgcGVyY2VudGFnZSB2YWx1ZSAoZS5nLiwgMTUuNSUpXG4gKiBAcGFyYW0ge251bWJlcnxzdHJpbmd9IHZhbHVlIC0gVmFsdWUgdG8gZm9ybWF0XG4gKiBAcGFyYW0ge251bWJlcn0gW2RlY2ltYWxzPTFdIC0gRGVjaW1hbCBwcmVjaXNpb25cbiAqIEByZXR1cm5zIHtzdHJpbmd9IEZvcm1hdHRlZCBwZXJjZW50YWdlIHN0cmluZ1xuICovXG5leHBvcnQgY29uc3QgZm9ybWF0UGVyY2VudGFnZSA9ICh2YWx1ZSwgZGVjaW1hbHMgPSAxKSA9PiB7XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBcIlwiIHx8IGlzTmFOKHZhbHVlKSkgcmV0dXJuIEZBTExCQUNLO1xuICByZXR1cm4gYCR7cGFyc2VGbG9hdCh2YWx1ZSkudG9GaXhlZChkZWNpbWFscyl9JWA7XG59O1xuXG5leHBvcnQgY29uc3QgZm9ybWF0UGVyY2VudCA9IGZvcm1hdFBlcmNlbnRhZ2U7XG5cbi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgQ09OVEFDVCwgTE9DQVRJT04gJiBGSUxFIEZPUk1BVFRFUlNcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xuXG4vKipcbiAqIEZvcm1hdCBwaG9uZSBudW1iZXIgY2xlYW5seSAoZS5nLiArOTEgOTg3NjUgNDMyMTApXG4gKiBAcGFyYW0ge3N0cmluZ3xudW1iZXJ9IHBob25lIC0gUGhvbmUgbnVtYmVyXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBGb3JtYXR0ZWQgcGhvbmUgbnVtYmVyXG4gKi9cbmV4cG9ydCBjb25zdCBmb3JtYXRQaG9uZSA9IChwaG9uZSkgPT4ge1xuICBpZiAoIXBob25lKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGNvbnN0IHNldHRpbmdzID0gcmVhZENhY2hlZFN5c3RlbVNldHRpbmdzKCk7XG4gIGNvbnN0IGNvbXBhbnlQaG9uZSA9IHNldHRpbmdzLnBob25lIHx8IFwiXCI7XG4gIGxldCBjb3VudHJ5Q29kZSA9IFwiKzkxXCI7XG4gIGlmIChjb21wYW55UGhvbmUuc3RhcnRzV2l0aChcIitcIikpIHtcbiAgICBjb25zdCBtYXRjaCA9IGNvbXBhbnlQaG9uZS5tYXRjaCgvXihcXCtcXGR7MSw0fSkvKTtcbiAgICBpZiAobWF0Y2gpIGNvdW50cnlDb2RlID0gbWF0Y2hbMV07XG4gIH1cbiAgY29uc3QgY2xlYW5lZCA9IChcIlwiICsgcGhvbmUpLnJlcGxhY2UoL1xcRC9nLCBcIlwiKTtcbiAgaWYgKGNsZWFuZWQubGVuZ3RoID09PSAxMCkge1xuICAgIHJldHVybiBgJHtjb3VudHJ5Q29kZX0gJHtjbGVhbmVkLnNsaWNlKDAsIDUpfSAke2NsZWFuZWQuc2xpY2UoNSl9YDtcbiAgfVxuICBpZiAoY2xlYW5lZC5sZW5ndGggPT09IDEyICYmIGNsZWFuZWQuc3RhcnRzV2l0aChcIjkxXCIpKSB7XG4gICAgcmV0dXJuIGAke2NvdW50cnlDb2RlfSAke2NsZWFuZWQuc2xpY2UoMiwgNyl9ICR7Y2xlYW5lZC5zbGljZSg3KX1gO1xuICB9XG4gIHJldHVybiBwaG9uZTtcbn07XG5cbi8qKlxuICogRm9ybWF0IGFuZCB0cmltIGVtYWlsIHN0cmluZ1xuICogQHBhcmFtIHtzdHJpbmd9IGVtYWlsIC0gRW1haWwgYWRkcmVzc1xuICogQHJldHVybnMge3N0cmluZ30gQ2xlYW4gZW1haWwgc3RyaW5nXG4gKi9cbmV4cG9ydCBjb25zdCBmb3JtYXRFbWFpbCA9IChlbWFpbCkgPT4ge1xuICBpZiAoIWVtYWlsIHx8IHR5cGVvZiBlbWFpbCAhPT0gJ3N0cmluZycpIHJldHVybiBGQUxMQkFDSztcbiAgY29uc3QgdHJpbW1lZCA9IGVtYWlsLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICByZXR1cm4gdHJpbW1lZCB8fCBGQUxMQkFDSztcbn07XG5cbi8qKlxuICogRm9ybWF0IGR1cmF0aW9uIGluIGRlY2ltYWwgaG91cnMgdG8gcmVhZGFibGUgc3RyaW5nIChlLmcuLCAyIGhyIDMwIG1pbilcbiAqIEBwYXJhbSB7bnVtYmVyfSBob3VycyAtIER1cmF0aW9uIGluIGRlY2ltYWwgaG91cnNcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEZvcm1hdHRlZCBkdXJhdGlvbiBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGZvcm1hdER1cmF0aW9uID0gKGhvdXJzKSA9PiB7XG4gIGlmIChob3VycyA9PT0gbnVsbCB8fCBob3VycyA9PT0gdW5kZWZpbmVkIHx8IGlzTmFOKGhvdXJzKSB8fCBob3VycyA8PSAwKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGNvbnN0IGggPSBNYXRoLmZsb29yKGhvdXJzKTtcbiAgY29uc3QgbSA9IE1hdGgucm91bmQoKGhvdXJzIC0gaCkgKiA2MCk7XG4gIGNvbnN0IGhEaXNwbGF5ID0gaCA+IDAgPyBgJHtofSBocmAgOiBcIlwiO1xuICBjb25zdCBtRGlzcGxheSA9IG0gPiAwID8gYCR7bX0gbWluYCA6IFwiXCI7XG4gIHJldHVybiBgJHtoRGlzcGxheX0gJHttRGlzcGxheX1gLnRyaW0oKSB8fCBGQUxMQkFDSztcbn07XG5cbi8qKlxuICogRm9ybWF0IGRpc3RhbmNlIGluIG1ldGVycyBvciBraWxvbWV0ZXJzIChlLmcuLCA4NTAgbSwgNC4yIGttKVxuICogQHBhcmFtIHtudW1iZXJ9IG1ldGVyc09yS20gLSBEaXN0YW5jZSB2YWx1ZVxuICogQHBhcmFtIHtib29sZWFufSBbaXNLbT1mYWxzZV0gLSBXaGV0aGVyIGlucHV0IGlzIGFscmVhZHkgaW4ga2lsb21ldGVyc1xuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIGRpc3RhbmNlIHN0cmluZ1xuICovXG5leHBvcnQgY29uc3QgZm9ybWF0RGlzdGFuY2UgPSAobWV0ZXJzT3JLbSwgaXNLbSA9IGZhbHNlKSA9PiB7XG4gIGlmIChtZXRlcnNPckttID09PSBudWxsIHx8IG1ldGVyc09yS20gPT09IHVuZGVmaW5lZCB8fCBpc05hTihtZXRlcnNPckttKSkgcmV0dXJuIEZBTExCQUNLO1xuICBjb25zdCBtZXRlcnMgPSBpc0ttID8gbWV0ZXJzT3JLbSAqIDEwMDAgOiBtZXRlcnNPckttO1xuICBpZiAobWV0ZXJzIDwgMTAwMCkge1xuICAgIHJldHVybiBgJHtNYXRoLnJvdW5kKG1ldGVycyl9IG1gO1xuICB9XG4gIHJldHVybiBgJHsobWV0ZXJzIC8gMTAwMCkudG9GaXhlZCgxKX0ga21gO1xufTtcblxuLyoqXG4gKiBGb3JtYXQgYnl0ZSBzaXplIHRvIHJlYWRhYmxlIHN0cmluZyAoZS5nLiAxLjUgTUIsIDQ1MCBLQilcbiAqIEBwYXJhbSB7bnVtYmVyfSBieXRlcyAtIEZpbGUgc2l6ZSBpbiBieXRlc1xuICogQHJldHVybnMge3N0cmluZ30gRm9ybWF0dGVkIGZpbGUgc2l6ZSBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IGZvcm1hdEZpbGVTaXplID0gKGJ5dGVzKSA9PiB7XG4gIGlmIChieXRlcyA9PT0gbnVsbCB8fCBieXRlcyA9PT0gdW5kZWZpbmVkIHx8IGlzTmFOKGJ5dGVzKSB8fCBieXRlcyA8IDApIHJldHVybiBGQUxMQkFDSztcbiAgaWYgKGJ5dGVzID09PSAwKSByZXR1cm4gXCIwIEJ5dGVzXCI7XG4gIGNvbnN0IGsgPSAxMDI0O1xuICBjb25zdCBzaXplcyA9IFtcIkJ5dGVzXCIsIFwiS0JcIiwgXCJNQlwiLCBcIkdCXCIsIFwiVEJcIl07XG4gIGNvbnN0IGkgPSBNYXRoLmZsb29yKE1hdGgubG9nKGJ5dGVzKSAvIE1hdGgubG9nKGspKTtcbiAgcmV0dXJuIGAke3BhcnNlRmxvYXQoKGJ5dGVzIC8gTWF0aC5wb3coaywgaSkpLnRvRml4ZWQoMSkpfSAke3NpemVzW2ldfWA7XG59O1xuXG4vKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgIElEIEZPUk1BVFRFUlNcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xuXG4vKipcbiAqIFRydW5jYXRlIGxvbmcgSURzIHdpdGggZWxsaXBzaXMgKGUuZy4sIDY1ZmExMC4uLjliMilcbiAqIEBwYXJhbSB7c3RyaW5nfSBpZCAtIFRoZSBJRCBzdHJpbmdcbiAqIEBwYXJhbSB7bnVtYmVyfSBbY2hhcnM9MTRdIC0gTWF4IGxlbmd0aCB0aHJlc2hvbGRcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRydW5jYXRlZCBJRCBzdHJpbmdcbiAqL1xuZXhwb3J0IGNvbnN0IHRydW5jYXRlSWQgPSAoaWQsIGNoYXJzID0gMTQpID0+IHtcbiAgaWYgKCFpZCkgcmV0dXJuIEZBTExCQUNLO1xuICBjb25zdCBzdHIgPSBTdHJpbmcoaWQpLnRyaW0oKTtcbiAgaWYgKHN0ci5sZW5ndGggPD0gY2hhcnMpIHJldHVybiBzdHI7XG4gIHJldHVybiBgJHtzdHIuc2xpY2UoMCwgY2hhcnMpfeKApmA7XG59O1xuXG5leHBvcnQgY29uc3QgZm9ybWF0Qm9va2luZ0lkID0gKGlkKSA9PiAoaWQgPyAoU3RyaW5nKGlkKS5zdGFydHNXaXRoKFwiQkstXCIpID8gU3RyaW5nKGlkKSA6IGBCSy0ke3RydW5jYXRlSWQoaWQsIDEwKX1gKSA6IEZBTExCQUNLKTtcbmV4cG9ydCBjb25zdCBmb3JtYXRQYXltZW50SWQgPSAoaWQpID0+IChpZCA/IChTdHJpbmcoaWQpLnN0YXJ0c1dpdGgoXCJwYXlfXCIpID8gU3RyaW5nKGlkKSA6IHRydW5jYXRlSWQoaWQsIDE0KSkgOiBGQUxMQkFDSyk7XG5leHBvcnQgY29uc3QgZm9ybWF0VHJhbnNhY3Rpb25JZCA9IChpZCkgPT4gKGlkID8gKFN0cmluZyhpZCkuc3RhcnRzV2l0aChcIlRYTi1cIikgPyBTdHJpbmcoaWQpIDogYFRYTi0ke3RydW5jYXRlSWQoaWQsIDEwKX1gKSA6IEZBTExCQUNLKTtcbmV4cG9ydCBjb25zdCBmb3JtYXRSZWZ1bmRJZCA9IChpZCkgPT4gKGlkID8gKFN0cmluZyhpZCkuc3RhcnRzV2l0aChcInJmbmRfXCIpIHx8IFN0cmluZyhpZCkuc3RhcnRzV2l0aChcIlJGRC1cIikgPyBTdHJpbmcoaWQpIDogYFJGRC0ke3RydW5jYXRlSWQoaWQsIDEwKX1gKSA6IEZBTExCQUNLKTtcbmV4cG9ydCBjb25zdCBmb3JtYXRTZXR0bGVtZW50SWQgPSAoaWQpID0+IChpZCA/IChTdHJpbmcoaWQpLnN0YXJ0c1dpdGgoXCJTVEwtXCIpIHx8IFN0cmluZyhpZCkuc3RhcnRzV2l0aChcInNldF9cIikgPyBTdHJpbmcoaWQpIDogYFNUTC0ke3RydW5jYXRlSWQoaWQsIDEwKX1gKSA6IEZBTExCQUNLKTtcbmV4cG9ydCBjb25zdCBmb3JtYXRXaXRoZHJhd2FsSWQgPSAoaWQpID0+IChpZCA/IChTdHJpbmcoaWQpLnN0YXJ0c1dpdGgoXCJXVEQtXCIpIHx8IFN0cmluZyhpZCkuc3RhcnRzV2l0aChcInBvdXRfXCIpID8gU3RyaW5nKGlkKSA6IGBXVEQtJHt0cnVuY2F0ZUlkKGlkLCAxMCl9YCkgOiBGQUxMQkFDSyk7XG5leHBvcnQgY29uc3QgZm9ybWF0V2FsbGV0SWQgPSAoaWQpID0+IChpZCA/IChTdHJpbmcoaWQpLnN0YXJ0c1dpdGgoXCJXQUwtXCIpID8gU3RyaW5nKGlkKSA6IGBXQUwtJHt0cnVuY2F0ZUlkKGlkLCAxMCl9YCkgOiBGQUxMQkFDSyk7XG5leHBvcnQgY29uc3QgZm9ybWF0UHJvdmlkZXJJZCA9IChpZCkgPT4gKGlkID8gKFN0cmluZyhpZCkuc3RhcnRzV2l0aChcIlBSVi1cIikgPyBTdHJpbmcoaWQpIDogYFBSVi0ke3RydW5jYXRlSWQoaWQsIDEwKX1gKSA6IEZBTExCQUNLKTtcbmV4cG9ydCBjb25zdCBmb3JtYXRDdXN0b21lcklkID0gKGlkKSA9PiAoaWQgPyAoU3RyaW5nKGlkKS5zdGFydHNXaXRoKFwiQ1VTVC1cIikgPyBTdHJpbmcoaWQpIDogYENVU1QtJHt0cnVuY2F0ZUlkKGlkLCAxMCl9YCkgOiBGQUxMQkFDSyk7XG5leHBvcnQgY29uc3QgZm9ybWF0SW52b2ljZUlkID0gKGlkKSA9PiAoaWQgPyAoU3RyaW5nKGlkKS5zdGFydHNXaXRoKFwiSU5WLVwiKSA/IFN0cmluZyhpZCkgOiBgSU5WLSR7dHJ1bmNhdGVJZChpZCwgMTApfWApIDogRkFMTEJBQ0spO1xuXG4vKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgIENPTU1PTiBTVFJJTkcgJiBVVElMSVRZIEhFTFBFUlNcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xuXG4vKipcbiAqIENhcGl0YWxpemUgZmlyc3QgbGV0dGVyIG9mIHN0cmluZ1xuICogQHBhcmFtIHtzdHJpbmd9IHN0clxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGNvbnN0IGNhcGl0YWxpemUgPSAoc3RyKSA9PiB7XG4gIGlmICghc3RyIHx8IHR5cGVvZiBzdHIgIT09IFwic3RyaW5nXCIpIHJldHVybiBcIlwiO1xuICByZXR1cm4gc3RyLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RyLnNsaWNlKDEpLnRvTG93ZXJDYXNlKCk7XG59O1xuXG4vKipcbiAqIENvbnZlcnQgc25ha2VfY2FzZSwga2ViYWItY2FzZSwgb3Igc3BhY2VkIHN0cmluZyB0byBUaXRsZSBDYXNlXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5jb25zdCBUSVRMRV9DQVNFX0FDUk9OWU1TID0gbmV3IFNldChbJ0lEJywgJ1VUUicsICdJRlNDJywgJ0dTVCcsICdBUEknLCAnUERGJywgJ0NTVicsICdYTFNYJywgJ1VSTCcsICdVUEknLCAnUVInXSk7XG5cbmV4cG9ydCBjb25zdCB0aXRsZUNhc2UgPSAoc3RyKSA9PiB7XG4gIGlmICghc3RyIHx8IHR5cGVvZiBzdHIgIT09IFwic3RyaW5nXCIpIHJldHVybiBcIlwiO1xuICByZXR1cm4gc3RyXG4gICAgLnJlcGxhY2UoLyhbYS16XSkoW0EtWl0pL2csICckMSAkMicpXG4gICAgLnJlcGxhY2UoL1tfLV0rL2csIFwiIFwiKVxuICAgIC5zcGxpdChcIiBcIilcbiAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgLm1hcCgod29yZCkgPT4ge1xuICAgICAgY29uc3QgdXBwZXIgPSB3b3JkLnRvVXBwZXJDYXNlKCk7XG4gICAgICBpZiAoVElUTEVfQ0FTRV9BQ1JPTllNUy5oYXModXBwZXIpKSByZXR1cm4gdXBwZXI7XG4gICAgICByZXR1cm4gd29yZC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHdvcmQuc2xpY2UoMSkudG9Mb3dlckNhc2UoKTtcbiAgICB9KVxuICAgIC5qb2luKFwiIFwiKTtcbn07XG5cbi8qKlxuICogU2FmZWx5IHJldHVybiB2YWx1ZSBvciBmYWxsYmFjayBpZiBlbXB0eS9mYWxzeVxuICogQHBhcmFtIHsqfSB2YWxcbiAqIEBwYXJhbSB7c3RyaW5nfSBbZmFsbGJhY2s9RkFMTEJBQ0tdXG4gKiBAcmV0dXJucyB7Kn1cbiAqL1xuZXhwb3J0IGNvbnN0IHNhZmVWYWx1ZSA9ICh2YWwsIGZhbGxiYWNrID0gRkFMTEJBQ0spID0+IHtcbiAgaWYgKHZhbCA9PT0gbnVsbCB8fCB2YWwgPT09IHVuZGVmaW5lZCB8fCB2YWwgPT09IFwiXCIgfHwgKHR5cGVvZiB2YWwgPT09IFwibnVtYmVyXCIgJiYgaXNOYU4odmFsKSkpIHtcbiAgICByZXR1cm4gZmFsbGJhY2s7XG4gIH1cbiAgcmV0dXJuIHZhbDtcbn07XG5cbi8qKlxuICogQ2hlY2sgaWYgYSB2YWx1ZSBpcyBlbXB0eSAobnVsbCwgdW5kZWZpbmVkLCBlbXB0eSBzdHJpbmcsIGVtcHR5IGFycmF5LCBlbXB0eSBvYmplY3QpXG4gKiBAcGFyYW0geyp9IHZhbFxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmV4cG9ydCBjb25zdCBpc0VtcHR5VmFsdWUgPSAodmFsKSA9PiB7XG4gIGlmICh2YWwgPT09IG51bGwgfHwgdmFsID09PSB1bmRlZmluZWQgfHwgdmFsID09PSBcIlwiKSByZXR1cm4gdHJ1ZTtcbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsKSkgcmV0dXJuIHZhbC5sZW5ndGggPT09IDA7XG4gIGlmICh0eXBlb2YgdmFsID09PSBcIm9iamVjdFwiKSByZXR1cm4gT2JqZWN0LmtleXModmFsKS5sZW5ndGggPT09IDA7XG4gIHJldHVybiBmYWxzZTtcbn07XG5cbi8qKlxuICogQ29weSB0ZXh0IHRvIHVzZXIgY2xpcGJvYXJkIHdpdGggZmFsbGJhY2sgc3VwcG9ydFxuICogQHBhcmFtIHtzdHJpbmd9IHRleHRcbiAqIEByZXR1cm5zIHtQcm9taXNlPGJvb2xlYW4+fVxuICovXG5leHBvcnQgY29uc3QgY29weVRvQ2xpcGJvYXJkID0gYXN5bmMgKHRleHQpID0+IHtcbiAgaWYgKCF0ZXh0KSByZXR1cm4gZmFsc2U7XG4gIHRyeSB7XG4gICAgaWYgKG5hdmlnYXRvcj8uY2xpcGJvYXJkPy53cml0ZVRleHQpIHtcbiAgICAgIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHRleHQpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGNvbnN0IHRleHRBcmVhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInRleHRhcmVhXCIpO1xuICAgIHRleHRBcmVhLnZhbHVlID0gdGV4dDtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRleHRBcmVhKTtcbiAgICB0ZXh0QXJlYS5zZWxlY3QoKTtcbiAgICBjb25zdCBzdWNjZXNzID0gZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJjb3B5XCIpO1xuICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodGV4dEFyZWEpO1xuICAgIHJldHVybiBzdWNjZXNzO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGNvcHkgdG8gY2xpcGJvYXJkOlwiLCBlcnIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuLyoqXG4gKiBQcm9ncmFtbWF0aWNhbGx5IGRvd25sb2FkIGEgZmlsZSBmcm9tIFVSTFxuICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICogQHBhcmFtIHtzdHJpbmd9IGZpbGVOYW1lXG4gKi9cbmV4cG9ydCBjb25zdCBkb3dubG9hZEZpbGUgPSAodXJsLCBmaWxlTmFtZSA9IFwiZG93bmxvYWRcIikgPT4ge1xuICBpZiAoIXVybCkgcmV0dXJuO1xuICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XG4gIGxpbmsuaHJlZiA9IHVybDtcbiAgbGluay5kb3dubG9hZCA9IGZpbGVOYW1lO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xuICBsaW5rLmNsaWNrKCk7XG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XG59O1xuXG4vKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgIFBSRVNFUlZFRCBJTUFHRSwgR0VPQ09ESU5HICYgTUFQIFVUSUxJVElFU1xuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXG5cbmV4cG9ydCBjb25zdCBnZXRPcHRpbWl6ZWRDbG91ZGluYXJ5VXJsID0gKHVybCwgd2lkdGggPSA4MDApID0+IHtcbiAgaWYgKCF1cmwgfHwgdHlwZW9mIHVybCAhPT0gJ3N0cmluZycpIHJldHVybiB1cmw7XG4gIGlmICghdXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSB8fCAhdXJsLmluY2x1ZGVzKCdyZXMuY2xvdWRpbmFyeS5jb20nKSkgcmV0dXJuIHVybDtcbiAgaWYgKHVybC5pbmNsdWRlcygnL3MtLScpKSByZXR1cm4gdXJsO1xuXG4gIGxldCBjbGVhblVybCA9IHVybDtcbiAgY29uc3QgdXBsb2FkUmVnZXggPSAvXFwvKGltYWdlXFwvdXBsb2FkfHVwbG9hZClcXC8oW14vXSspXFwvLztcbiAgY29uc3QgbWF0Y2ggPSBjbGVhblVybC5tYXRjaCh1cGxvYWRSZWdleCk7XG4gIGlmIChtYXRjaCkge1xuICAgIGNvbnN0IHRyYW5zZm9ybVN0ciA9IG1hdGNoWzJdO1xuICAgIGlmICh0cmFuc2Zvcm1TdHIuaW5jbHVkZXMoJ2ZfYXV0bycpIHx8IHRyYW5zZm9ybVN0ci5pbmNsdWRlcygncV9hdXRvJykgfHwgdHJhbnNmb3JtU3RyLmluY2x1ZGVzKCd3XycpIHx8IHRyYW5zZm9ybVN0ci5pbmNsdWRlcygnY18nKSkge1xuICAgICAgY2xlYW5VcmwgPSBjbGVhblVybC5yZXBsYWNlKGAvJHttYXRjaFsxXX0vJHt0cmFuc2Zvcm1TdHJ9L2AsIGAvJHttYXRjaFsxXX0vYCk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgdHJhbnNmb3JtID0gYGZfYXV0byxxX2F1dG8sd18ke3dpZHRofWA7XG4gIGlmIChjbGVhblVybC5pbmNsdWRlcygnL2ltYWdlL3VwbG9hZC8nKSkge1xuICAgIHJldHVybiBjbGVhblVybC5yZXBsYWNlKCcvaW1hZ2UvdXBsb2FkLycsIGAvaW1hZ2UvdXBsb2FkLyR7dHJhbnNmb3JtfS9gKTtcbiAgfSBlbHNlIGlmIChjbGVhblVybC5pbmNsdWRlcygnL3VwbG9hZC8nKSAmJiAhY2xlYW5VcmwuaW5jbHVkZXMoJy9yYXcvdXBsb2FkLycpICYmICFjbGVhblVybC5pbmNsdWRlcygnL3ZpZGVvL3VwbG9hZC8nKSkge1xuICAgIHJldHVybiBjbGVhblVybC5yZXBsYWNlKCcvdXBsb2FkLycsIGAvdXBsb2FkLyR7dHJhbnNmb3JtfS9gKTtcbiAgfVxuICByZXR1cm4gY2xlYW5Vcmw7XG59O1xuXG5leHBvcnQgY29uc3QgY29tcHJlc3NJbWFnZSA9IChmaWxlLCBvcHRpb25zID0ge30pID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgY29uc3QgeyBtYXhXaWR0aCA9IDE2MDAsIG1heEhlaWdodCA9IDE2MDAsIHF1YWxpdHkgPSAwLjgyIH0gPSBvcHRpb25zO1xuICAgIGlmICghZmlsZSB8fCAhZmlsZS50eXBlLnN0YXJ0c1dpdGgoJ2ltYWdlLycpKSByZXR1cm4gcmVzb2x2ZShmaWxlKTtcblxuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgcmVhZGVyLm9ubG9hZCA9IChldmVudCkgPT4ge1xuICAgICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgICBpbWcub25sb2FkID0gKCkgPT4ge1xuICAgICAgICBsZXQgd2lkdGggPSBpbWcud2lkdGg7XG4gICAgICAgIGxldCBoZWlnaHQgPSBpbWcuaGVpZ2h0O1xuICAgICAgICBpZiAod2lkdGggPiBtYXhXaWR0aCB8fCBoZWlnaHQgPiBtYXhIZWlnaHQpIHtcbiAgICAgICAgICBpZiAod2lkdGggPiBoZWlnaHQpIHtcbiAgICAgICAgICAgIGhlaWdodCA9IE1hdGgucm91bmQoKGhlaWdodCAqIG1heFdpZHRoKSAvIHdpZHRoKTtcbiAgICAgICAgICAgIHdpZHRoID0gbWF4V2lkdGg7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHdpZHRoID0gTWF0aC5yb3VuZCgod2lkdGggKiBtYXhIZWlnaHQpIC8gaGVpZ2h0KTtcbiAgICAgICAgICAgIGhlaWdodCA9IG1heEhlaWdodDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgIGNhbnZhcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICBjYW52YXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgY3R4LmRyYXdJbWFnZShpbWcsIDAsIDAsIHdpZHRoLCBoZWlnaHQpO1xuXG4gICAgICAgIGNhbnZhcy50b0Jsb2IoKGJsb2IpID0+IHtcbiAgICAgICAgICBpZiAoIWJsb2IpIHJldHVybiByZXNvbHZlKGZpbGUpO1xuICAgICAgICAgIGNvbnN0IGNvbXByZXNzZWRGaWxlID0gbmV3IEZpbGUoW2Jsb2JdLCBmaWxlLm5hbWUucmVwbGFjZSgvXFwuW14vLl0rJC8sIFwiXCIpICsgXCIuanBlZ1wiLCB7XG4gICAgICAgICAgICB0eXBlOiBcImltYWdlL2pwZWdcIixcbiAgICAgICAgICAgIGxhc3RNb2RpZmllZDogRGF0ZS5ub3coKVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJlc29sdmUoY29tcHJlc3NlZEZpbGUuc2l6ZSA8IGZpbGUuc2l6ZSA/IGNvbXByZXNzZWRGaWxlIDogZmlsZSk7XG4gICAgICAgIH0sIFwiaW1hZ2UvanBlZ1wiLCBxdWFsaXR5KTtcbiAgICAgIH07XG4gICAgICBpbWcub25lcnJvciA9ICgpID0+IHJlc29sdmUoZmlsZSk7XG4gICAgICBpbWcuc3JjID0gZXZlbnQudGFyZ2V0LnJlc3VsdDtcbiAgICB9O1xuICAgIHJlYWRlci5vbmVycm9yID0gKCkgPT4gcmVzb2x2ZShmaWxlKTtcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgYnVpbGRBZGRyZXNzUHJldmlldyA9IChhZGRyZXNzID0ge30pID0+IHtcbiAgY29uc3QgY2xlYW5QYXJ0ID0gKHZhbCkgPT4ge1xuICAgIGlmICghdmFsKSByZXR1cm4gXCJcIjtcbiAgICByZXR1cm4gdmFsLnRvU3RyaW5nKClcbiAgICAgIC5yZXBsYWNlKC9bXFx1MDkwMC1cXHUwOTdGXFx1MEEwMC1cXHUwQTdGXS9nLCBcIlwiKVxuICAgICAgLnJlcGxhY2UoL1xccytkaXN0cmljdCQvaSwgXCJcIilcbiAgICAgIC5yZXBsYWNlKC9eWywuXFxzLV0rfFssLlxccy1dKyQvZywgXCJcIilcbiAgICAgIC50cmltKCk7XG4gIH07XG5cbiAgY29uc3QgaG91c2VOdW1iZXIgPSBjbGVhblBhcnQoYWRkcmVzcy5ob3VzZU51bWJlciB8fCBhZGRyZXNzLmhvdXNlX251bWJlciB8fCBhZGRyZXNzLmhvdXNlIHx8IGFkZHJlc3MuZmxhdCB8fCBhZGRyZXNzLmFwYXJ0bWVudCB8fCBhZGRyZXNzLnVuaXQgfHwgYWRkcmVzcy5vZmZpY2UpO1xuICBjb25zdCByb2FkID0gY2xlYW5QYXJ0KGFkZHJlc3Mucm9hZCB8fCBhZGRyZXNzLnN0cmVldE5hbWUgfHwgYWRkcmVzcy5zdHJlZXQgfHwgYWRkcmVzcy5mb290d2F5IHx8IGFkZHJlc3MucGF0aCk7XG4gIGNvbnN0IGxhbmRtYXJrID0gY2xlYW5QYXJ0KGFkZHJlc3MubGFuZG1hcmspO1xuICBjb25zdCBhcmVhID0gY2xlYW5QYXJ0KGFkZHJlc3MuYXJlYSB8fCBhZGRyZXNzLmxvY2FsaXR5IHx8IGFkZHJlc3MucmVzaWRlbnRpYWwgfHwgYWRkcmVzcy5uZWlnaGJvdXJob29kIHx8IGFkZHJlc3Muc3VidXJiIHx8IGFkZHJlc3MucXVhcnRlciB8fCBhZGRyZXNzLmhhbWxldCB8fCBhZGRyZXNzLnZpbGxhZ2UpO1xuICBjb25zdCBjaXR5ID0gY2xlYW5QYXJ0KGFkZHJlc3MuY2l0eSB8fCBhZGRyZXNzLnRvd24gfHwgYWRkcmVzcy5tdW5pY2lwYWxpdHkgfHwgYWRkcmVzcy5jaXR5X2Rpc3RyaWN0IHx8IGFkZHJlc3MuY291bnR5IHx8IGFkZHJlc3Muc3RhdGVfZGlzdHJpY3QpO1xuICBjb25zdCBwaW5jb2RlID0gY2xlYW5QYXJ0KGFkZHJlc3MucGluY29kZSB8fCBhZGRyZXNzLnBvc3RhbENvZGUgfHwgYWRkcmVzcy5wb3N0Y29kZSB8fCBhZGRyZXNzLnBvc3RhbF9jb2RlKTtcblxuICBjb25zdCBwYXJ0cyA9IFtdO1xuICBmb3IgKGNvbnN0IHBhcnQgb2YgW2hvdXNlTnVtYmVyLCByb2FkLCBsYW5kbWFyaywgYXJlYSwgY2l0eSwgcGluY29kZV0pIHtcbiAgICBpZiAoIXBhcnQpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHBhcnRMb3dlciA9IHBhcnQudG9Mb3dlckNhc2UoKTtcbiAgICBsZXQgZHVwbGljYXRlSW5kZXggPSAtMTtcbiAgICBjb25zdCBpc0R1cGxpY2F0ZSA9IHBhcnRzLnNvbWUoKGV4aXN0aW5nLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgZXhpc3RpbmdMb3dlciA9IGV4aXN0aW5nLnRvTG93ZXJDYXNlKCk7XG4gICAgICBjb25zdCBtYXRjaGVkID0gZXhpc3RpbmdMb3dlciA9PT0gcGFydExvd2VyIHx8IGV4aXN0aW5nTG93ZXIuaW5jbHVkZXMocGFydExvd2VyKSB8fCBwYXJ0TG93ZXIuaW5jbHVkZXMoZXhpc3RpbmdMb3dlcik7XG4gICAgICBpZiAobWF0Y2hlZCkgZHVwbGljYXRlSW5kZXggPSBpbmRleDtcbiAgICAgIHJldHVybiBtYXRjaGVkO1xuICAgIH0pO1xuICAgIGlmIChpc0R1cGxpY2F0ZSkge1xuICAgICAgaWYgKGR1cGxpY2F0ZUluZGV4ICE9PSAtMSAmJiBwYXJ0Lmxlbmd0aCA+IHBhcnRzW2R1cGxpY2F0ZUluZGV4XS5sZW5ndGgpIHtcbiAgICAgICAgcGFydHNbZHVwbGljYXRlSW5kZXhdID0gcGFydDtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcGFydHMucHVzaChwYXJ0KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHBhcnRzLmpvaW4oXCIsIFwiKTtcbn07XG5cbmV4cG9ydCBjb25zdCBmb3JtYXRBZGRyZXNzID0gKGFkZHJlc3MpID0+IHtcbiAgaWYgKCFhZGRyZXNzKSByZXR1cm4gRkFMTEJBQ0s7XG4gIGlmICh0eXBlb2YgYWRkcmVzcyA9PT0gJ3N0cmluZycpIHJldHVybiBhZGRyZXNzLnRyaW0oKSB8fCBGQUxMQkFDSztcbiAgaWYgKHR5cGVvZiBhZGRyZXNzID09PSAnb2JqZWN0Jykge1xuICAgIGNvbnN0IHByZXZpZXcgPSBidWlsZEFkZHJlc3NQcmV2aWV3KGFkZHJlc3MpO1xuICAgIGlmIChwcmV2aWV3KSByZXR1cm4gcHJldmlldztcbiAgICByZXR1cm4gW2FkZHJlc3Muc3RyZWV0IHx8IGFkZHJlc3MuYWRkcmVzc0xpbmUsIGFkZHJlc3MuY2l0eSwgYWRkcmVzcy5zdGF0ZSwgYWRkcmVzcy5wb3N0YWxDb2RlIHx8IGFkZHJlc3MucGluY29kZSwgYWRkcmVzcy5jb3VudHJ5XVxuICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgLmpvaW4oJywgJykgfHwgRkFMTEJBQ0s7XG4gIH1cbiAgcmV0dXJuIEZBTExCQUNLO1xufTtcblxuZXhwb3J0IGNvbnN0IHNtYXJ0QWRkcmVzc0J1aWxkZXIgPSAoYWRkcmVzc09iaiwgZGlzcGxheU5hbWUgPSBcIlwiKSA9PiB7XG4gIGNvbnN0IGFkZHIgPSBhZGRyZXNzT2JqIHx8IHt9O1xuICBjb25zdCBjbGVhblBhcnQgPSAodmFsKSA9PiB7XG4gICAgaWYgKCF2YWwpIHJldHVybiBcIlwiO1xuICAgIGxldCBzID0gdmFsLnRvU3RyaW5nKCkudHJpbSgpO1xuICAgIHMgPSBzLnJlcGxhY2UoL1tcXHUwOTAwLVxcdTA5N0ZcXHUwQTAwLVxcdTBBN0ZdL2csIFwiXCIpO1xuICAgIHMgPSBzLnJlcGxhY2UoL15bLC5cXHMtXSt8WywuXFxzLV0rJC9nLCBcIlwiKS50cmltKCk7XG4gICAgcmV0dXJuIHM7XG4gIH07XG5cbiAgY29uc3QgaXNVbndhbnRlZCA9ICh2YWwpID0+IHtcbiAgICBpZiAoIXZhbCkgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgcyA9IHZhbC50b1N0cmluZygpLnRvTG93ZXJDYXNlKCk7XG4gICAgcmV0dXJuIChcbiAgICAgIHMuaW5jbHVkZXMoXCJ0YWhzaWxcIikgfHwgcy5pbmNsdWRlcyhcInRlaHNpbFwiKSB8fCBzLmluY2x1ZGVzKFwi4KSk4KS54KS44KWA4KSyXCIpIHx8XG4gICAgICBzLmluY2x1ZGVzKFwi4Kik4Ki54Ki/4Ki44KmA4KiyXCIpIHx8IHMuaW5jbHVkZXMoXCJ0YWx1a1wiKSB8fCBzLmluY2x1ZGVzKFwidGFsdWthXCIpIHx8XG4gICAgICBzLmluY2x1ZGVzKFwic3ViZGlzdHJpY3RcIikgfHwgcy5pbmNsdWRlcyhcInN1Yi1kaXN0cmljdFwiKSB8fCBzID09PSBcImluZGlhXCIgfHxcbiAgICAgIHMgPT09IFwiY291bnR5XCIgfHwgcyA9PT0gXCJzdGF0ZSBkaXN0cmljdFwiIHx8IHMgPT09IFwiZGlzdHJpY3RcIiB8fCBzID09PSBcInN0YXRlX2Rpc3RyaWN0XCIgfHxcbiAgICAgIC9bXFx1MDkwMC1cXHUwOTdGXFx1MEEwMC1cXHUwQTdGXS8udGVzdCh2YWwpXG4gICAgKTtcbiAgfTtcblxuICBsZXQgaG91c2VObyA9IGNsZWFuUGFydChhZGRyLmhvdXNlX251bWJlciB8fCBhZGRyLmhvdXNlIHx8IGFkZHIuZmxhdCB8fCBhZGRyLmFwYXJ0bWVudCB8fCBhZGRyLnVuaXQgfHwgYWRkci5vZmZpY2UpO1xuICBsZXQgYnVpbGRpbmcgPSBjbGVhblBhcnQoYWRkci5idWlsZGluZyB8fCBhZGRyLmFwYXJ0bWVudHMgfHwgYWRkci5hbWVuaXR5KTtcbiAgbGV0IHJvYWQgPSBjbGVhblBhcnQoYWRkci5yb2FkIHx8IGFkZHIuc3RyZWV0IHx8IGFkZHIuZm9vdHdheSB8fCBhZGRyLnBhdGgpO1xuICBsZXQgbG9jYWxpdHkgPSBjbGVhblBhcnQoYWRkci5zdWJ1cmIpIHx8IGNsZWFuUGFydChhZGRyLm5laWdoYm91cmhvb2QpIHx8IGNsZWFuUGFydChhZGRyLnJlc2lkZW50aWFsKSB8fCBjbGVhblBhcnQoYWRkci5xdWFydGVyKSB8fCBjbGVhblBhcnQoYWRkci5oYW1sZXQpIHx8IFwiXCI7XG4gIGxldCBjaXR5ID0gY2xlYW5QYXJ0KGFkZHIuY2l0eSB8fCBhZGRyLnRvd24gfHwgYWRkci5tdW5pY2lwYWxpdHkgfHwgYWRkci5jaXR5X2Rpc3RyaWN0IHx8IGFkZHIudmlsbGFnZSB8fCBhZGRyLmNvdW50eSB8fCBhZGRyLnN0YXRlX2Rpc3RyaWN0KS5yZXBsYWNlKC9cXHMrZGlzdHJpY3QkL2ksIFwiXCIpLnRyaW0oKTtcbiAgbGV0IHN0YXRlID0gY2xlYW5QYXJ0KGFkZHIuc3RhdGUpO1xuICBsZXQgcGluY29kZSA9IGNsZWFuUGFydChhZGRyLnBvc3Rjb2RlIHx8IGFkZHIucG9zdGFsX2NvZGUpO1xuXG4gIGNvbnN0IGZhbGxiYWNrTGlzdCA9IFtob3VzZU5vLCBidWlsZGluZywgcm9hZCwgbG9jYWxpdHldLmZpbHRlcihCb29sZWFuKTtcbiAgY29uc3QgZ2V0RmFsbGJhY2sgPSAodmFsKSA9PiAodmFsICYmIHZhbC50cmltKCkgPyB2YWwgOiBmYWxsYmFja0xpc3RbMF0gfHwgXCJcIik7XG5cbiAgaG91c2VObyA9IGdldEZhbGxiYWNrKGhvdXNlTm8pO1xuICBidWlsZGluZyA9IGdldEZhbGxiYWNrKGJ1aWxkaW5nKTtcbiAgcm9hZCA9IGdldEZhbGxiYWNrKHJvYWQpO1xuICBsb2NhbGl0eSA9IGdldEZhbGxiYWNrKGxvY2FsaXR5KTtcblxuICBpZiAoaXNVbndhbnRlZChob3VzZU5vKSkgaG91c2VObyA9IFwiXCI7XG4gIGlmIChpc1Vud2FudGVkKGJ1aWxkaW5nKSkgYnVpbGRpbmcgPSBcIlwiO1xuICBpZiAoaXNVbndhbnRlZChyb2FkKSkgcm9hZCA9IFwiXCI7XG4gIGlmIChpc1Vud2FudGVkKGxvY2FsaXR5KSkgbG9jYWxpdHkgPSBcIlwiO1xuICBpZiAoaXNVbndhbnRlZChjaXR5KSkgY2l0eSA9IFwiXCI7XG4gIGlmIChpc1Vud2FudGVkKHN0YXRlKSkgc3RhdGUgPSBcIlwiO1xuXG4gIGNvbnN0IHBhcnRzID0gW107XG4gIGxldCBob3VzZUJ1aWxkaW5nUGFydCA9IFtob3VzZU5vLCBidWlsZGluZ10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIsIFwiKTtcbiAgaWYgKGhvdXNlTm8gJiYgYnVpbGRpbmcgJiYgKGhvdXNlTm8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhidWlsZGluZy50b0xvd2VyQ2FzZSgpKSB8fCBidWlsZGluZy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGhvdXNlTm8udG9Mb3dlckNhc2UoKSkpKSB7XG4gICAgaG91c2VCdWlsZGluZ1BhcnQgPSBob3VzZU5vLmxlbmd0aCA+IGJ1aWxkaW5nLmxlbmd0aCA/IGhvdXNlTm8gOiBidWlsZGluZztcbiAgfVxuICBpZiAoaG91c2VCdWlsZGluZ1BhcnQpIHBhcnRzLnB1c2goaG91c2VCdWlsZGluZ1BhcnQpO1xuICBpZiAocm9hZCkgcGFydHMucHVzaChyb2FkKTtcblxuICBpZiAoZGlzcGxheU5hbWUpIHtcbiAgICBjb25zdCBkaXNwbGF5UGFydHMgPSBkaXNwbGF5TmFtZS5zcGxpdChcIixcIikubWFwKGNsZWFuUGFydCkuZmlsdGVyKHAgPT4gcCAmJiAhaXNVbndhbnRlZChwKSk7XG4gICAgY29uc3QgY2l0eUxvd2VyID0gY2l0eSA/IGNpdHkudG9Mb3dlckNhc2UoKSA6IFwiXCI7XG4gICAgY29uc3Qgc3RhdGVMb3dlciA9IHN0YXRlID8gc3RhdGUudG9Mb3dlckNhc2UoKSA6IFwiXCI7XG4gICAgZm9yIChjb25zdCBkcCBvZiBkaXNwbGF5UGFydHMpIHtcbiAgICAgIGNvbnN0IGRwTG93ZXIgPSBkcC50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKGRwTG93ZXIuaW5jbHVkZXMoXCJwaGFzZVwiKSB8fCBkcExvd2VyLmluY2x1ZGVzKFwic2VjdG9yXCIpIHx8IGRwTG93ZXIuaW5jbHVkZXMoXCJibG9ja1wiKSB8fCBkcExvd2VyLmluY2x1ZGVzKFwiY29sb255XCIpIHx8IGRwTG93ZXIuaW5jbHVkZXMoXCJlc3RhdGVcIikgfHwgZHBMb3dlci5pbmNsdWRlcyhcInRvd25cIikgfHwgZHBMb3dlci5pbmNsdWRlcyhcInVyYmFuXCIpKSB7XG4gICAgICAgIGNvbnN0IG1hdGNoZWQgPSBwYXJ0cy5zb21lKHAgPT4gcC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGRwTG93ZXIpIHx8IGRwTG93ZXIuaW5jbHVkZXMocC50b0xvd2VyQ2FzZSgpKSk7XG4gICAgICAgIGlmICghbWF0Y2hlZCAmJiBkcExvd2VyICE9PSBjaXR5TG93ZXIgJiYgZHBMb3dlciAhPT0gc3RhdGVMb3dlcikgcGFydHMucHVzaChkcCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKGxvY2FsaXR5ICYmICFwYXJ0cy5zb21lKHAgPT4gcC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGxvY2FsaXR5LnRvTG93ZXJDYXNlKCkpIHx8IGxvY2FsaXR5LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocC50b0xvd2VyQ2FzZSgpKSkpIHBhcnRzLnB1c2gobG9jYWxpdHkpO1xuICBpZiAoY2l0eSAmJiAhcGFydHMuc29tZShwID0+IHAudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhjaXR5LnRvTG93ZXJDYXNlKCkpIHx8IGNpdHkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhwLnRvTG93ZXJDYXNlKCkpKSkgcGFydHMucHVzaChjaXR5KTtcbiAgaWYgKHN0YXRlKSB7XG4gICAgY29uc3QgbWF0Y2hlZCA9IHBhcnRzLnNvbWUocCA9PiBwLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc3RhdGUudG9Mb3dlckNhc2UoKSkgfHwgc3RhdGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhwLnRvTG93ZXJDYXNlKCkpKTtcbiAgICBsZXQgc3RhdGVTdHJpbmcgPSBwaW5jb2RlID8gYCR7c3RhdGV9ICR7cGluY29kZX1gIDogc3RhdGU7XG4gICAgaWYgKCFtYXRjaGVkKSBwYXJ0cy5wdXNoKHN0YXRlU3RyaW5nKTtcbiAgICBlbHNlIHtcbiAgICAgIGNvbnN0IGlkeCA9IHBhcnRzLmZpbmRJbmRleChwID0+IHAudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzdGF0ZS50b0xvd2VyQ2FzZSgpKSk7XG4gICAgICBpZiAoaWR4ICE9PSAtMSkgcGFydHNbaWR4XSA9IHN0YXRlU3RyaW5nO1xuICAgIH1cbiAgfSBlbHNlIGlmIChwaW5jb2RlKSBwYXJ0cy5wdXNoKHBpbmNvZGUpO1xuXG4gIGNvbnN0IHVuaXF1ZVBhcnRzID0gW107XG4gIGZvciAoY29uc3QgcGFydCBvZiBwYXJ0cykge1xuICAgIGlmICghdW5pcXVlUGFydHMuc29tZShwID0+IHAudG9Mb3dlckNhc2UoKSA9PT0gcGFydC50b0xvd2VyQ2FzZSgpKSkgdW5pcXVlUGFydHMucHVzaChwYXJ0KTtcbiAgfVxuICByZXR1cm4gdW5pcXVlUGFydHMuam9pbihcIiwgXCIpO1xufTtcblxuZXhwb3J0IGNvbnN0IGNsZWFuQWRkcmVzc0ZpZWxkcyA9IChhZGRyZXNzT2JqLCBkaXNwbGF5TmFtZSA9IFwiXCIpID0+IHtcbiAgY29uc3QgYWRkciA9IGFkZHJlc3NPYmogfHwge307XG4gIGNvbnN0IGNsZWFuUGFydCA9ICh2YWwpID0+IHtcbiAgICBpZiAoIXZhbCkgcmV0dXJuIFwiXCI7XG4gICAgbGV0IHMgPSB2YWwudG9TdHJpbmcoKS50cmltKCk7XG4gICAgcyA9IHMucmVwbGFjZSgvW1xcdTA5MDAtXFx1MDk3RlxcdTBBMDAtXFx1MEE3Rl0vZywgXCJcIikucmVwbGFjZSgvXlssLlxccy1dK3xbLC5cXHMtXSskL2csIFwiXCIpLnRyaW0oKTtcbiAgICByZXR1cm4gcztcbiAgfTtcblxuICBjb25zdCBpc1Vud2FudGVkID0gKHZhbCkgPT4ge1xuICAgIGlmICghdmFsKSByZXR1cm4gdHJ1ZTtcbiAgICBjb25zdCBzID0gdmFsLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gcy5pbmNsdWRlcyhcInRhaHNpbFwiKSB8fCBzLmluY2x1ZGVzKFwidGVoc2lsXCIpIHx8IHMuaW5jbHVkZXMoXCJzdWJkaXN0cmljdFwiKSB8fCBzID09PSBcImluZGlhXCIgfHwgcyA9PT0gXCJjb3VudHlcIiB8fCBzID09PSBcImRpc3RyaWN0XCIgfHwgL1tcXHUwOTAwLVxcdTA5N0ZcXHUwQTAwLVxcdTBBN0ZdLy50ZXN0KHZhbCk7XG4gIH07XG5cbiAgbGV0IGhvdXNlTm8gPSBjbGVhblBhcnQoYWRkci5ob3VzZV9udW1iZXIgfHwgYWRkci5ob3VzZSB8fCBhZGRyLmZsYXQgfHwgYWRkci5hcGFydG1lbnQgfHwgYWRkci51bml0IHx8IGFkZHIub2ZmaWNlKTtcbiAgbGV0IGJ1aWxkaW5nID0gY2xlYW5QYXJ0KGFkZHIuYnVpbGRpbmcgfHwgYWRkci5hcGFydG1lbnRzIHx8IGFkZHIuYW1lbml0eSk7XG4gIGxldCByb2FkID0gY2xlYW5QYXJ0KGFkZHIucm9hZCB8fCBhZGRyLnN0cmVldCB8fCBhZGRyLmZvb3R3YXkgfHwgYWRkci5wYXRoKTtcbiAgbGV0IHJlc2lkZW50aWFsID0gY2xlYW5QYXJ0KGFkZHIucmVzaWRlbnRpYWwgfHwgYWRkci5kZXZlbG9wbWVudCk7XG4gIGxldCBuZWlnaGJvdXJob29kID0gY2xlYW5QYXJ0KGFkZHIubmVpZ2hib3VyaG9vZCB8fCBhZGRyLnF1YXJ0ZXIpO1xuICBsZXQgc3VidXJiID0gY2xlYW5QYXJ0KGFkZHIuc3VidXJiIHx8IGFkZHIudmlsbGFnZSB8fCBhZGRyLnRvd25sYW5kKTtcbiAgbGV0IHF1YXJ0ZXIgPSBjbGVhblBhcnQoYWRkci5xdWFydGVyKTtcbiAgbGV0IGhhbWxldCA9IGNsZWFuUGFydChhZGRyLmhhbWxldCk7XG4gIGxldCBsYW5kbWFyayA9IGNsZWFuUGFydChhZGRyLmxhbmRtYXJrIHx8IGFkZHIucGxhY2UgfHwgYWRkci5jb21tZXJjaWFsIHx8IGFkZHIuaW5kdXN0cmlhbCk7XG4gIGxldCBjaXR5ID0gY2xlYW5QYXJ0KGFkZHIuY2l0eSB8fCBhZGRyLnRvd24gfHwgYWRkci5tdW5pY2lwYWxpdHkgfHwgYWRkci5jaXR5X2Rpc3RyaWN0IHx8IGFkZHIudmlsbGFnZSB8fCBhZGRyLmNvdW50eSB8fCBhZGRyLnN0YXRlX2Rpc3RyaWN0KS5yZXBsYWNlKC9cXHMrZGlzdHJpY3QkL2ksIFwiXCIpLnRyaW0oKTtcbiAgbGV0IHN0YXRlID0gY2xlYW5QYXJ0KGFkZHIuc3RhdGUpO1xuICBsZXQgcGluY29kZSA9IGNsZWFuUGFydChhZGRyLnBvc3Rjb2RlIHx8IGFkZHIucG9zdGFsX2NvZGUpO1xuXG4gIGxldCBsb2NhbGl0eSA9IHN1YnVyYiB8fCBuZWlnaGJvdXJob29kIHx8IHJlc2lkZW50aWFsIHx8IHF1YXJ0ZXIgfHwgaGFtbGV0IHx8IFwiXCI7XG4gIGxldCBhcmVhID0gbG9jYWxpdHkgfHwgXCJcIjtcbiAgY29uc3QgZmFsbGJhY2tMaXN0ID0gW2hvdXNlTm8sIGJ1aWxkaW5nLCByb2FkLCByZXNpZGVudGlhbCwgc3VidXJiLCBuZWlnaGJvdXJob29kXS5maWx0ZXIoQm9vbGVhbik7XG4gIGNvbnN0IGdldEZhbGxiYWNrID0gKHZhbCkgPT4gKHZhbCAmJiB2YWwudHJpbSgpID8gdmFsIDogZmFsbGJhY2tMaXN0WzBdIHx8IFwiXCIpO1xuXG4gIGxldCBmaW5hbEhvdXNlTnVtYmVyID0gZ2V0RmFsbGJhY2soaG91c2VObyk7XG4gIGxldCBmaW5hbEJ1aWxkaW5nID0gZ2V0RmFsbGJhY2soYnVpbGRpbmcpO1xuICBsZXQgZmluYWxSb2FkID0gZ2V0RmFsbGJhY2socm9hZCk7XG4gIGxldCBmaW5hbExvY2FsaXR5ID0gZ2V0RmFsbGJhY2sobG9jYWxpdHkpO1xuICBsZXQgZmluYWxMYW5kbWFyayA9IGdldEZhbGxiYWNrKGxhbmRtYXJrKTtcbiAgbGV0IGZpbmFsQXJlYSA9IGdldEZhbGxiYWNrKGFyZWEpO1xuICBsZXQgZmluYWxDaXR5ID0gY2l0eSB8fCBsb2NhbGl0eSB8fCBcIlwiO1xuICBsZXQgZmluYWxTdGF0ZSA9IHN0YXRlIHx8IFwiXCI7XG4gIGxldCBmaW5hbFBpbmNvZGUgPSBwaW5jb2RlIHx8IFwiXCI7XG5cbiAgaWYgKGlzVW53YW50ZWQoZmluYWxIb3VzZU51bWJlcikpIGZpbmFsSG91c2VOdW1iZXIgPSBcIlwiO1xuICBpZiAoaXNVbndhbnRlZChmaW5hbEJ1aWxkaW5nKSkgZmluYWxCdWlsZGluZyA9IFwiXCI7XG4gIGlmIChpc1Vud2FudGVkKGZpbmFsUm9hZCkpIGZpbmFsUm9hZCA9IFwiXCI7XG4gIGlmIChpc1Vud2FudGVkKGZpbmFsTG9jYWxpdHkpKSBmaW5hbExvY2FsaXR5ID0gXCJcIjtcbiAgaWYgKGlzVW53YW50ZWQoZmluYWxMYW5kbWFyaykpIGZpbmFsTGFuZG1hcmsgPSBcIlwiO1xuICBpZiAoaXNVbndhbnRlZChmaW5hbEFyZWEpKSBmaW5hbEFyZWEgPSBcIlwiO1xuICBpZiAoaXNVbndhbnRlZChmaW5hbENpdHkpKSBmaW5hbENpdHkgPSBcIlwiO1xuICBpZiAoaXNVbndhbnRlZChmaW5hbFN0YXRlKSkgZmluYWxTdGF0ZSA9IFwiXCI7XG5cbiAgZmluYWxIb3VzZU51bWJlciA9IGdldEZhbGxiYWNrKGZpbmFsSG91c2VOdW1iZXIpO1xuICBmaW5hbEJ1aWxkaW5nID0gZ2V0RmFsbGJhY2soZmluYWxCdWlsZGluZyk7XG4gIGZpbmFsUm9hZCA9IGdldEZhbGxiYWNrKGZpbmFsUm9hZCk7XG4gIGZpbmFsTG9jYWxpdHkgPSBnZXRGYWxsYmFjayhmaW5hbExvY2FsaXR5KTtcbiAgZmluYWxBcmVhID0gZ2V0RmFsbGJhY2soZmluYWxBcmVhKTtcblxuICBsZXQgY2FuZGlkYXRlcyA9IFtmaW5hbEhvdXNlTnVtYmVyLCBmaW5hbEJ1aWxkaW5nLCBmaW5hbFJvYWQsIGZpbmFsTG9jYWxpdHldLmZpbHRlcihCb29sZWFuKTtcbiAgaWYgKGRpc3BsYXlOYW1lKSB7XG4gICAgY29uc3QgZGlzcGxheVBhcnRzID0gZGlzcGxheU5hbWUuc3BsaXQoXCIsXCIpLm1hcChjbGVhblBhcnQpLmZpbHRlcihwID0+IHAgJiYgIWlzVW53YW50ZWQocCkpO1xuICAgIGNvbnN0IGNpdHlMb3dlciA9IGZpbmFsQ2l0eS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IHN0YXRlTG93ZXIgPSBmaW5hbFN0YXRlLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgcGluY29kZUxvd2VyID0gZmluYWxQaW5jb2RlLnRvTG93ZXJDYXNlKCk7XG5cbiAgICBmb3IgKGNvbnN0IGRwIG9mIGRpc3BsYXlQYXJ0cykge1xuICAgICAgY29uc3QgZHBMb3dlciA9IGRwLnRvTG93ZXJDYXNlKCk7XG4gICAgICBpZiAoZHBMb3dlciA9PT0gY2l0eUxvd2VyIHx8IGRwTG93ZXIgPT09IHN0YXRlTG93ZXIgfHwgZHBMb3dlciA9PT0gcGluY29kZUxvd2VyIHx8IChjaXR5TG93ZXIgJiYgY2l0eUxvd2VyLmluY2x1ZGVzKGRwTG93ZXIpKSB8fCAoc3RhdGVMb3dlciAmJiBzdGF0ZUxvd2VyLmluY2x1ZGVzKGRwTG93ZXIpKSkgY29udGludWU7XG4gICAgICBjb25zdCBhbHJlYWR5TWF0Y2hlZCA9IGNhbmRpZGF0ZXMuc29tZShjID0+IHtcbiAgICAgICAgY29uc3QgY0xvd2VyID0gYy50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gY0xvd2VyLmluY2x1ZGVzKGRwTG93ZXIpIHx8IGRwTG93ZXIuaW5jbHVkZXMoY0xvd2VyKTtcbiAgICAgIH0pO1xuICAgICAgaWYgKCFhbHJlYWR5TWF0Y2hlZCkge1xuICAgICAgICBjYW5kaWRhdGVzLnB1c2goZHApO1xuICAgICAgICBpZiAoIWZpbmFsUm9hZCkgZmluYWxSb2FkID0gZHA7XG4gICAgICAgIGVsc2UgaWYgKCFmaW5hbExvY2FsaXR5IHx8IGZpbmFsTG9jYWxpdHkgPT09IGZpbmFsUm9hZCkgZmluYWxMb2NhbGl0eSA9IGRwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHVuaXF1ZUNhbmRpZGF0ZXMgPSBbXTtcbiAgZm9yIChjb25zdCBjYW5kIG9mIGNhbmRpZGF0ZXMpIHtcbiAgICBjb25zdCBjYW5kTG93ZXIgPSBjYW5kLnRvTG93ZXJDYXNlKCk7XG4gICAgbGV0IGlzRHVwID0gZmFsc2U7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB1bmlxdWVDYW5kaWRhdGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBleGlzdGluZ0xvd2VyID0gdW5pcXVlQ2FuZGlkYXRlc1tpXS50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKGV4aXN0aW5nTG93ZXIgPT09IGNhbmRMb3dlciB8fCBleGlzdGluZ0xvd2VyLmluY2x1ZGVzKGNhbmRMb3dlcikpIHtcbiAgICAgICAgaXNEdXAgPSB0cnVlO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGlmIChjYW5kTG93ZXIuaW5jbHVkZXMoZXhpc3RpbmdMb3dlcikpIHtcbiAgICAgICAgdW5pcXVlQ2FuZGlkYXRlc1tpXSA9IGNhbmQ7XG4gICAgICAgIGlzRHVwID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghaXNEdXApIHVuaXF1ZUNhbmRpZGF0ZXMucHVzaChjYW5kKTtcbiAgfVxuXG4gIGxldCBzdHJlZXRBZGRyZXNzID0gdW5pcXVlQ2FuZGlkYXRlcy5qb2luKFwiLCBcIik7XG4gIGNvbnN0IGZvcm1hdHRlZEFkZHJlc3MgPSBzbWFydEFkZHJlc3NCdWlsZGVyKGFkZHIsIGRpc3BsYXlOYW1lKTtcbiAgY29uc3QgZnVsbEFkZHJlc3NQcmV2aWV3ID0gYnVpbGRBZGRyZXNzUHJldmlldyh7XG4gICAgaG91c2VOdW1iZXI6IGZpbmFsSG91c2VOdW1iZXIsXG4gICAgcm9hZDogZmluYWxSb2FkLFxuICAgIGFyZWE6IGZpbmFsQXJlYSB8fCBmaW5hbExvY2FsaXR5LFxuICAgIGNpdHk6IGZpbmFsQ2l0eSxcbiAgICBwaW5jb2RlOiBmaW5hbFBpbmNvZGVcbiAgfSk7XG5cbiAgY29uc3QgaGFzR3JhbnVsYXJEZXRhaWxzID0gISEoaG91c2VObyB8fCBidWlsZGluZyB8fCByb2FkIHx8IHJlc2lkZW50aWFsIHx8IG5laWdoYm91cmhvb2QgfHwgc3VidXJiIHx8IHF1YXJ0ZXIgfHwgaGFtbGV0IHx8IGxhbmRtYXJrKTtcblxuICByZXR1cm4ge1xuICAgIHN0cmVldDogc3RyZWV0QWRkcmVzcyB8fCBmaW5hbFJvYWQgfHwgZm9ybWF0dGVkQWRkcmVzcyB8fCBcIlwiLFxuICAgIGNpdHk6IGZpbmFsQ2l0eSxcbiAgICBzdGF0ZTogZmluYWxTdGF0ZSxcbiAgICBwb3N0YWxDb2RlOiBmaW5hbFBpbmNvZGUsXG4gICAgcGluY29kZTogZmluYWxQaW5jb2RlLFxuICAgIGFkZHJlc3NMaW5lOiBzdHJlZXRBZGRyZXNzIHx8IGZpbmFsUm9hZCB8fCBcIlwiLFxuICAgIGhvdXNlTnVtYmVyOiBmaW5hbEhvdXNlTnVtYmVyIHx8IFwiXCIsXG4gICAgYnVpbGRpbmc6IGZpbmFsQnVpbGRpbmcgfHwgXCJcIixcbiAgICByb2FkOiBmaW5hbFJvYWQgfHwgXCJcIixcbiAgICBsb2NhbGl0eTogZmluYWxMb2NhbGl0eSB8fCBcIlwiLFxuICAgIGxhbmRtYXJrOiBmaW5hbExhbmRtYXJrIHx8IFwiXCIsXG4gICAgYXJlYTogZmluYWxBcmVhIHx8IGZpbmFsTG9jYWxpdHkgfHwgXCJcIixcbiAgICBjb3VudHJ5OiBjbGVhblBhcnQoYWRkci5jb3VudHJ5KSB8fCBcIkluZGlhXCIsXG4gICAgZm9ybWF0dGVkQWRkcmVzczogZnVsbEFkZHJlc3NQcmV2aWV3IHx8IGZvcm1hdHRlZEFkZHJlc3MgfHwgc3RyZWV0QWRkcmVzcyB8fCBcIlwiLFxuICAgIGlzQ2l0eUNlbnRlck9ubHk6ICFoYXNHcmFudWxhckRldGFpbHMsXG4gICAgbGF0OiBudWxsLFxuICAgIGxuZzogbnVsbFxuICB9O1xufTtcblxuZXhwb3J0IGNvbnN0IExJR0hUX01BUF9USUxFUyA9IFwiaHR0cHM6Ly97c30uYmFzZW1hcHMuY2FydG9jZG4uY29tL3Jhc3RlcnRpbGVzL3ZveWFnZXIve3p9L3t4fS97eX17cn0ucG5nXCI7XG5leHBvcnQgY29uc3QgTElHSFRfTUFQX0FUVFJJQlVUSU9OID0gJyZjb3B5OyA8YSBocmVmPVwiaHR0cHM6Ly93d3cub3BlbnN0cmVldG1hcC5vcmcvY29weXJpZ2h0XCI+T3BlblN0cmVldE1hcDwvYT4gJmNvcHk7IDxhIGhyZWY9XCJodHRwczovL2NhcnRvLmNvbS9hdHRyaWJ1dGlvbnNcIj5DQVJUTzwvYT4nO1xuXG5jb25zdCBHRU9DT0RFX0NBQ0hFID0gbmV3IE1hcCgpO1xuY29uc3QgR0VPQ09ERV9DQUNIRV9UVExfTVMgPSA1ICogNjAgKiAxMDAwO1xuY29uc3QgR0VPQ09ERV9VU0VSX0FHRU5UID0gXCJSYWpTZXJ2aWNlQm9va2luZy8xLjAgKHNlcnZpY2UtYm9va2luZy1hcHApXCI7XG5jb25zdCBjb29yZENhY2hlS2V5ID0gKGxhdCwgbG5nKSA9PiBgJHtOdW1iZXIobGF0KS50b0ZpeGVkKDUpfSwke051bWJlcihsbmcpLnRvRml4ZWQoNSl9YDtcblxuY29uc3QgbWVyZ2VQaG90b25Ob21pbmF0aW0gPSAocGhvdG9uUHJvcHMsIG5vbWluYXRpbUFkZHIsIGRpc3BsYXlOYW1lKSA9PiB7XG4gIGNvbnN0IHAgPSBwaG90b25Qcm9wcyB8fCB7fTtcbiAgY29uc3QgbiA9IG5vbWluYXRpbUFkZHIgfHwge307XG4gIHJldHVybiB7XG4gICAgaG91c2VfbnVtYmVyOiBwLmhvdXNlbnVtYmVyIHx8IG4uaG91c2VfbnVtYmVyIHx8IG4uaG91c2UgfHwgXCJcIixcbiAgICBidWlsZGluZzogcC5uYW1lIHx8IG4uYnVpbGRpbmcgfHwgbi5hcGFydG1lbnRzIHx8IFwiXCIsXG4gICAgcm9hZDogcC5zdHJlZXQgfHwgbi5yb2FkIHx8IG4uc3RyZWV0IHx8IG4uZm9vdHdheSB8fCBcIlwiLFxuICAgIG5laWdoYm91cmhvb2Q6IG4ubmVpZ2hib3VyaG9vZCB8fCBuLnF1YXJ0ZXIgfHwgbi5yZXNpZGVudGlhbCB8fCBcIlwiLFxuICAgIHN1YnVyYjogcC5kaXN0cmljdCB8fCBuLnN1YnVyYiB8fCBuLmNpdHlfZGlzdHJpY3QgfHwgXCJcIixcbiAgICBjaXR5OiBwLmNpdHkgfHwgbi5jaXR5IHx8IG4udG93biB8fCBuLm11bmljaXBhbGl0eSB8fCBuLmNpdHlfZGlzdHJpY3QgfHwgbi52aWxsYWdlIHx8IG4uY291bnR5IHx8IG4uc3RhdGVfZGlzdHJpY3QgfHwgXCJcIixcbiAgICBzdGF0ZTogcC5zdGF0ZSB8fCBuLnN0YXRlIHx8IFwiXCIsXG4gICAgcG9zdGNvZGU6IHAucG9zdGNvZGUgfHwgbi5wb3N0Y29kZSB8fCBcIlwiLFxuICAgIGNvdW50cnk6IHAuY291bnRyeSB8fCBuLmNvdW50cnkgfHwgXCJJbmRpYVwiLFxuICAgIGxhbmRtYXJrOiBuLmFtZW5pdHkgfHwgbi5wbGFjZSB8fCBcIlwiLFxuICAgIF9kaXNwbGF5TmFtZTogZGlzcGxheU5hbWUgfHwgXCJcIlxuICB9O1xufTtcblxuZXhwb3J0IGNvbnN0IHJldmVyc2VHZW9jb2RlID0gYXN5bmMgKGxhdCwgbG5nKSA9PiB7XG4gIGNvbnN0IGNhY2hlS2V5ID0gY29vcmRDYWNoZUtleShsYXQsIGxuZyk7XG4gIGNvbnN0IGNhY2hlZCA9IEdFT0NPREVfQ0FDSEUuZ2V0KGNhY2hlS2V5KTtcbiAgaWYgKGNhY2hlZCAmJiBEYXRlLm5vdygpIC0gY2FjaGVkLnRzIDwgR0VPQ09ERV9DQUNIRV9UVExfTVMpIHtcbiAgICByZXR1cm4gY2FjaGVkLmRhdGE7XG4gIH1cblxuICBsZXQgcGhvdG9uUHJvcHMgPSBudWxsO1xuICBsZXQgbm9taW5hdGltQWRkciA9IG51bGw7XG4gIGxldCBkaXNwbGF5TmFtZSA9IFwiXCI7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBub21SZXMgPSBhd2FpdCBmZXRjaChcbiAgICAgIGBodHRwczovL25vbWluYXRpbS5vcGVuc3RyZWV0bWFwLm9yZy9yZXZlcnNlP2Zvcm1hdD1qc29udjImbGF0PSR7bGF0fSZsb249JHtsbmd9Jnpvb209MTgmYWRkcmVzc2RldGFpbHM9MSZhY2NlcHQtbGFuZ3VhZ2U9ZW5gLFxuICAgICAgeyBoZWFkZXJzOiB7IFwiVXNlci1BZ2VudFwiOiBHRU9DT0RFX1VTRVJfQUdFTlQgfSB9XG4gICAgKTtcbiAgICBjb25zdCBub21Kc29uID0gYXdhaXQgbm9tUmVzLmpzb24oKTtcbiAgICBpZiAobm9tSnNvbj8uYWRkcmVzcykge1xuICAgICAgbm9taW5hdGltQWRkciA9IG5vbUpzb24uYWRkcmVzcztcbiAgICAgIGRpc3BsYXlOYW1lID0gbm9tSnNvbi5kaXNwbGF5X25hbWUgfHwgXCJcIjtcbiAgICB9XG4gIH0gY2F0Y2ggeyAvKiBmYWxsYmFjayAqLyB9XG5cbiAgaWYgKCFub21pbmF0aW1BZGRyKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBob3RvblJlcyA9IGF3YWl0IGZldGNoKGBodHRwczovL3Bob3Rvbi5rb21vb3QuaW8vcmV2ZXJzZT9sYXQ9JHtsYXR9Jmxvbj0ke2xuZ30mbGFuZz1lbmApO1xuICAgICAgY29uc3QgcGhvdG9uSnNvbiA9IGF3YWl0IHBob3RvblJlcy5qc29uKCk7XG4gICAgICBpZiAocGhvdG9uSnNvbj8uZmVhdHVyZXM/LlswXT8ucHJvcGVydGllcykge1xuICAgICAgICBwaG90b25Qcm9wcyA9IHBob3Rvbkpzb24uZmVhdHVyZXNbMF0ucHJvcGVydGllcztcbiAgICAgICAgY29uc3QgcHJvcHMgPSBwaG90b25Kc29uLmZlYXR1cmVzWzBdLnByb3BlcnRpZXM7XG4gICAgICAgIGRpc3BsYXlOYW1lID0gcHJvcHMubmFtZSB8fCBwcm9wcy5zdHJlZXQgfHwgXCJcIjtcbiAgICAgICAgaWYgKHByb3BzLmNpdHkpIGRpc3BsYXlOYW1lICs9IChkaXNwbGF5TmFtZSA/IFwiLCBcIiA6IFwiXCIpICsgcHJvcHMuY2l0eTtcbiAgICAgICAgaWYgKHByb3BzLnN0YXRlKSBkaXNwbGF5TmFtZSArPSAoZGlzcGxheU5hbWUgPyBcIiwgXCIgOiBcIlwiKSArIHByb3BzLnN0YXRlO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggeyAvKiBmYWxsYmFjayAqLyB9XG4gIH1cblxuICBsZXQgbWVyZ2VkID0gbWVyZ2VQaG90b25Ob21pbmF0aW0ocGhvdG9uUHJvcHMsIG5vbWluYXRpbUFkZHIsIGRpc3BsYXlOYW1lKTtcbiAgbGV0IHN0cnVjdHVyZWQgPSBjbGVhbkFkZHJlc3NGaWVsZHMobWVyZ2VkLCBkaXNwbGF5TmFtZSk7XG4gIHN0cnVjdHVyZWQubGF0ID0gbGF0O1xuICBzdHJ1Y3R1cmVkLmxuZyA9IGxuZztcblxuICBHRU9DT0RFX0NBQ0hFLnNldChjYWNoZUtleSwgeyB0czogRGF0ZS5ub3coKSwgZGF0YTogc3RydWN0dXJlZCB9KTtcbiAgcmV0dXJuIHN0cnVjdHVyZWQ7XG59O1xuXG5leHBvcnQgY29uc3QgZGV0ZWN0Q3VycmVudExvY2F0aW9uID0gKG9wdGlvbnMgPSB7fSkgPT4ge1xuICBjb25zdCB0YXJnZXRBY2N1cmFjeSA9IG9wdGlvbnMudGFyZ2V0QWNjdXJhY3kgPz8gODA7XG4gIGNvbnN0IG1heFVwZGF0ZXMgPSBvcHRpb25zLm1heFVwZGF0ZXMgPz8gMjtcbiAgY29uc3QgdGltZW91dE1zID0gb3B0aW9ucy50aW1lb3V0ID8/IDEwMDAwO1xuICBjb25zdCBtYXhSZXRyaWVzID0gb3B0aW9ucy5tYXhSZXRyaWVzID8/IDA7XG4gIGxldCByZXRyeUNvdW50ID0gMDtcblxuICBjb25zdCBleGVjdXRlRGV0ZWN0aW9uID0gKCkgPT5cbiAgICBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBpZiAoIW5hdmlnYXRvci5nZW9sb2NhdGlvbikge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKFwiR2VvbG9jYXRpb24gaXMgbm90IHN1cHBvcnRlZCBieSB5b3VyIGJyb3dzZXJcIikpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsZXQgd2F0Y2hJZCA9IG51bGw7XG4gICAgICBsZXQgdXBkYXRlQ291bnQgPSAwO1xuICAgICAgbGV0IGJlc3RQb3MgPSBudWxsO1xuXG4gICAgICBjb25zdCBjbGVhcldhdGNoU2FmZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKHdhdGNoSWQgIT09IG51bGwpIHtcbiAgICAgICAgICBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uY2xlYXJXYXRjaCh3YXRjaElkKTtcbiAgICAgICAgICB3YXRjaElkID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGNsZWFyV2F0Y2hTYWZlKCk7XG4gICAgICAgIGlmIChiZXN0UG9zICYmIGJlc3RQb3MuY29vcmRzLmFjY3VyYWN5IDw9IHRhcmdldEFjY3VyYWN5KSB7XG4gICAgICAgICAgcmVzb2x2ZVBvc2l0aW9uKGJlc3RQb3MpO1xuICAgICAgICB9IGVsc2UgaWYgKGJlc3RQb3MpIHtcbiAgICAgICAgICByZXNvbHZlUG9zaXRpb24oYmVzdFBvcyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmF2aWdhdG9yLmdlb2xvY2F0aW9uLmdldEN1cnJlbnRQb3NpdGlvbihcbiAgICAgICAgICAgIChmYWxsYmFja1BvcykgPT4gcmVzb2x2ZVBvc2l0aW9uKGZhbGxiYWNrUG9zKSxcbiAgICAgICAgICAgIChmYWxsYmFja0VycikgPT4gcmVqZWN0KG5ldyBFcnJvcihcIkxvY2F0aW9uIHJlcXVlc3QgdGltZWQgb3V0LiBQbGVhc2Ugc2VsZWN0IHlvdXIgYWRkcmVzcyBtYW51YWxseS5cIikpLFxuICAgICAgICAgICAgeyBlbmFibGVIaWdoQWNjdXJhY3k6IGZhbHNlLCB0aW1lb3V0OiAzMDAwIH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9LCB0aW1lb3V0TXMpO1xuXG4gICAgICBjb25zdCByZXNvbHZlUG9zaXRpb24gPSBhc3luYyAocG9zKSA9PiB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgICBjbGVhcldhdGNoU2FmZSgpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHsgbGF0aXR1ZGUsIGxvbmdpdHVkZSwgYWNjdXJhY3kgfSA9IHBvcy5jb29yZHM7XG4gICAgICAgICAgY29uc3QgYWRkcmVzcyA9IGF3YWl0IHJldmVyc2VHZW9jb2RlKGxhdGl0dWRlLCBsb25naXR1ZGUpO1xuICAgICAgICAgIGNvbnN0IHMyQ2VsbElkID0gbGF0TG5nVG9TMkNlbGxJZChsYXRpdHVkZSwgbG9uZ2l0dWRlLCAxMyk7XG4gICAgICAgICAgY29uc3QgczJDZWxsSWRQcmVjaXNlID0gbGF0TG5nVG9TMkNlbGxJZChsYXRpdHVkZSwgbG9uZ2l0dWRlLCAyMCk7XG4gICAgICAgICAgcmVzb2x2ZSh7IGxhdGl0dWRlLCBsb25naXR1ZGUsIGFjY3VyYWN5LCBhZGRyZXNzOiB7IC4uLmFkZHJlc3MsIGxhdDogbGF0aXR1ZGUsIGxuZzogbG9uZ2l0dWRlLCBzMkNlbGxJZCwgczJDZWxsSWRQcmVjaXNlIH0gfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICB3YXRjaElkID0gbmF2aWdhdG9yLmdlb2xvY2F0aW9uLndhdGNoUG9zaXRpb24oXG4gICAgICAgIChwb3MpID0+IHtcbiAgICAgICAgICB1cGRhdGVDb3VudCsrO1xuICAgICAgICAgIGlmICghYmVzdFBvcyB8fCBwb3MuY29vcmRzLmFjY3VyYWN5IDwgYmVzdFBvcy5jb29yZHMuYWNjdXJhY3kpIHtcbiAgICAgICAgICAgIGJlc3RQb3MgPSBwb3M7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChwb3MuY29vcmRzLmFjY3VyYWN5IDw9IHRhcmdldEFjY3VyYWN5IHx8IHVwZGF0ZUNvdW50ID49IG1heFVwZGF0ZXMpIHtcbiAgICAgICAgICAgIHJlc29sdmVQb3NpdGlvbihiZXN0UG9zIHx8IHBvcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICAoZXJyKSA9PiB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgICAgY2xlYXJXYXRjaFNhZmUoKTtcbiAgICAgICAgICBpZiAoZXJyLmNvZGUgPT09IDIgfHwgZXJyLmNvZGUgPT09IDMpIHtcbiAgICAgICAgICAgIG5hdmlnYXRvci5nZW9sb2NhdGlvbi5nZXRDdXJyZW50UG9zaXRpb24oXG4gICAgICAgICAgICAgIChmYWxsYmFja1BvcykgPT4gcmVzb2x2ZVBvc2l0aW9uKGZhbGxiYWNrUG9zKSxcbiAgICAgICAgICAgICAgKGZhbGxiYWNrRXJyKSA9PiByZWplY3QobmV3IEVycm9yKFwiTG9jYXRpb24gdW5hdmFpbGFibGUuIFBsZWFzZSBzZWxlY3QgeW91ciBhZGRyZXNzIG1hbnVhbGx5LlwiKSksXG4gICAgICAgICAgICAgIHsgZW5hYmxlSGlnaEFjY3VyYWN5OiBmYWxzZSwgdGltZW91dDogMzAwMCB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZWplY3QobmV3IEVycm9yKFwiTG9jYXRpb24gcGVybWlzc2lvbiBkZW5pZWQuIEVuYWJsZSBHUFMgaW4gYnJvd3NlciBzZXR0aW5ncy5cIikpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgeyBlbmFibGVIaWdoQWNjdXJhY3k6IHRydWUsIHRpbWVvdXQ6IHRpbWVvdXRNcywgbWF4aW11bUFnZTogMCB9XG4gICAgICApO1xuICAgIH0pO1xuXG4gIHJldHVybiBleGVjdXRlRGV0ZWN0aW9uKCk7XG59O1xuXG5leHBvcnQgY29uc3QgdG9MZWdhY3lBZGRyZXNzRmllbGRzID0gKHN0cnVjdHVyZWQpID0+IHtcbiAgY29uc3QgbGF0ID0gc3RydWN0dXJlZC5sYXQ7XG4gIGNvbnN0IGxuZyA9IHN0cnVjdHVyZWQubG5nO1xuICBjb25zdCBzMkNlbGxJZCA9IChsYXQgJiYgbG5nKSA/IGxhdExuZ1RvUzJDZWxsSWQobGF0LCBsbmcsIDEzKSA6IChzdHJ1Y3R1cmVkLnMyQ2VsbElkIHx8IG51bGwpO1xuICBjb25zdCBzMkNlbGxJZFByZWNpc2UgPSAobGF0ICYmIGxuZykgPyBsYXRMbmdUb1MyQ2VsbElkKGxhdCwgbG5nLCAyMCkgOiAoc3RydWN0dXJlZC5zMkNlbGxJZFByZWNpc2UgfHwgbnVsbCk7XG4gIGNvbnN0IGZvcm1hdHRlZEFkZHJlc3MgPSBidWlsZEFkZHJlc3NQcmV2aWV3KHN0cnVjdHVyZWQpIHx8IHN0cnVjdHVyZWQuZm9ybWF0dGVkQWRkcmVzcyB8fCBzbWFydEFkZHJlc3NCdWlsZGVyKHN0cnVjdHVyZWQsIFwiXCIpO1xuICByZXR1cm4ge1xuICAgIHN0cmVldDogc3RydWN0dXJlZC5zdHJlZXQgfHwgc3RydWN0dXJlZC5hZGRyZXNzTGluZSB8fCBmb3JtYXR0ZWRBZGRyZXNzIHx8IFwiXCIsXG4gICAgY2l0eTogc3RydWN0dXJlZC5jaXR5IHx8IFwiXCIsXG4gICAgc3RhdGU6IHN0cnVjdHVyZWQuc3RhdGUgfHwgXCJcIixcbiAgICBwb3N0YWxDb2RlOiBzdHJ1Y3R1cmVkLnBvc3RhbENvZGUgfHwgc3RydWN0dXJlZC5waW5jb2RlIHx8IFwiXCIsXG4gICAgY291bnRyeTogc3RydWN0dXJlZC5jb3VudHJ5IHx8IFwiSW5kaWFcIixcbiAgICBsYXQsXG4gICAgbG5nLFxuICAgIHMyQ2VsbElkLFxuICAgIHMyQ2VsbElkUHJlY2lzZSxcbiAgICBhZGRyZXNzTGluZTogc3RydWN0dXJlZC5hZGRyZXNzTGluZSB8fCBzdHJ1Y3R1cmVkLnN0cmVldCB8fCBcIlwiLFxuICAgIGhvdXNlTnVtYmVyOiBzdHJ1Y3R1cmVkLmhvdXNlTnVtYmVyIHx8IFwiXCIsXG4gICAgcm9hZDogc3RydWN0dXJlZC5yb2FkIHx8IFwiXCIsXG4gICAgbGFuZG1hcms6IHN0cnVjdHVyZWQubGFuZG1hcmsgfHwgXCJcIixcbiAgICBhcmVhOiBzdHJ1Y3R1cmVkLmFyZWEgfHwgXCJcIixcbiAgICBwaW5jb2RlOiBzdHJ1Y3R1cmVkLnBpbmNvZGUgfHwgc3RydWN0dXJlZC5wb3N0YWxDb2RlIHx8IFwiXCIsXG4gICAgZm9ybWF0dGVkQWRkcmVzc1xuICB9O1xufTtcblxuZXhwb3J0IGNvbnN0IGZpbHRlckdQU0ppdHRlciA9IChwcmV2LCBuZXh0LCBtaW5NZXRlcnMgPSA4KSA9PiB7XG4gIGlmICghcHJldiB8fCBwcmV2LmxhdCA9PSBudWxsIHx8IHByZXYubG5nID09IG51bGwpIHJldHVybiBuZXh0O1xuICBjb25zdCBSID0gNjM3MTAwMDtcbiAgY29uc3QgZExhdCA9ICgobmV4dC5sYXQgLSBwcmV2LmxhdCkgKiBNYXRoLlBJKSAvIDE4MDtcbiAgY29uc3QgZExuZyA9ICgobmV4dC5sbmcgLSBwcmV2LmxuZykgKiBNYXRoLlBJKSAvIDE4MDtcbiAgY29uc3QgYSA9IE1hdGguc2luKGRMYXQgLyAyKSAqKiAyICsgTWF0aC5jb3MoKHByZXYubGF0ICogTWF0aC5QSSkgLyAxODApICogTWF0aC5jb3MoKG5leHQubGF0ICogTWF0aC5QSSkgLyAxODApICogTWF0aC5zaW4oZExuZyAvIDIpICoqIDI7XG4gIGNvbnN0IGRpc3QgPSBSICogMiAqIE1hdGguYXRhbjIoTWF0aC5zcXJ0KGEpLCBNYXRoLnNxcnQoMSAtIGEpKTtcbiAgcmV0dXJuIGRpc3QgPCBtaW5NZXRlcnMgPyBwcmV2IDogbmV4dDtcbn07XG5cbmV4cG9ydCBjb25zdCBjYWxjdWxhdGVCZWFyaW5nID0gKGxhdDEsIGxvbjEsIGxhdDIsIGxvbjIpID0+IHtcbiAgY29uc3QgZExvbiA9ICgobG9uMiAtIGxvbjEpICogTWF0aC5QSSkgLyAxODA7XG4gIGNvbnN0IGxhdDFSYWQgPSAobGF0MSAqIE1hdGguUEkpIC8gMTgwO1xuICBjb25zdCBsYXQyUmFkID0gKGxhdDIgKiBNYXRoLlBJKSAvIDE4MDtcbiAgY29uc3QgeSA9IE1hdGguc2luKGRMb24pICogTWF0aC5jb3MobGF0MlJhZCk7XG4gIGNvbnN0IHggPSBNYXRoLmNvcyhsYXQxUmFkKSAqIE1hdGguc2luKGxhdDJSYWQpIC0gTWF0aC5zaW4obGF0MVJhZCkgKiBNYXRoLmNvcyhsYXQyUmFkKSAqIE1hdGguY29zKGRMb24pO1xuICByZXR1cm4gKChNYXRoLmF0YW4yKHksIHgpICogMTgwKSAvIE1hdGguUEkgKyAzNjApICUgMzYwO1xufTtcblxuZXhwb3J0IGNvbnN0IGJ1aWxkU3RyZWV0QWRkcmVzcyA9IChob3VzZU51bWJlciwgcm9hZCkgPT4ge1xuICBjb25zdCBob3VzZU51bSA9IChob3VzZU51bWJlciB8fCAnJykudHJpbSgpO1xuICBjb25zdCByZCA9IChyb2FkIHx8ICcnKS50cmltKCk7XG4gIHJldHVybiBob3VzZU51bSAmJiByZCA/IGAke2hvdXNlTnVtfSwgJHtyZH1gIDogKGhvdXNlTnVtIHx8IHJkKTtcbn07XG5cbmNvbnN0IEJBTktfTkFNRVMgPSB7XG4gIFBVTkI6ICdQdW5qYWIgTmF0aW9uYWwgQmFuaycsXG4gIEhERkM6ICdIREZDIEJhbmsnLFxuICBTQklOOiAnU3RhdGUgQmFuayBvZiBJbmRpYScsXG4gIElDSUM6ICdJQ0lDSSBCYW5rJyxcbiAgVVRJQjogJ0F4aXMgQmFuaycsXG4gIEFYSVM6ICdBeGlzIEJhbmsnLFxuICBLS0JLOiAnS290YWsgTWFoaW5kcmEgQmFuaycsXG4gIEJBUkI6ICdCYW5rIG9mIEJhcm9kYScsXG4gIENOUkI6ICdDYW5hcmEgQmFuaycsXG4gIFVCSU46ICdVbmlvbiBCYW5rIG9mIEluZGlhJyxcbiAgSURJQjogJ0luZGlhbiBCYW5rJyxcbiAgQktJRDogJ0Jhbmsgb2YgSW5kaWEnLFxuICBJT0JBOiAnSW5kaWFuIE92ZXJzZWFzIEJhbmsnLFxuICBNQUhCOiAnQmFuayBvZiBNYWhhcmFzaHRyYScsXG4gIFBTSUI6ICdQdW5qYWIgJiBTaW5kIEJhbmsnLFxuICBVQ09COiAnVUNPIEJhbmsnLFxuICBDVUI6ICdDaXR5IFVuaW9uIEJhbmsnLFxuICBDU0I6ICdDU0IgQmFuaycsXG4gIERDQjogJ0RDQiBCYW5rJyxcbiAgRExYQjogJ0RoYW5sYXhtaSBCYW5rJyxcbiAgRkRSTDogJ0ZlZGVyYWwgQmFuaycsXG4gIElERkI6ICdJREZDIEZpcnN0IEJhbmsnLFxuICBJTkRCOiAnSW5kdXNJbmQgQmFuaycsXG4gIElORFVTOiAnSW5kdXNJbmQgQmFuaycsXG4gIEpBS0E6ICdKYW1tdSAmIEthc2htaXIgQmFuaycsXG4gIEtBUkI6ICdLYXJuYXRha2EgQmFuaycsXG4gIEtWQkw6ICdLYXJ1ciBWeXN5YSBCYW5rJyxcbiAgS1ZCOiAnS2FydXIgVnlzeWEgQmFuaycsXG4gIE5BSU46ICdOYWluaXRhbCBCYW5rJyxcbiAgUkJMOiAnUkJMIEJhbmsnLFxuICBTSUJMOiAnU291dGggSW5kaWFuIEJhbmsnLFxuICBUTUJMOiAnVGFtaWxuYWQgTWVyY2FudGlsZSBCYW5rJyxcbiAgWUVTQjogJ1lFUyBCYW5rJyxcbiAgQkRCTDogJ0JhbmRoYW4gQmFuaycsXG4gIEFVQkw6ICdBVSBTbWFsbCBGaW5hbmNlIEJhbmsnLFxuICBFU0ZCOiAnRXF1aXRhcyBTbWFsbCBGaW5hbmNlIEJhbmsnLFxuICBVU0ZCOiAnVWpqaXZhbiBTbWFsbCBGaW5hbmNlIEJhbmsnLFxuICBBSVJQOiAnQWlydGVsIFBheW1lbnRzIEJhbmsnLFxuICBJUFBCOiAnSW5kaWEgUG9zdCBQYXltZW50cyBCYW5rJyxcbiAgUFlUTTogJ1BheXRtIFBheW1lbnRzIEJhbmsnLFxufTtcblxuZXhwb3J0IGNvbnN0IGZvcm1hdEJhbmtOYW1lID0gKGNvZGUpID0+IHtcbiAgaWYgKCFjb2RlKSByZXR1cm4gJ04vQSc7XG4gIGNvbnN0IGNsZWFuQ29kZSA9IFN0cmluZyhjb2RlKS50cmltKCkudG9VcHBlckNhc2UoKTtcbiAgY29uc3QgYmFzZUNvZGUgPSBjbGVhbkNvZGUucmVwbGFjZSgvX1tBLVowLTldKyQvLCAnJyk7XG4gIGNvbnN0IGJhbmtOYW1lID0gQkFOS19OQU1FU1tjbGVhbkNvZGVdIHx8IEJBTktfTkFNRVNbYmFzZUNvZGVdO1xuICBpZiAoYmFua05hbWUpIHtcbiAgICByZXR1cm4gYCR7YmFua05hbWV9ICgke2NsZWFuQ29kZX0pYDtcbiAgfVxuICByZXR1cm4gY2xlYW5Db2RlO1xufTtcbiJdLCJmaWxlIjoiQzovUHJvamVjdC9TZXJ2aWNlL2NsaWVudC9zcmMvdXRpbHMvZm9ybWF0LmpzeCJ9
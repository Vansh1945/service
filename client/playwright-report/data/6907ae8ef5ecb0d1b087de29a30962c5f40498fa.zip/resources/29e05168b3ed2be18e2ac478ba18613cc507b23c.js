import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/customer/services/components/ServiceCard.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_BACKEND_URL": "http://localhost:5000/api", "VITE_FIREBASE_API_KEY": "AIzaSyBa4POZSvx62cqq8Mdc8rIBhjIGreNJ-GA", "VITE_FIREBASE_APP_ID": "1:710160850410:web:2e5a539d56b3e12025a693", "VITE_FIREBASE_AUTH_DOMAIN": "raj-electrical.firebaseapp.com", "VITE_FIREBASE_MEASUREMENT_ID": "G-DMD24Q474W", "VITE_FIREBASE_MESSAGING_SENDER_ID": "710160850410", "VITE_FIREBASE_PROJECT_ID": "raj-electrical", "VITE_FIREBASE_STORAGE_BUCKET": "raj-electrical.firebasestorage.app", "VITE_FIREBASE_VAPID_KEY": "BM1f0TxUwEjEdxMP6m7O87NW2gH365y3r85EabX_sp7uWtZE26jORH8Udlt_Kf6ermGuNTlemkrJ6fa_IzXx5dE", "VITE_GA_ID": "G-DMD24Q474W", "VITE_GTM_ID": "GTM-K2LPNDN6", "VITE_RAZORPAY_KEY_ID": "rzp_test_I0DD5odIErkEDP", "VITE_SENTRY_DSN": "https://aaaef72d2ba5669552d7871269c5cdc9@o4512015420948480.ingest.de.sentry.io/4512015425208400"};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=38a573e6"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=38a573e6"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Clock, Star } from "/node_modules/.vite/deps/lucide-react.js?v=38a573e6";
const ServiceCard = ({ service, categoryMap, onBook, getMergedPrice }) => {
  const backendUrl = import.meta.env.VITE_BACKEND_URL ? import.meta.env.VITE_BACKEND_URL.replace("/api", "") : window.location.origin;
  const defaultServiceImage = `${backendUrl}/assets/Service.png`;
  const imageUrl = service.displayImage || service.images?.[0] || service.image || defaultServiceImage;
  const isAvailable = service.isActive !== false;
  const categoryName = typeof service.category === "object" ? service.category?.name : categoryMap[service.category] || "Service";
  const displayRating = service.averageRating ? service.averageRating.toFixed(1) : "0.0";
  const displayRatingCount = service.ratingCount || 0;
  return /* @__PURE__ */ jsxDEV("div", { className: "group bg-white rounded-2xl border border-gray-150 hover:shadow-md transition-shadow duration-200 overflow-hidden flex flex-col justify-between h-full", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-32 overflow-hidden bg-gray-50", children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: imageUrl,
            alt: service.title || "Electrical Service",
            loading: "lazy",
            decoding: "async",
            width: 300,
            height: 128,
            className: "w-full h-full object-cover",
            onError: (e) => e.target.src = defaultServiceImage
          },
          void 0,
          false,
          {
            fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
            lineNumber: 44,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-2 left-2 flex flex-col gap-1 z-10", children: [
          service.isFeatured && /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] font-black bg-amber-50/90 text-amber-700 backdrop-blur-sm px-1.5 py-0.5 rounded-md shadow-sm border border-amber-100", children: "★ Featured" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
            lineNumber: 57,
            columnNumber: 13
          }, this),
          service.serviceType && service.serviceType !== "standard" && /* @__PURE__ */ jsxDEV("span", { className: `text-[9px] font-black px-1.5 py-0.5 rounded-md uppercase shadow-sm tracking-wider text-white ${service.serviceType === "emergency" ? "bg-red-500" : "bg-purple-600"}`, children: service.serviceType }, void 0, false, {
            fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
            lineNumber: 62,
            columnNumber: 13
          }, this),
          !service.isFeatured && service.averageRating >= 4.5 && /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] font-black bg-emerald-50/90 text-emerald-700 backdrop-blur-sm px-1.5 py-0.5 rounded-md shadow-sm border border-emerald-100", children: "★ Popular" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
            lineNumber: 68,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 55,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-2 left-2 z-10", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] font-extrabold bg-white/95 backdrop-blur-sm text-teal-700 px-2 py-0.5 rounded-lg shadow-md border border-teal-50", children: categoryName }, void 0, false, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 75,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 74,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-extrabold text-secondary text-sm line-clamp-1 mb-1 group-hover:text-primary transition-colors", children: service.title }, void 0, false, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 83,
          columnNumber: 11
        }, this),
        service.shortDescription && /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs line-clamp-2 mb-2 leading-relaxed", children: service.shortDescription }, void 0, false, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 88,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1 text-xs text-gray-500 font-medium", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(Clock, { className: "w-3.5 h-3.5 text-gray-400 flex-shrink-0" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
              lineNumber: 96,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: [
              service.duration || 1,
              " Hr"
            ] }, void 0, true, {
              fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
              lineNumber: 97,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-gray-50 px-1.5 py-0.5 rounded-lg border border-gray-100", children: [
            /* @__PURE__ */ jsxDEV(Star, { className: "w-3.5 h-3.5 text-amber-500 fill-amber-500 flex-shrink-0" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
              lineNumber: 100,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-secondary", children: displayRating }, void 0, false, {
              fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
              lineNumber: 101,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-400", children: [
              "(",
              displayRatingCount,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
              lineNumber: 102,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
            lineNumber: 99,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 94,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
        lineNumber: 82,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-3 pt-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-2 border-t border-gray-100", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-shrink-0", children: service.discountPrice ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-extrabold text-emerald-600 whitespace-nowrap", children: [
          "₹",
          getMergedPrice ? getMergedPrice(service.discountPrice)?.toLocaleString() : service.discountPrice?.toLocaleString()
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 114,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] line-through text-gray-400 font-normal whitespace-nowrap", children: [
          "₹",
          getMergedPrice ? getMergedPrice(service.basePrice)?.toLocaleString() : service.basePrice?.toLocaleString()
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 117,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
        lineNumber: 113,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-extrabold text-emerald-600 whitespace-nowrap", children: [
        "₹",
        getMergedPrice ? getMergedPrice(service.basePrice)?.toLocaleString() : service.basePrice?.toLocaleString()
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
        lineNumber: 122,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
        lineNumber: 111,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onBook(service._id, isAvailable),
          disabled: !isAvailable,
          className: `px-3 py-1.5 rounded-xl text-xs font-bold tracking-wide transition-all active:scale-95 whitespace-nowrap ${isAvailable ? "bg-primary text-white hover:bg-primary/95 shadow-sm shadow-primary/10" : "bg-gray-150 text-gray-400 cursor-not-allowed"}`,
          children: "Book Now"
        },
        void 0,
        false,
        {
          fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
          lineNumber: 127,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
      lineNumber: 110,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
};
_c = ServiceCard;
export default ServiceCard;
var _c;
$RefreshReg$(_c, "ServiceCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Project/Service/client/src/features/customer/services/components/ServiceCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JVLFNBcUVJLFVBckVKOzs7Ozs7Ozs7Ozs7Ozs7O0FBeEJWLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsT0FBT0MsWUFBWTtBQUU1QixNQUFNQyxjQUFjQSxDQUFDLEVBQUVDLFNBQVNDLGFBQWFDLFFBQVFDLGVBQWUsTUFBTTtBQUN4RSxRQUFNQyxhQUFhQyxZQUFZQyxJQUFJQyxtQkFDL0JGLFlBQVlDLElBQUlDLGlCQUFpQkMsUUFBUSxRQUFRLEVBQUUsSUFDbkRDLE9BQU9DLFNBQVNDO0FBQ3BCLFFBQU1DLHNCQUFzQixHQUFHUixVQUFVO0FBRXpDLFFBQU1TLFdBQVdiLFFBQVFjLGdCQUFnQmQsUUFBUWUsU0FBUyxDQUFDLEtBQUtmLFFBQVFnQixTQUFTSjtBQUNqRixRQUFNSyxjQUFjakIsUUFBUWtCLGFBQWE7QUFDekMsUUFBTUMsZUFBZSxPQUFPbkIsUUFBUW9CLGFBQWEsV0FDN0NwQixRQUFRb0IsVUFBVUMsT0FDbEJwQixZQUFZRCxRQUFRb0IsUUFBUSxLQUFLO0FBRXJDLFFBQU1FLGdCQUFnQnRCLFFBQVF1QixnQkFBZ0J2QixRQUFRdUIsY0FBY0MsUUFBUSxDQUFDLElBQUk7QUFDakYsUUFBTUMscUJBQXFCekIsUUFBUTBCLGVBQWU7QUFHbEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUseUpBQ2I7QUFBQSwyQkFBQyxTQUVDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEtBQUtiO0FBQUFBLFlBQ0wsS0FBS2IsUUFBUTJCLFNBQVM7QUFBQSxZQUN0QixTQUFRO0FBQUEsWUFDUixVQUFTO0FBQUEsWUFDVCxPQUFPO0FBQUEsWUFDUCxRQUFRO0FBQUEsWUFDUixXQUFVO0FBQUEsWUFDVixTQUFTLENBQUNDLE1BQU1BLEVBQUVDLE9BQU9DLE1BQU1sQjtBQUFBQTtBQUFBQSxVQVJqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRcUQ7QUFBQSxRQUdyRCx1QkFBQyxTQUFJLFdBQVUsa0RBQ1paO0FBQUFBLGtCQUFRK0IsY0FDUCx1QkFBQyxVQUFLLFdBQVUsbUlBQWlJLDBCQUFqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFRC9CLFFBQVFnQyxlQUFlaEMsUUFBUWdDLGdCQUFnQixjQUM5Qyx1QkFBQyxVQUFLLFdBQVcsZ0dBQWdHaEMsUUFBUWdDLGdCQUFnQixjQUFjLGVBQWUsZUFBZSxJQUVsTGhDLGtCQUFRZ0MsZUFGWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFRCxDQUFDaEMsUUFBUStCLGNBQWMvQixRQUFRdUIsaUJBQWlCLE9BQy9DLHVCQUFDLFVBQUssV0FBVSx5SUFBdUkseUJBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYixpQ0FBQyxVQUFLLFdBQVUsK0hBQ2JKLDBCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNHQUNYbkIsa0JBQVEyQixTQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUMzQixRQUFRaUMsb0JBQ1AsdUJBQUMsT0FBRSxXQUFVLDJEQUNWakMsa0JBQVFpQyxvQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQU0sV0FBVSw2Q0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxVQUFNakM7QUFBQUEsc0JBQVFrQyxZQUFZO0FBQUEsY0FBRTtBQUFBLGlCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBLG1DQUFDLFFBQUssV0FBVSw2REFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxVQUFLLFdBQVUsb0NBQW9DWiwyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSxjQUFFRztBQUFBQSxjQUFtQjtBQUFBLGlCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLGVBSHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxTQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsWUFDYixpQ0FBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQ1p6QixrQkFBUW1DLGdCQUNQLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDZEQUEyRDtBQUFBO0FBQUEsVUFDdkVoQyxpQkFBaUJBLGVBQWVILFFBQVFtQyxhQUFhLEdBQUdDLGVBQWUsSUFBSXBDLFFBQVFtQyxlQUFlQyxlQUFlO0FBQUEsYUFEckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsd0VBQXNFO0FBQUE7QUFBQSxVQUNsRmpDLGlCQUFpQkEsZUFBZUgsUUFBUXFDLFNBQVMsR0FBR0QsZUFBZSxJQUFJcEMsUUFBUXFDLFdBQVdELGVBQWU7QUFBQSxhQUQ3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxJQUVBLHVCQUFDLFVBQUssV0FBVSw2REFBMkQ7QUFBQTtBQUFBLFFBQ3ZFakMsaUJBQWlCQSxlQUFlSCxRQUFRcUMsU0FBUyxHQUFHRCxlQUFlLElBQUlwQyxRQUFRcUMsV0FBV0QsZUFBZTtBQUFBLFdBRDdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTWxDLE9BQU9GLFFBQVFzQyxLQUFLckIsV0FBVztBQUFBLFVBQzlDLFVBQVUsQ0FBQ0E7QUFBQUEsVUFDWCxXQUFXLDJHQUEyR0EsY0FDbEgsMEVBQ0EsOENBQThDO0FBQUEsVUFDN0M7QUFBQTtBQUFBLFFBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0E7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxPQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUdBO0FBRUo7QUFBRXNCLEtBdEhJeEM7QUF3SE4sZUFBZUE7QUFBWSxJQUFBd0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJDbG9jayIsIlN0YXIiLCJTZXJ2aWNlQ2FyZCIsInNlcnZpY2UiLCJjYXRlZ29yeU1hcCIsIm9uQm9vayIsImdldE1lcmdlZFByaWNlIiwiYmFja2VuZFVybCIsImltcG9ydCIsImVudiIsIlZJVEVfQkFDS0VORF9VUkwiLCJyZXBsYWNlIiwid2luZG93IiwibG9jYXRpb24iLCJvcmlnaW4iLCJkZWZhdWx0U2VydmljZUltYWdlIiwiaW1hZ2VVcmwiLCJkaXNwbGF5SW1hZ2UiLCJpbWFnZXMiLCJpbWFnZSIsImlzQXZhaWxhYmxlIiwiaXNBY3RpdmUiLCJjYXRlZ29yeU5hbWUiLCJjYXRlZ29yeSIsIm5hbWUiLCJkaXNwbGF5UmF0aW5nIiwiYXZlcmFnZVJhdGluZyIsInRvRml4ZWQiLCJkaXNwbGF5UmF0aW5nQ291bnQiLCJyYXRpbmdDb3VudCIsInRpdGxlIiwiZSIsInRhcmdldCIsInNyYyIsImlzRmVhdHVyZWQiLCJzZXJ2aWNlVHlwZSIsInNob3J0RGVzY3JpcHRpb24iLCJkdXJhdGlvbiIsImRpc2NvdW50UHJpY2UiLCJ0b0xvY2FsZVN0cmluZyIsImJhc2VQcmljZSIsIl9pZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VDYXJkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ2xvY2ssIFN0YXIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5jb25zdCBTZXJ2aWNlQ2FyZCA9ICh7IHNlcnZpY2UsIGNhdGVnb3J5TWFwLCBvbkJvb2ssIGdldE1lcmdlZFByaWNlIH0pID0+IHtcbiAgY29uc3QgYmFja2VuZFVybCA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0JBQ0tFTkRfVVJMXG4gICAgPyBpbXBvcnQubWV0YS5lbnYuVklURV9CQUNLRU5EX1VSTC5yZXBsYWNlKCcvYXBpJywgJycpXG4gICAgOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luO1xuICBjb25zdCBkZWZhdWx0U2VydmljZUltYWdlID0gYCR7YmFja2VuZFVybH0vYXNzZXRzL1NlcnZpY2UucG5nYDtcblxuICBjb25zdCBpbWFnZVVybCA9IHNlcnZpY2UuZGlzcGxheUltYWdlIHx8IHNlcnZpY2UuaW1hZ2VzPy5bMF0gfHwgc2VydmljZS5pbWFnZSB8fCBkZWZhdWx0U2VydmljZUltYWdlO1xuICBjb25zdCBpc0F2YWlsYWJsZSA9IHNlcnZpY2UuaXNBY3RpdmUgIT09IGZhbHNlO1xuICBjb25zdCBjYXRlZ29yeU5hbWUgPSB0eXBlb2Ygc2VydmljZS5jYXRlZ29yeSA9PT0gJ29iamVjdCdcbiAgICA/IHNlcnZpY2UuY2F0ZWdvcnk/Lm5hbWVcbiAgICA6IGNhdGVnb3J5TWFwW3NlcnZpY2UuY2F0ZWdvcnldIHx8ICdTZXJ2aWNlJztcblxuICBjb25zdCBkaXNwbGF5UmF0aW5nID0gc2VydmljZS5hdmVyYWdlUmF0aW5nID8gc2VydmljZS5hdmVyYWdlUmF0aW5nLnRvRml4ZWQoMSkgOiAnMC4wJztcbiAgY29uc3QgZGlzcGxheVJhdGluZ0NvdW50ID0gc2VydmljZS5yYXRpbmdDb3VudCB8fCAwO1xuXG4gIC8vIEdyaWQgVmlldyBDYXJkXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncm91cCBiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMTUwIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvdyBkdXJhdGlvbi0yMDAgb3ZlcmZsb3ctaGlkZGVuIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGgtZnVsbFwiPlxuICAgICAgPGRpdj5cbiAgICAgICAgey8qIEltYWdlIENvbnRhaW5lciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTMyIG92ZXJmbG93LWhpZGRlbiBiZy1ncmF5LTUwXCI+XG4gICAgICAgICAgPGltZ1xuICAgICAgICAgICAgc3JjPXtpbWFnZVVybH1cbiAgICAgICAgICAgIGFsdD17c2VydmljZS50aXRsZSB8fCBcIkVsZWN0cmljYWwgU2VydmljZVwifVxuICAgICAgICAgICAgbG9hZGluZz1cImxhenlcIlxuICAgICAgICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXG4gICAgICAgICAgICB3aWR0aD17MzAwfVxuICAgICAgICAgICAgaGVpZ2h0PXsxMjh9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4gZS50YXJnZXQuc3JjID0gZGVmYXVsdFNlcnZpY2VJbWFnZX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIHsvKiBUb3AtTGVmdCBCYWRnZXMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiBsZWZ0LTIgZmxleCBmbGV4LWNvbCBnYXAtMSB6LTEwXCI+XG4gICAgICAgICAgICB7c2VydmljZS5pc0ZlYXR1cmVkICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJsYWNrIGJnLWFtYmVyLTUwLzkwIHRleHQtYW1iZXItNzAwIGJhY2tkcm9wLWJsdXItc20gcHgtMS41IHB5LTAuNSByb3VuZGVkLW1kIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWFtYmVyLTEwMFwiPlxuICAgICAgICAgICAgICAgIOKYhSBGZWF0dXJlZFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3NlcnZpY2Uuc2VydmljZVR5cGUgJiYgc2VydmljZS5zZXJ2aWNlVHlwZSAhPT0gJ3N0YW5kYXJkJyAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzlweF0gZm9udC1ibGFjayBweC0xLjUgcHktMC41IHJvdW5kZWQtbWQgdXBwZXJjYXNlIHNoYWRvdy1zbSB0cmFja2luZy13aWRlciB0ZXh0LXdoaXRlICR7c2VydmljZS5zZXJ2aWNlVHlwZSA9PT0gJ2VtZXJnZW5jeScgPyAnYmctcmVkLTUwMCcgOiAnYmctcHVycGxlLTYwMCdcbiAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAge3NlcnZpY2Uuc2VydmljZVR5cGV9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7IXNlcnZpY2UuaXNGZWF0dXJlZCAmJiBzZXJ2aWNlLmF2ZXJhZ2VSYXRpbmcgPj0gNC41ICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJsYWNrIGJnLWVtZXJhbGQtNTAvOTAgdGV4dC1lbWVyYWxkLTcwMCBiYWNrZHJvcC1ibHVyLXNtIHB4LTEuNSBweS0wLjUgcm91bmRlZC1tZCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1lbWVyYWxkLTEwMFwiPlxuICAgICAgICAgICAgICAgIOKYhSBQb3B1bGFyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgey8qIEJvdHRvbS1MZWZ0IENhdGVnb3J5IFRhZyBPdmVybGF5ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTIgbGVmdC0yIHotMTBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1leHRyYWJvbGQgYmctd2hpdGUvOTUgYmFja2Ryb3AtYmx1ci1zbSB0ZXh0LXRlYWwtNzAwIHB4LTIgcHktMC41IHJvdW5kZWQtbGcgc2hhZG93LW1kIGJvcmRlciBib3JkZXItdGVhbC01MFwiPlxuICAgICAgICAgICAgICB7Y2F0ZWdvcnlOYW1lfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRGV0YWlscyBDb250YWluZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc2Vjb25kYXJ5IHRleHQtc20gbGluZS1jbGFtcC0xIG1iLTEgZ3JvdXAtaG92ZXI6dGV4dC1wcmltYXJ5IHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICB7c2VydmljZS50aXRsZX1cbiAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAge3NlcnZpY2Uuc2hvcnREZXNjcmlwdGlvbiAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHMgbGluZS1jbGFtcC0yIG1iLTIgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIHtzZXJ2aWNlLnNob3J0RGVzY3JpcHRpb259XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBJY29ucyAmIFJhdGluZyBSb3cgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPntzZXJ2aWNlLmR1cmF0aW9uIHx8IDF9IEhyPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLWdyYXktNTAgcHgtMS41IHB5LTAuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDBcIj5cbiAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci01MDAgZmlsbC1hbWJlci01MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCI+e2Rpc3BsYXlSYXRpbmd9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNDAwXCI+KHtkaXNwbGF5UmF0aW5nQ291bnR9KTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRm9vdGVyIC8gUHJpY2UgJiBCdXR0b24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBwdC0wXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIHtzZXJ2aWNlLmRpc2NvdW50UHJpY2UgPyAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWV4dHJhYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICDigrl7Z2V0TWVyZ2VkUHJpY2UgPyBnZXRNZXJnZWRQcmljZShzZXJ2aWNlLmRpc2NvdW50UHJpY2UpPy50b0xvY2FsZVN0cmluZygpIDogc2VydmljZS5kaXNjb3VudFByaWNlPy50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBsaW5lLXRocm91Z2ggdGV4dC1ncmF5LTQwMCBmb250LW5vcm1hbCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAg4oK5e2dldE1lcmdlZFByaWNlID8gZ2V0TWVyZ2VkUHJpY2Uoc2VydmljZS5iYXNlUHJpY2UpPy50b0xvY2FsZVN0cmluZygpIDogc2VydmljZS5iYXNlUHJpY2U/LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1lbWVyYWxkLTYwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgIOKCuXtnZXRNZXJnZWRQcmljZSA/IGdldE1lcmdlZFByaWNlKHNlcnZpY2UuYmFzZVByaWNlKT8udG9Mb2NhbGVTdHJpbmcoKSA6IHNlcnZpY2UuYmFzZVByaWNlPy50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQm9vayhzZXJ2aWNlLl9pZCwgaXNBdmFpbGFibGUpfVxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc0F2YWlsYWJsZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhY2tpbmctd2lkZSB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTUgd2hpdGVzcGFjZS1ub3dyYXAgJHtpc0F2YWlsYWJsZVxuICAgICAgICAgICAgICA/ICdiZy1wcmltYXJ5IHRleHQtd2hpdGUgaG92ZXI6YmctcHJpbWFyeS85NSBzaGFkb3ctc20gc2hhZG93LXByaW1hcnkvMTAnXG4gICAgICAgICAgICAgIDogJ2JnLWdyYXktMTUwIHRleHQtZ3JheS00MDAgY3Vyc29yLW5vdC1hbGxvd2VkJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBCb29rIE5vd1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU2VydmljZUNhcmQ7XG4iXSwiZmlsZSI6IkM6L1Byb2plY3QvU2VydmljZS9jbGllbnQvc3JjL2ZlYXR1cmVzL2N1c3RvbWVyL3NlcnZpY2VzL2NvbXBvbmVudHMvU2VydmljZUNhcmQuanN4In0=
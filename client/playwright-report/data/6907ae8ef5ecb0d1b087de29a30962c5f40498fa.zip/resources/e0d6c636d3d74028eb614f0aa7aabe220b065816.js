import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui-skeletons/ServiceCardSkeleton.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=38a573e6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=38a573e6"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
const ServiceCardSkeleton = () => {
  return /* @__PURE__ */ jsxDEV("div", { className: "animate-pulse bg-white rounded-xl border border-gray-100 overflow-hidden flex flex-col h-full ring-1 ring-gray-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative h-36 md:h-44 bg-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "absolute top-2 left-2 w-16 h-5 bg-gray-300 rounded-lg" }, void 0, false, {
      fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
      lineNumber: 27,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-3 md:p-4 flex flex-col flex-grow space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow space-y-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "h-4 bg-gray-200 rounded w-3/4" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
          lineNumber: 34,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "h-3 bg-gray-200 rounded w-full" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
            lineNumber: 37,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "h-3 bg-gray-200 rounded w-5/6" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
            lineNumber: 38,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
          lineNumber: 36,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1 pt-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-3.5 bg-gray-200 rounded" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
          lineNumber: 44,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-3.5 bg-gray-200 rounded" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
          lineNumber: 45,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-3 border-t border-gray-100 mt-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-5 bg-gray-200 rounded" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
          lineNumber: 50,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-7 bg-gray-200 rounded-lg" }, void 0, false, {
          fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx",
    lineNumber: 24,
    columnNumber: 5
  }, this);
};
_c = ServiceCardSkeleton;
export default ServiceCardSkeleton;
var _c;
$RefreshReg$(_c, "ServiceCardSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Project/Service/client/src/components/ui-skeletons/ServiceCardSkeleton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFQUixPQUFPQSxXQUFXO0FBRWxCLE1BQU1DLHNCQUFzQkEsTUFBTTtBQUNoQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxzSEFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxxQ0FDYixpQ0FBQyxTQUFJLFdBQVUsMkRBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RSxLQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx1QkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFFL0MsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxTQUFJLFdBQVUsbUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxhQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxRQUNoRCx1QkFBQyxTQUFJLFdBQVUsb0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFdBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxTQUFJLFdBQVUscUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFdBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxPQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBO0FBRUo7QUFBRUMsS0FsQ0lEO0FBb0NOLGVBQWVBO0FBQW9CLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU2VydmljZUNhcmRTa2VsZXRvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VDYXJkU2tlbGV0b24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmNvbnN0IFNlcnZpY2VDYXJkU2tlbGV0b24gPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXB1bHNlIGJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBoLWZ1bGwgcmluZy0xIHJpbmctZ3JheS0xMDBcIj5cbiAgICAgIHsvKiBJbWFnZSBBcmVhICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTM2IG1kOmgtNDQgYmctZ3JheS0yMDBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiBsZWZ0LTIgdy0xNiBoLTUgYmctZ3JheS0zMDAgcm91bmRlZC1sZ1wiPjwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBJbmZvIEFyZWEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBtZDpwLTQgZmxleCBmbGV4LWNvbCBmbGV4LWdyb3cgc3BhY2UteS0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHNwYWNlLXktMlwiPlxuICAgICAgICAgIHsvKiBUaXRsZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNCBiZy1ncmF5LTIwMCByb3VuZGVkIHctMy80XCI+PC9kaXY+XG4gICAgICAgICAgey8qIERlc2NyaXB0aW9uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zIGJnLWdyYXktMjAwIHJvdW5kZWQgdy1mdWxsXCI+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMyBiZy1ncmF5LTIwMCByb3VuZGVkIHctNS82XCI+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXRyaWNzIChEdXJhdGlvbiAvIFJhdGluZykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTEgcHQtMVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTMuNSBiZy1ncmF5LTIwMCByb3VuZGVkXCI+PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIwIGgtMy41IGJnLWdyYXktMjAwIHJvdW5kZWRcIj48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFByaWNpbmcgJiBCb29raW5nIEJ1dHRvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgbXQtYXV0b1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTUgYmctZ3JheS0yMDAgcm91bmRlZFwiPjwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTcgYmctZ3JheS0yMDAgcm91bmRlZC1sZ1wiPjwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU2VydmljZUNhcmRTa2VsZXRvbjtcbiJdLCJmaWxlIjoiQzovUHJvamVjdC9TZXJ2aWNlL2NsaWVudC9zcmMvY29tcG9uZW50cy91aS1za2VsZXRvbnMvU2VydmljZUNhcmRTa2VsZXRvbi5qc3gifQ==
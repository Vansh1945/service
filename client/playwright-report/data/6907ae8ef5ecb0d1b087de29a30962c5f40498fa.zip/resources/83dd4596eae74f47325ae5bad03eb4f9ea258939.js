import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HeroSection.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=38a573e6"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Project/Service/client/src/components/HeroSection.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=38a573e6"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Swiper, SwiperSlide } from "/node_modules/.vite/deps/swiper_react.js?v=38a573e6";
import { Autoplay, Pagination } from "/node_modules/.vite/deps/swiper_modules.js?v=38a573e6";
import { useAuth } from "/src/context/auth.jsx";
import "/node_modules/swiper/swiper.css";
import "/node_modules/swiper/modules/pagination.css";
import ServiceImg from "/src/assets/ServiceImg.webp?import";
import LoadingSpinner from "/src/components/ui/Loader.jsx";
import { getBanners } from "/src/services/SystemService.js";
const HeroSection = ({ noMargin = false }) => {
  _s();
  const { API } = useAuth();
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);
  const defaultBanner = {
    image: ServiceImg,
    title: "Power Your Home & Business with Reliable Electrical Services",
    subtitle: "Expert wiring, repair, and maintenance for homes & industries across North India.",
    isDefault: true
  };
  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const res = await getBanners();
        const data = res?.data?.data || [];
        const today = /* @__PURE__ */ new Date();
        const activeBanners = data.filter((b) => {
          if (!b.startDate || !b.endDate) return true;
          return today >= new Date(b.startDate) && today <= new Date(b.endDate);
        });
        const uniqueBanners = [];
        const seen = /* @__PURE__ */ new Set();
        for (const banner of activeBanners) {
          const key = banner._id || banner.image;
          if (!seen.has(key)) {
            seen.add(key);
            uniqueBanners.push(banner);
          }
        }
        let finalBanners = uniqueBanners.length > 0 ? uniqueBanners : [defaultBanner];
        if (finalBanners.length > 1 && finalBanners.length < 4) {
          finalBanners = [...finalBanners, ...finalBanners, ...finalBanners].slice(0, 6);
        }
        setBanners(finalBanners);
      } catch (error) {
        console.error(error);
        console.error(error);
        setBanners([defaultBanner]);
      } finally {
        setLoading(false);
      }
    };
    fetchBanners();
  }, [API]);
  if (loading) {
    return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
      lineNumber: 93,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("section", { className: `max-w-7xl mx-auto overflow-hidden px-4 sm:px-6 lg:px-8 pb-2 md:pb-3 relative ${noMargin ? "pt-0 md:pt-0" : "pt-4 md:pt-6 mt-16 md:mt-18 lg:mt-20"}`, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative w-full group", children: /* @__PURE__ */ jsxDEV(
      Swiper,
      {
        modules: [Autoplay, Pagination],
        autoplay: { delay: 4e3, disableOnInteraction: false },
        loop: banners.length > 1,
        spaceBetween: 20,
        pagination: { clickable: true },
        breakpoints: {
          320: { slidesPerView: 1.1 },
          640: { slidesPerView: 1.5 },
          768: { slidesPerView: 2 },
          1024: { slidesPerView: 3 }
        },
        className: "w-full pb-6",
        children: banners.map((banner, index) => {
          const isDefault = banner.isDefault;
          return /* @__PURE__ */ jsxDEV(SwiperSlide, { children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full h-[140px] sm:h-[180px] md:h-[220px] rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: banner.image,
                alt: banner.title || "Raj Electrical Service Banner",
                loading: index === 0 ? "eager" : "lazy",
                decoding: "async",
                width: 800,
                height: 450,
                className: "w-full h-full object-cover"
              },
              void 0,
              false,
              {
                fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
                lineNumber: 120,
                columnNumber: 19
              },
              this
            ),
            isDefault && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" }, void 0, false, {
                fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
                lineNumber: 133,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-full p-4 z-10", children: [
                banner.title && /* @__PURE__ */ jsxDEV("h3", { className: "text-sm sm:text-base md:text-lg font-bold text-white font-poppins line-clamp-1", children: banner.title }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
                  lineNumber: 136,
                  columnNumber: 23
                }, this),
                banner.subtitle && /* @__PURE__ */ jsxDEV("p", { className: "text-xxs sm:text-xs md:text-sm text-gray-300 font-poppins line-clamp-2 mt-1", children: banner.subtitle }, void 0, false, {
                  fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
                  lineNumber: 141,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
                lineNumber: 134,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
              lineNumber: 132,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
            lineNumber: 118,
            columnNumber: 17
          }, this) }, banner._id ? `${banner._id}-${index}` : `${banner.image}-${index}`, false, {
            fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
            lineNumber: 117,
            columnNumber: 15
          }, this);
        })
      },
      void 0,
      false,
      {
        fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
        lineNumber: 99,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
      lineNumber: 98,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { children: `
        .swiper-pagination-bullet {
          background: #d1d5db !important;
          opacity: 1 !important;
          width: 8px !important;
          height: 8px !important;
          transition: all 0.3s ease;
        }
        .swiper-pagination-bullet-active {
          background: #FF5E00 !important; /* warm brown matching brand */
          width: 24px !important;
          border-radius: 4px !important;
        }
      ` }, void 0, false, {
      fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
      lineNumber: 156,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Project/Service/client/src/components/HeroSection.jsx",
    lineNumber: 97,
    columnNumber: 5
  }, this);
};
_s(HeroSection, "0a1WxZPuKNAeVTN0iW5t58SHTBc=", false, function() {
  return [useAuth];
});
_c = HeroSection;
export default HeroSection;
var _c;
$RefreshReg$(_c, "HeroSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Project/Service/client/src/components/HeroSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Project/Service/client/src/components/HeroSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVXLFNBdUNTLFVBdkNUOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpFWCxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsUUFBUUMsbUJBQW1CO0FBQ3BDLFNBQVNDLFVBQVVDLGtCQUFrQjtBQUNyQyxTQUFTQyxlQUFlO0FBRXhCLE9BQU87QUFDUCxPQUFPO0FBRVAsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsY0FBY0EsQ0FBQyxFQUFFQyxXQUFXLE1BQU0sTUFBTTtBQUFBQyxLQUFBO0FBQzVDLFFBQU0sRUFBRUMsSUFBSSxJQUFJUCxRQUFRO0FBQ3hCLFFBQU0sQ0FBQ1EsU0FBU0MsVUFBVSxJQUFJZCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDZSxTQUFTQyxVQUFVLElBQUloQixTQUFTLElBQUk7QUFFM0MsUUFBTWlCLGdCQUFnQjtBQUFBLElBQ3BCQyxPQUFPWjtBQUFBQSxJQUNQYSxPQUFPO0FBQUEsSUFDUEMsVUFDRTtBQUFBLElBQ0ZDLFdBQVc7QUFBQSxFQUNiO0FBRUF0QixZQUFVLE1BQU07QUFDZCxVQUFNdUIsZUFBZSxZQUFZO0FBQy9CLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU1mLFdBQVc7QUFDN0IsY0FBTWdCLE9BQU9ELEtBQUtDLE1BQU1BLFFBQVE7QUFFaEMsY0FBTUMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixjQUFNQyxnQkFBZ0JILEtBQUtJLE9BQU8sQ0FBQ0MsTUFBTTtBQUN2QyxjQUFJLENBQUNBLEVBQUVDLGFBQWEsQ0FBQ0QsRUFBRUUsUUFBUyxRQUFPO0FBQ3ZDLGlCQUNFTixTQUFTLElBQUlDLEtBQUtHLEVBQUVDLFNBQVMsS0FDN0JMLFNBQVMsSUFBSUMsS0FBS0csRUFBRUUsT0FBTztBQUFBLFFBRS9CLENBQUM7QUFHRCxjQUFNQyxnQkFBZ0I7QUFDdEIsY0FBTUMsT0FBTyxvQkFBSUMsSUFBSTtBQUNyQixtQkFBV0MsVUFBVVIsZUFBZTtBQUNsQyxnQkFBTVMsTUFBTUQsT0FBT0UsT0FBT0YsT0FBT2pCO0FBQ2pDLGNBQUksQ0FBQ2UsS0FBS0ssSUFBSUYsR0FBRyxHQUFHO0FBQ2xCSCxpQkFBS00sSUFBSUgsR0FBRztBQUNaSiwwQkFBY1EsS0FBS0wsTUFBTTtBQUFBLFVBQzNCO0FBQUEsUUFDRjtBQUVBLFlBQUlNLGVBQWVULGNBQWNVLFNBQVMsSUFBSVYsZ0JBQWdCLENBQUNmLGFBQWE7QUFJNUUsWUFBSXdCLGFBQWFDLFNBQVMsS0FBS0QsYUFBYUMsU0FBUyxHQUFHO0FBQ3RERCx5QkFBZSxDQUFDLEdBQUdBLGNBQWMsR0FBR0EsY0FBYyxHQUFHQSxZQUFZLEVBQUVFLE1BQU0sR0FBRyxDQUFDO0FBQUEsUUFDL0U7QUFFQTdCLG1CQUFXMkIsWUFBWTtBQUFBLE1BQ3pCLFNBQVNHLE9BQU87QUFDaEJDLGdCQUFRRCxNQUFNQSxLQUFLO0FBQ25CQyxnQkFBUUQsTUFBTUEsS0FBSztBQUNqQjlCLG1CQUFXLENBQUNHLGFBQWEsQ0FBQztBQUFBLE1BQzVCLFVBQUM7QUFDQ0QsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUVBTSxpQkFBYTtBQUFBLEVBQ2YsR0FBRyxDQUFDVixHQUFHLENBQUM7QUFFUixNQUFJRyxTQUFTO0FBQ1gsV0FBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWU7QUFBQSxFQUN4QjtBQUVBLFNBQ0UsdUJBQUMsYUFBUSxXQUFXLGdGQUFnRkwsV0FBVyxpQkFBaUIsc0NBQXNDLElBQ3BLO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLENBQUNQLFVBQVVDLFVBQVU7QUFBQSxRQUM5QixVQUFVLEVBQUUwQyxPQUFPLEtBQU1DLHNCQUFzQixNQUFNO0FBQUEsUUFDckQsTUFBTWxDLFFBQVE2QixTQUFTO0FBQUEsUUFDdkIsY0FBYztBQUFBLFFBQ2QsWUFBWSxFQUFFTSxXQUFXLEtBQUs7QUFBQSxRQUM5QixhQUFhO0FBQUEsVUFDWCxLQUFLLEVBQUVDLGVBQWUsSUFBSTtBQUFBLFVBQzFCLEtBQUssRUFBRUEsZUFBZSxJQUFJO0FBQUEsVUFDMUIsS0FBSyxFQUFFQSxlQUFlLEVBQUU7QUFBQSxVQUN4QixNQUFNLEVBQUVBLGVBQWUsRUFBRTtBQUFBLFFBQzNCO0FBQUEsUUFDQSxXQUFVO0FBQUEsUUFFVHBDLGtCQUFRcUMsSUFBSSxDQUFDZixRQUFRZ0IsVUFBVTtBQUM5QixnQkFBTTlCLFlBQVljLE9BQU9kO0FBRXpCLGlCQUNFLHVCQUFDLGVBQ0MsaUNBQUMsU0FBSSxXQUFVLDJKQUViO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxLQUFLYyxPQUFPakI7QUFBQUEsZ0JBQ1osS0FBS2lCLE9BQU9oQixTQUFTO0FBQUEsZ0JBQ3JCLFNBQVNnQyxVQUFVLElBQUksVUFBVTtBQUFBLGdCQUNqQyxVQUFTO0FBQUEsZ0JBQ1QsT0FBTztBQUFBLGdCQUNQLFFBQVE7QUFBQSxnQkFDUixXQUFVO0FBQUE7QUFBQSxjQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU93QztBQUFBLFlBSXZDOUIsYUFDQyxtQ0FDRTtBQUFBLHFDQUFDLFNBQUksV0FBVSxpRkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RjtBQUFBLGNBQzdGLHVCQUFDLFNBQUksV0FBVSw0Q0FDWmM7QUFBQUEsdUJBQU9oQixTQUNOLHVCQUFDLFFBQUcsV0FBVSxrRkFDWGdCLGlCQUFPaEIsU0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRURnQixPQUFPZixZQUNOLHVCQUFDLE9BQUUsV0FBVSwrRUFDVmUsaUJBQU9mLFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsZUE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkEsS0EvQmdCZSxPQUFPRSxNQUFNLEdBQUdGLE9BQU9FLEdBQUcsSUFBSWMsS0FBSyxLQUFLLEdBQUdoQixPQUFPakIsS0FBSyxJQUFJaUMsS0FBSyxJQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLFFBRUosQ0FBQztBQUFBO0FBQUEsTUFwREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REE7QUFBQSxJQUdBLHVCQUFDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhRTtBQUFBLE9BeEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RUE7QUFFSjtBQUFFeEMsR0E1SUlGLGFBQVc7QUFBQSxVQUNDSixPQUFPO0FBQUE7QUFBQSxLQURuQkk7QUE4SU4sZUFBZUE7QUFBWSxJQUFBMkM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTd2lwZXIiLCJTd2lwZXJTbGlkZSIsIkF1dG9wbGF5IiwiUGFnaW5hdGlvbiIsInVzZUF1dGgiLCJTZXJ2aWNlSW1nIiwiTG9hZGluZ1NwaW5uZXIiLCJnZXRCYW5uZXJzIiwiSGVyb1NlY3Rpb24iLCJub01hcmdpbiIsIl9zIiwiQVBJIiwiYmFubmVycyIsInNldEJhbm5lcnMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImRlZmF1bHRCYW5uZXIiLCJpbWFnZSIsInRpdGxlIiwic3VidGl0bGUiLCJpc0RlZmF1bHQiLCJmZXRjaEJhbm5lcnMiLCJyZXMiLCJkYXRhIiwidG9kYXkiLCJEYXRlIiwiYWN0aXZlQmFubmVycyIsImZpbHRlciIsImIiLCJzdGFydERhdGUiLCJlbmREYXRlIiwidW5pcXVlQmFubmVycyIsInNlZW4iLCJTZXQiLCJiYW5uZXIiLCJrZXkiLCJfaWQiLCJoYXMiLCJhZGQiLCJwdXNoIiwiZmluYWxCYW5uZXJzIiwibGVuZ3RoIiwic2xpY2UiLCJlcnJvciIsImNvbnNvbGUiLCJkZWxheSIsImRpc2FibGVPbkludGVyYWN0aW9uIiwiY2xpY2thYmxlIiwic2xpZGVzUGVyVmlldyIsIm1hcCIsImluZGV4IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGVyb1NlY3Rpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFN3aXBlciwgU3dpcGVyU2xpZGUgfSBmcm9tIFwic3dpcGVyL3JlYWN0XCI7XG5pbXBvcnQgeyBBdXRvcGxheSwgUGFnaW5hdGlvbiB9IGZyb20gXCJzd2lwZXIvbW9kdWxlc1wiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L2F1dGhcIjtcblxuaW1wb3J0IFwic3dpcGVyL2Nzc1wiO1xuaW1wb3J0IFwic3dpcGVyL2Nzcy9wYWdpbmF0aW9uXCI7XG5cbmltcG9ydCBTZXJ2aWNlSW1nIGZyb20gXCIuLi9hc3NldHMvU2VydmljZUltZy53ZWJwXCI7XG5pbXBvcnQgTG9hZGluZ1NwaW5uZXIgZnJvbSBcIi4vdWkvTG9hZGVyXCI7XG5pbXBvcnQgeyBnZXRCYW5uZXJzIH0gZnJvbSBcIi4uL3NlcnZpY2VzL1N5c3RlbVNlcnZpY2VcIjtcblxuY29uc3QgSGVyb1NlY3Rpb24gPSAoeyBub01hcmdpbiA9IGZhbHNlIH0pID0+IHtcbiAgY29uc3QgeyBBUEkgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgW2Jhbm5lcnMsIHNldEJhbm5lcnNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICBjb25zdCBkZWZhdWx0QmFubmVyID0ge1xuICAgIGltYWdlOiBTZXJ2aWNlSW1nLFxuICAgIHRpdGxlOiBcIlBvd2VyIFlvdXIgSG9tZSAmIEJ1c2luZXNzIHdpdGggUmVsaWFibGUgRWxlY3RyaWNhbCBTZXJ2aWNlc1wiLFxuICAgIHN1YnRpdGxlOlxuICAgICAgXCJFeHBlcnQgd2lyaW5nLCByZXBhaXIsIGFuZCBtYWludGVuYW5jZSBmb3IgaG9tZXMgJiBpbmR1c3RyaWVzIGFjcm9zcyBOb3J0aCBJbmRpYS5cIixcbiAgICBpc0RlZmF1bHQ6IHRydWUsXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEJhbm5lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2V0QmFubmVycygpO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXM/LmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgICAgICBjb25zdCBhY3RpdmVCYW5uZXJzID0gZGF0YS5maWx0ZXIoKGIpID0+IHtcclxuICAgICAgICAgIGlmICghYi5zdGFydERhdGUgfHwgIWIuZW5kRGF0ZSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICB0b2RheSA+PSBuZXcgRGF0ZShiLnN0YXJ0RGF0ZSkgJiZcclxuICAgICAgICAgICAgdG9kYXkgPD0gbmV3IERhdGUoYi5lbmREYXRlKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gMS4gUmVtb3ZlIGR1cGxpY2F0ZXMgbWFudWFsbHkgYnkgX2lkIG9yIGltYWdlXHJcbiAgICAgICAgY29uc3QgdW5pcXVlQmFubmVycyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IHNlZW4gPSBuZXcgU2V0KCk7XHJcbiAgICAgICAgZm9yIChjb25zdCBiYW5uZXIgb2YgYWN0aXZlQmFubmVycykge1xyXG4gICAgICAgICAgY29uc3Qga2V5ID0gYmFubmVyLl9pZCB8fCBiYW5uZXIuaW1hZ2U7XHJcbiAgICAgICAgICBpZiAoIXNlZW4uaGFzKGtleSkpIHtcclxuICAgICAgICAgICAgc2Vlbi5hZGQoa2V5KTtcclxuICAgICAgICAgICAgdW5pcXVlQmFubmVycy5wdXNoKGJhbm5lcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgZmluYWxCYW5uZXJzID0gdW5pcXVlQmFubmVycy5sZW5ndGggPiAwID8gdW5pcXVlQmFubmVycyA6IFtkZWZhdWx0QmFubmVyXTtcclxuXHJcbiAgICAgICAgLy8gSWYgd2UgaGF2ZSBiZXR3ZWVuIDItMyBiYW5uZXJzLCBTd2lwZXIncyBsb29wIGJyZWFrcyBiZWNhdXNlIGRlc2t0b3Agc2hvd3MgMyBzbGlkZXMgKHNsaWRlc1BlclZpZXc9MylcclxuICAgICAgICAvLyBEdXBsaWNhdGluZyB0aGUgYXJyYXkgZ2l2ZXMgaXQgZW5vdWdoIGNsb25lcyB0byBpbmZpbml0ZWx5IHNjcm9sbC9hdXRvcGxheSBzbW9vdGhseS5cclxuICAgICAgICBpZiAoZmluYWxCYW5uZXJzLmxlbmd0aCA+IDEgJiYgZmluYWxCYW5uZXJzLmxlbmd0aCA8IDQpIHtcclxuICAgICAgICAgIGZpbmFsQmFubmVycyA9IFsuLi5maW5hbEJhbm5lcnMsIC4uLmZpbmFsQmFubmVycywgLi4uZmluYWxCYW5uZXJzXS5zbGljZSgwLCA2KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldEJhbm5lcnMoZmluYWxCYW5uZXJzKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgICAgc2V0QmFubmVycyhbZGVmYXVsdEJhbm5lcl0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGZldGNoQmFubmVycygpO1xuICB9LCBbQVBJXSk7XG5cbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+O1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9e2BtYXgtdy03eGwgbXgtYXV0byBvdmVyZmxvdy1oaWRkZW4gcHgtNCBzbTpweC02IGxnOnB4LTggcGItMiBtZDpwYi0zIHJlbGF0aXZlICR7bm9NYXJnaW4gPyAncHQtMCBtZDpwdC0wJyA6ICdwdC00IG1kOnB0LTYgbXQtMTYgbWQ6bXQtMTggbGc6bXQtMjAnfWB9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgZ3JvdXBcIj5cbiAgICAgICAgPFN3aXBlclxuICAgICAgICAgIG1vZHVsZXM9e1tBdXRvcGxheSwgUGFnaW5hdGlvbl19XG4gICAgICAgICAgYXV0b3BsYXk9e3sgZGVsYXk6IDQwMDAsIGRpc2FibGVPbkludGVyYWN0aW9uOiBmYWxzZSB9fVxuICAgICAgICAgIGxvb3A9e2Jhbm5lcnMubGVuZ3RoID4gMX1cbiAgICAgICAgICBzcGFjZUJldHdlZW49ezIwfVxuICAgICAgICAgIHBhZ2luYXRpb249e3sgY2xpY2thYmxlOiB0cnVlIH19XG4gICAgICAgICAgYnJlYWtwb2ludHM9e3tcbiAgICAgICAgICAgIDMyMDogeyBzbGlkZXNQZXJWaWV3OiAxLjEgfSxcbiAgICAgICAgICAgIDY0MDogeyBzbGlkZXNQZXJWaWV3OiAxLjUgfSxcbiAgICAgICAgICAgIDc2ODogeyBzbGlkZXNQZXJWaWV3OiAyIH0sXG4gICAgICAgICAgICAxMDI0OiB7IHNsaWRlc1BlclZpZXc6IDMgfSxcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwYi02XCJcbiAgICAgICAgPlxuICAgICAgICAgIHtiYW5uZXJzLm1hcCgoYmFubmVyLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNEZWZhdWx0ID0gYmFubmVyLmlzRGVmYXVsdDtcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPFN3aXBlclNsaWRlIGtleT17YmFubmVyLl9pZCA/IGAke2Jhbm5lci5faWR9LSR7aW5kZXh9YCA6IGAke2Jhbm5lci5pbWFnZX0tJHtpbmRleH1gfT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBoLVsxNDBweF0gc206aC1bMTgwcHhdIG1kOmgtWzIyMHB4XSByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvdyBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBNYWluIGltYWdlICovfVxuICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICBzcmM9e2Jhbm5lci5pbWFnZX1cbiAgICAgICAgICAgICAgICAgICAgYWx0PXtiYW5uZXIudGl0bGUgfHwgXCJSYWogRWxlY3RyaWNhbCBTZXJ2aWNlIEJhbm5lclwifVxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtpbmRleCA9PT0gMCA/IFwiZWFnZXJcIiA6IFwibGF6eVwifVxuICAgICAgICAgICAgICAgICAgICBkZWNvZGluZz1cImFzeW5jXCJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9ezgwMH1cbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PXs0NTB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCJcbiAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBSZW5kZXIgdGV4dCBvdmVybGF5IE9OTFkgZm9yIGRlZmF1bHQgYmFubmVyIGlmIGJhY2tlbmQgZGlkbid0IHN1cHBseSBjdXN0b20gZGVzaWduZWQgZ3JhcGhpY3MgKi99XG4gICAgICAgICAgICAgICAgICB7aXNEZWZhdWx0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tdCBmcm9tLWJsYWNrLzc1IHZpYS1ibGFjay8yMCB0by10cmFuc3BhcmVudFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHctZnVsbCBwLTQgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Jhbm5lci50aXRsZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIHNtOnRleHQtYmFzZSBtZDp0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGZvbnQtcG9wcGlucyBsaW5lLWNsYW1wLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFubmVyLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtiYW5uZXIuc3VidGl0bGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXh4cyBzbTp0ZXh0LXhzIG1kOnRleHQtc20gdGV4dC1ncmF5LTMwMCBmb250LXBvcHBpbnMgbGluZS1jbGFtcC0yIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFubmVyLnN1YnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvU3dpcGVyU2xpZGU+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L1N3aXBlcj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ3VzdG9tIFN0eWxlcyB0byBPdmVycmlkZSBTd2lwZXIgQnVsbGV0cyBjb2xvciB0byBtYXRjaCB0aGUgZGVzaWduIChlLmcuIGJyb3duaXNoIGFjdGl2ZSBkb3QpICovfVxuICAgICAgPHN0eWxlPntgXG4gICAgICAgIC5zd2lwZXItcGFnaW5hdGlvbi1idWxsZXQge1xuICAgICAgICAgIGJhY2tncm91bmQ6ICNkMWQ1ZGIgIWltcG9ydGFudDtcbiAgICAgICAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG4gICAgICAgICAgd2lkdGg6IDhweCAhaW1wb3J0YW50O1xuICAgICAgICAgIGhlaWdodDogOHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcbiAgICAgICAgfVxuICAgICAgICAuc3dpcGVyLXBhZ2luYXRpb24tYnVsbGV0LWFjdGl2ZSB7XG4gICAgICAgICAgYmFja2dyb3VuZDogI0ZGNUUwMCAhaW1wb3J0YW50OyAvKiB3YXJtIGJyb3duIG1hdGNoaW5nIGJyYW5kICovXG4gICAgICAgICAgd2lkdGg6IDI0cHggIWltcG9ydGFudDtcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHggIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgICAgYH08L3N0eWxlPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhlcm9TZWN0aW9uOyJdLCJmaWxlIjoiQzovUHJvamVjdC9TZXJ2aWNlL2NsaWVudC9zcmMvY29tcG9uZW50cy9IZXJvU2VjdGlvbi5qc3gifQ==
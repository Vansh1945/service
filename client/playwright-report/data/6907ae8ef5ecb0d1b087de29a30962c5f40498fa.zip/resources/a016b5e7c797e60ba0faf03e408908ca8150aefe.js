import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/shared/static/Services.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=38a573e6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Project/Service/client/src/features/shared/static/Services.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=38a573e6"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { Search, RefreshCw, ChevronLeft, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=38a573e6";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=38a573e6";
import ServiceCardSkeleton from "/src/components/ui-skeletons/ServiceCardSkeleton.jsx";
import { getActiveServices } from "/src/services/ServiceService.js";
import ServiceCard from "/src/features/customer/services/components/ServiceCard.jsx";
import useCategory from "/src/hooks/useCategory.js";
import useSurchargeBooking from "/src/hooks/useSurchargeBooking.js";
const Services = ({ limit }) => {
  _s();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [, setError] = useState(null);
  const sliderRef = useRef(null);
  const [isHovered, setIsHovered] = useState(false);
  const { categories } = useCategory();
  const { getMergedPrice, handleBookNow } = useSurchargeBooking();
  const categoryMap = useMemo(() => {
    return categories.reduce((acc, cat) => ({ ...acc, [cat.value]: cat.label }), {});
  }, [categories]);
  const fetchServices = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await getActiveServices();
      const data = response.data;
      if (data.success && data.data) {
        const transformedData = data.data.map((service) => ({
          ...service,
          displayImage: service.images && service.images.length > 0 ? service.images[0] : service.image || null
        }));
        setServices(transformedData);
      } else {
        setServices([]);
      }
    } catch (err) {
      console.error("Error fetching services:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    fetchServices();
  }, [fetchServices]);
  useEffect(() => {
    if (loading || services.length === 0 || isHovered) return;
    const interval = setInterval(() => {
      if (sliderRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
        if (scrollLeft + clientWidth >= scrollWidth - 15) {
          sliderRef.current.scrollTo({ left: 0, behavior: "smooth" });
        } else {
          const firstChild = sliderRef.current.firstElementChild;
          const cardWidth = firstChild ? firstChild.getBoundingClientRect().width : 300;
          const gap = window.innerWidth >= 768 ? 24 : 16;
          sliderRef.current.scrollBy({ left: cardWidth + gap, behavior: "smooth" });
        }
      }
    }, 4e3);
    return () => clearInterval(interval);
  }, [services, loading, isHovered]);
  const scrollSlider = (direction) => {
    if (sliderRef.current) {
      const scrollAmount = direction === "left" ? -300 : 300;
      sliderRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxDEV("section", { className: "bg-transparent py-2 px-4 md:px-8", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 md:gap-6 overflow-x-auto pb-4 scrollbar-hide", children: Array.from({ length: limit || 6 }).map(
      (_, i) => /* @__PURE__ */ jsxDEV("div", { className: "w-[calc((100%-16px)/2)] sm:w-[calc((100%-48px)/3.5)] md:w-[calc((100%-72px)/3.5)] lg:w-[calc((100%-144px)/6.5)] flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ServiceCardSkeleton, {}, void 0, false, {
        fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
        lineNumber: 108,
        columnNumber: 17
      }, this) }, i, false, {
        fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
        lineNumber: 107,
        columnNumber: 13
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
      lineNumber: 105,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
      lineNumber: 104,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this);
  }
  const displayedServices = limit ? services.slice(0, limit) : services;
  return /* @__PURE__ */ jsxDEV("section", { className: "max-w-7xl mx-auto bg-transparent py-2 px-4 sm:px-6 lg:px-8 relative group/section", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full relative", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-xl md:text-2xl font-extrabold text-secondary font-poppins", children: "Popular Services" }, void 0, false, {
        fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
        lineNumber: 124,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: "/customer/services-list",
          className: "text-xs md:text-sm font-bold text-primary hover:text-teal-800 transition-colors flex items-center gap-1 group/link",
          children: [
            "View All Services",
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 transition-transform group-hover/link:translate-x-1" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
              lineNumber: 132,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
          lineNumber: 127,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
      lineNumber: 123,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => scrollSlider("left"),
          className: "absolute -left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white border border-gray-150 rounded-full flex items-center justify-center shadow-lg text-secondary hover:text-primary active:scale-90 transition-all opacity-0 group-hover/section:opacity-100 disabled:opacity-0",
          "aria-label": "Scroll left",
          children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "w-5 h-5" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
            lineNumber: 144,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
          lineNumber: 139,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => scrollSlider("right"),
          className: "absolute -right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white border border-gray-150 rounded-full flex items-center justify-center shadow-lg text-secondary hover:text-primary active:scale-90 transition-all opacity-0 group-hover/section:opacity-100 disabled:opacity-0",
          "aria-label": "Scroll right",
          children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5" }, void 0, false, {
            fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
            lineNumber: 153,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
          lineNumber: 148,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          ref: sliderRef,
          onMouseEnter: () => setIsHovered(true),
          onMouseLeave: () => setIsHovered(false),
          onTouchStart: () => setIsHovered(true),
          onTouchEnd: () => setIsHovered(false),
          className: "flex gap-4 md:gap-6 overflow-x-auto pb-4 scroll-smooth snap-x snap-mandatory scrollbar-hide",
          style: {
            scrollbarWidth: "none",
            msOverflowStyle: "none"
          },
          children: displayedServices.map(
            (service) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "w-[calc((100%-16px)/2)] sm:w-[calc((100%-48px)/3.5)] md:w-[calc((100%-72px)/3.5)] lg:w-[calc((100%-144px)/6.5)] flex-shrink-0 snap-start",
                children: /* @__PURE__ */ jsxDEV(
                  ServiceCard,
                  {
                    service,
                    categoryMap,
                    onBook: handleBookNow,
                    getMergedPrice
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
                    lineNumber: 174,
                    columnNumber: 17
                  },
                  this
                )
              },
              service._id,
              false,
              {
                fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
                lineNumber: 170,
                columnNumber: 13
              },
              this
            )
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
          lineNumber: 157,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
      lineNumber: 137,
      columnNumber: 9
    }, this),
    services.length === 0 && !loading && /* @__PURE__ */ jsxDEV("div", { className: "text-center py-20 bg-white rounded-2xl border border-gray-100", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "w-12 h-12 text-gray-200 mx-auto mb-4" }, void 0, false, {
        fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
        lineNumber: 187,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-secondary mb-2", children: "No Services Found" }, void 0, false, {
        fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
        lineNumber: 188,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 mb-6", children: "We're working hard to bring more services to you." }, void 0, false, {
        fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
        lineNumber: 189,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => window.location.reload(),
          className: "px-6 py-2 bg-gray-50 text-secondary font-bold rounded-xl border border-gray-200 hover:bg-gray-100 transition-all inline-flex items-center gap-2",
          children: [
            /* @__PURE__ */ jsxDEV(RefreshCw, { className: "w-4 h-4" }, void 0, false, {
              fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
              lineNumber: 194,
              columnNumber: 15
            }, this),
            " Refresh"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
          lineNumber: 190,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
      lineNumber: 186,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
    lineNumber: 121,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Project/Service/client/src/features/shared/static/Services.jsx",
    lineNumber: 120,
    columnNumber: 5
  }, this);
};
_s(Services, "x8B2ktl2umF+NxdZzDmD6GVumYs=", false, function() {
  return [useCategory, useSurchargeBooking];
});
_c = Services;
export default Services;
var _c;
$RefreshReg$(_c, "Services");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Project/Service/client/src/features/shared/static/Services.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Project/Service/client/src/features/shared/static/Services.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4RmhCLE9BQU9BLFNBQVNDLFVBQVVDLFdBQVdDLFFBQVFDLFNBQVNDLG1CQUFtQjtBQUN6RSxTQUFTQyxRQUFRQyxXQUFXQyxhQUFhQyxvQkFBb0I7QUFDN0QsU0FBU0MsWUFBWTtBQUNyQixPQUFPQyx5QkFBeUI7QUFDaEMsU0FBU0MseUJBQXlCO0FBQ2xDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MseUJBQXlCO0FBRWhDLE1BQU1DLFdBQVdBLENBQUMsRUFBRUMsTUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDOUIsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUluQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDb0IsU0FBU0MsVUFBVSxJQUFJckIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sR0FBR3NCLFFBQVEsSUFBSXRCLFNBQVMsSUFBSTtBQUNsQyxRQUFNdUIsWUFBWXJCLE9BQU8sSUFBSTtBQUM3QixRQUFNLENBQUNzQixXQUFXQyxZQUFZLElBQUl6QixTQUFTLEtBQUs7QUFFaEQsUUFBTSxFQUFFMEIsV0FBVyxJQUFJYixZQUFZO0FBQ25DLFFBQU0sRUFBRWMsZ0JBQWdCQyxjQUFjLElBQUlkLG9CQUFvQjtBQUU5RCxRQUFNZSxjQUFjMUIsUUFBUSxNQUFNO0FBQ2hDLFdBQU91QixXQUFXSSxPQUFPLENBQUNDLEtBQUtDLFNBQVMsRUFBRSxHQUFHRCxLQUFLLENBQUNDLElBQUlDLEtBQUssR0FBR0QsSUFBSUUsTUFBTSxJQUFJLENBQUMsQ0FBQztBQUFBLEVBQ2pGLEdBQUcsQ0FBQ1IsVUFBVSxDQUFDO0FBRWYsUUFBTVMsZ0JBQWdCL0IsWUFBWSxZQUFZO0FBQzVDLFFBQUk7QUFDRmlCLGlCQUFXLElBQUk7QUFDZkMsZUFBUyxJQUFJO0FBQ2IsWUFBTWMsV0FBVyxNQUFNekIsa0JBQWtCO0FBQ3pDLFlBQU0wQixPQUFPRCxTQUFTQztBQUV0QixVQUFJQSxLQUFLQyxXQUFXRCxLQUFLQSxNQUFNO0FBQzdCLGNBQU1FLGtCQUFrQkYsS0FBS0EsS0FBS0csSUFBSSxDQUFBQyxhQUFZO0FBQUEsVUFDaEQsR0FBR0E7QUFBQUEsVUFDSEMsY0FBY0QsUUFBUUUsVUFBVUYsUUFBUUUsT0FBT0MsU0FBUyxJQUFJSCxRQUFRRSxPQUFPLENBQUMsSUFBSUYsUUFBUUksU0FBUztBQUFBLFFBQ25HLEVBQUU7QUFDRjFCLG9CQUFZb0IsZUFBZTtBQUFBLE1BQzdCLE9BQU87QUFDTHBCLG9CQUFZLEVBQUU7QUFBQSxNQUNoQjtBQUFBLElBQ0YsU0FBUzJCLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSw0QkFBNEJGLEdBQUc7QUFDN0N4QixlQUFTd0IsSUFBSUcsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDQzVCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUxwQixZQUFVLE1BQU07QUFDZGtDLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxDQUFDQSxhQUFhLENBQUM7QUFHbEJsQyxZQUFVLE1BQU07QUFDZCxRQUFJbUIsV0FBV0YsU0FBUzBCLFdBQVcsS0FBS3BCLFVBQVc7QUFFbkQsVUFBTTBCLFdBQVdDLFlBQVksTUFBTTtBQUNqQyxVQUFJNUIsVUFBVTZCLFNBQVM7QUFDckIsY0FBTSxFQUFFQyxZQUFZQyxhQUFhQyxZQUFZLElBQUloQyxVQUFVNkI7QUFFM0QsWUFBSUMsYUFBYUUsZUFBZUQsY0FBYyxJQUFJO0FBQ2hEL0Isb0JBQVU2QixRQUFRSSxTQUFTLEVBQUVDLE1BQU0sR0FBR0MsVUFBVSxTQUFTLENBQUM7QUFBQSxRQUM1RCxPQUFPO0FBQ0wsZ0JBQU1DLGFBQWFwQyxVQUFVNkIsUUFBUVE7QUFDckMsZ0JBQU1DLFlBQVlGLGFBQWFBLFdBQVdHLHNCQUFzQixFQUFFQyxRQUFRO0FBQzFFLGdCQUFNQyxNQUFNQyxPQUFPQyxjQUFjLE1BQU0sS0FBSztBQUM1QzNDLG9CQUFVNkIsUUFBUWUsU0FBUyxFQUFFVixNQUFNSSxZQUFZRyxLQUFLTixVQUFVLFNBQVMsQ0FBQztBQUFBLFFBQzFFO0FBQUEsTUFDRjtBQUFBLElBQ0YsR0FBRyxHQUFJO0FBRVAsV0FBTyxNQUFNVSxjQUFjbEIsUUFBUTtBQUFBLEVBQ3JDLEdBQUcsQ0FBQ2hDLFVBQVVFLFNBQVNJLFNBQVMsQ0FBQztBQUVqQyxRQUFNNkMsZUFBZUEsQ0FBQ0MsY0FBYztBQUNsQyxRQUFJL0MsVUFBVTZCLFNBQVM7QUFFckIsWUFBTW1CLGVBQWVELGNBQWMsU0FBUyxPQUFPO0FBQ25EL0MsZ0JBQVU2QixRQUFRZSxTQUFTLEVBQUVWLE1BQU1jLGNBQWNiLFVBQVUsU0FBUyxDQUFDO0FBQUEsSUFDdkU7QUFBQSxFQUNGO0FBRUEsTUFBSXRDLFNBQVM7QUFDWCxXQUNFLHVCQUFDLGFBQVEsV0FBVSxvQ0FDakIsaUNBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsU0FBSSxXQUFVLDJEQUNab0QsZ0JBQU1DLEtBQUssRUFBRTdCLFFBQVE1QixTQUFTLEVBQUUsQ0FBQyxFQUFFd0I7QUFBQUEsTUFBSSxDQUFDa0MsR0FBR0MsTUFDMUMsdUJBQUMsU0FBWSxXQUFVLGlJQUNyQixpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CLEtBRFpBLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLEVBRUo7QUFFQSxRQUFNQyxvQkFBb0I1RCxRQUFRRSxTQUFTMkQsTUFBTSxHQUFHN0QsS0FBSyxJQUFJRTtBQUU3RCxTQUNFLHVCQUFDLGFBQVEsV0FBVSxxRkFDakIsaUNBQUMsU0FBSSxXQUFVLG1CQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLGtFQUFpRSxnQ0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsV0FBVTtBQUFBLFVBQW9IO0FBQUE7QUFBQSxZQUc5SCx1QkFBQyxnQkFBYSxXQUFVLGlFQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBO0FBQUE7QUFBQSxRQUx2RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsWUFFYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1tRCxhQUFhLE1BQU07QUFBQSxVQUNsQyxXQUFVO0FBQUEsVUFDVixjQUFXO0FBQUEsVUFFWCxpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQTtBQUFBLFFBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsTUFHQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNQSxhQUFhLE9BQU87QUFBQSxVQUNuQyxXQUFVO0FBQUEsVUFDVixjQUFXO0FBQUEsVUFFWCxpQ0FBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUE7QUFBQSxRQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BR0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLEtBQUs5QztBQUFBQSxVQUNMLGNBQWMsTUFBTUUsYUFBYSxJQUFJO0FBQUEsVUFDckMsY0FBYyxNQUFNQSxhQUFhLEtBQUs7QUFBQSxVQUN0QyxjQUFjLE1BQU1BLGFBQWEsSUFBSTtBQUFBLFVBQ3JDLFlBQVksTUFBTUEsYUFBYSxLQUFLO0FBQUEsVUFDcEMsV0FBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFlBQ0xxRCxnQkFBZ0I7QUFBQSxZQUNoQkMsaUJBQWlCO0FBQUEsVUFDbkI7QUFBQSxVQUVDSCw0QkFBa0JwQztBQUFBQSxZQUFJLENBQUNDLFlBQ3RCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVWO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQSxRQUFRYjtBQUFBQSxvQkFDUjtBQUFBO0FBQUEsa0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlpQztBQUFBO0FBQUEsY0FQNUJhLFFBQVF1QztBQUFBQSxjQURmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFVBQ0Q7QUFBQTtBQUFBLFFBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXlCQTtBQUFBLFNBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0E7QUFBQSxJQUVDOUQsU0FBUzBCLFdBQVcsS0FBSyxDQUFDeEIsV0FDekIsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsNkJBQUMsVUFBTyxXQUFVLDBDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQsdUJBQUMsUUFBRyxXQUFVLHlDQUF3QyxpQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RTtBQUFBLE1BQ3ZFLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsaUVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUY7QUFBQSxNQUNuRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNNkMsT0FBT2dCLFNBQVNDLE9BQU87QUFBQSxVQUN0QyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFKbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BM0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2RUEsS0E5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStFQTtBQUVKO0FBQUVqRSxHQTVLSUYsVUFBUTtBQUFBLFVBT1dGLGFBQ21CQyxtQkFBbUI7QUFBQTtBQUFBLEtBUnpEQztBQThLTixlQUFlQTtBQUFTLElBQUFvRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlTWVtbyIsInVzZUNhbGxiYWNrIiwiU2VhcmNoIiwiUmVmcmVzaEN3IiwiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJMaW5rIiwiU2VydmljZUNhcmRTa2VsZXRvbiIsImdldEFjdGl2ZVNlcnZpY2VzIiwiU2VydmljZUNhcmQiLCJ1c2VDYXRlZ29yeSIsInVzZVN1cmNoYXJnZUJvb2tpbmciLCJTZXJ2aWNlcyIsImxpbWl0IiwiX3MiLCJzZXJ2aWNlcyIsInNldFNlcnZpY2VzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZXRFcnJvciIsInNsaWRlclJlZiIsImlzSG92ZXJlZCIsInNldElzSG92ZXJlZCIsImNhdGVnb3JpZXMiLCJnZXRNZXJnZWRQcmljZSIsImhhbmRsZUJvb2tOb3ciLCJjYXRlZ29yeU1hcCIsInJlZHVjZSIsImFjYyIsImNhdCIsInZhbHVlIiwibGFiZWwiLCJmZXRjaFNlcnZpY2VzIiwicmVzcG9uc2UiLCJkYXRhIiwic3VjY2VzcyIsInRyYW5zZm9ybWVkRGF0YSIsIm1hcCIsInNlcnZpY2UiLCJkaXNwbGF5SW1hZ2UiLCJpbWFnZXMiLCJsZW5ndGgiLCJpbWFnZSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsIm1lc3NhZ2UiLCJpbnRlcnZhbCIsInNldEludGVydmFsIiwiY3VycmVudCIsInNjcm9sbExlZnQiLCJzY3JvbGxXaWR0aCIsImNsaWVudFdpZHRoIiwic2Nyb2xsVG8iLCJsZWZ0IiwiYmVoYXZpb3IiLCJmaXJzdENoaWxkIiwiZmlyc3RFbGVtZW50Q2hpbGQiLCJjYXJkV2lkdGgiLCJnZXRCb3VuZGluZ0NsaWVudFJlY3QiLCJ3aWR0aCIsImdhcCIsIndpbmRvdyIsImlubmVyV2lkdGgiLCJzY3JvbGxCeSIsImNsZWFySW50ZXJ2YWwiLCJzY3JvbGxTbGlkZXIiLCJkaXJlY3Rpb24iLCJzY3JvbGxBbW91bnQiLCJBcnJheSIsImZyb20iLCJfIiwiaSIsImRpc3BsYXllZFNlcnZpY2VzIiwic2xpY2UiLCJzY3JvbGxiYXJXaWR0aCIsIm1zT3ZlcmZsb3dTdHlsZSIsIl9pZCIsImxvY2F0aW9uIiwicmVsb2FkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VydmljZXMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZU1lbW8sIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBTZWFyY2gsIFJlZnJlc2hDdywgQ2hldnJvbkxlZnQsIENoZXZyb25SaWdodCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IFNlcnZpY2VDYXJkU2tlbGV0b24gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy91aS1za2VsZXRvbnMvU2VydmljZUNhcmRTa2VsZXRvbic7XHJcbmltcG9ydCB7IGdldEFjdGl2ZVNlcnZpY2VzIH0gZnJvbSAnLi4vLi4vLi4vc2VydmljZXMvU2VydmljZVNlcnZpY2UnO1xyXG5pbXBvcnQgU2VydmljZUNhcmQgZnJvbSAnLi4vLi4vY3VzdG9tZXIvc2VydmljZXMvY29tcG9uZW50cy9TZXJ2aWNlQ2FyZCc7XHJcbmltcG9ydCB1c2VDYXRlZ29yeSBmcm9tICcuLi8uLi8uLi9ob29rcy91c2VDYXRlZ29yeSc7XHJcbmltcG9ydCB1c2VTdXJjaGFyZ2VCb29raW5nIGZyb20gJy4uLy4uLy4uL2hvb2tzL3VzZVN1cmNoYXJnZUJvb2tpbmcnO1xyXG5cclxuY29uc3QgU2VydmljZXMgPSAoeyBsaW1pdCB9KSA9PiB7XHJcbiAgY29uc3QgW3NlcnZpY2VzLCBzZXRTZXJ2aWNlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgWywgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3Qgc2xpZGVyUmVmID0gdXNlUmVmKG51bGwpO1xyXG4gIGNvbnN0IFtpc0hvdmVyZWQsIHNldElzSG92ZXJlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IHsgY2F0ZWdvcmllcyB9ID0gdXNlQ2F0ZWdvcnkoKTtcclxuICBjb25zdCB7IGdldE1lcmdlZFByaWNlLCBoYW5kbGVCb29rTm93IH0gPSB1c2VTdXJjaGFyZ2VCb29raW5nKCk7XHJcblxyXG4gIGNvbnN0IGNhdGVnb3J5TWFwID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gY2F0ZWdvcmllcy5yZWR1Y2UoKGFjYywgY2F0KSA9PiAoeyAuLi5hY2MsIFtjYXQudmFsdWVdOiBjYXQubGFiZWwgfSksIHt9KTtcclxuICB9LCBbY2F0ZWdvcmllc10pO1xyXG5cclxuICBjb25zdCBmZXRjaFNlcnZpY2VzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZ2V0QWN0aXZlU2VydmljZXMoKTtcclxuICAgICAgY29uc3QgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gICAgICBpZiAoZGF0YS5zdWNjZXNzICYmIGRhdGEuZGF0YSkge1xyXG4gICAgICAgIGNvbnN0IHRyYW5zZm9ybWVkRGF0YSA9IGRhdGEuZGF0YS5tYXAoc2VydmljZSA9PiAoe1xyXG4gICAgICAgICAgLi4uc2VydmljZSxcclxuICAgICAgICAgIGRpc3BsYXlJbWFnZTogc2VydmljZS5pbWFnZXMgJiYgc2VydmljZS5pbWFnZXMubGVuZ3RoID4gMCA/IHNlcnZpY2UuaW1hZ2VzWzBdIDogc2VydmljZS5pbWFnZSB8fCBudWxsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFNlcnZpY2VzKHRyYW5zZm9ybWVkRGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0U2VydmljZXMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgc2VydmljZXM6JywgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hTZXJ2aWNlcygpO1xyXG4gIH0sIFtmZXRjaFNlcnZpY2VzXSk7XHJcblxyXG4gIC8vIEF1dG8tc2Nyb2xsIGVmZmVjdFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAobG9hZGluZyB8fCBzZXJ2aWNlcy5sZW5ndGggPT09IDAgfHwgaXNIb3ZlcmVkKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGlmIChzbGlkZXJSZWYuY3VycmVudCkge1xyXG4gICAgICAgIGNvbnN0IHsgc2Nyb2xsTGVmdCwgc2Nyb2xsV2lkdGgsIGNsaWVudFdpZHRoIH0gPSBzbGlkZXJSZWYuY3VycmVudDtcclxuICAgICAgICAvLyBJZiB3ZSBoYXZlIHJlYWNoZWQgdGhlIGVuZCwgc2Nyb2xsIGJhY2sgdG8gdGhlIHN0YXJ0XHJcbiAgICAgICAgaWYgKHNjcm9sbExlZnQgKyBjbGllbnRXaWR0aCA+PSBzY3JvbGxXaWR0aCAtIDE1KSB7XHJcbiAgICAgICAgICBzbGlkZXJSZWYuY3VycmVudC5zY3JvbGxUbyh7IGxlZnQ6IDAsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc3QgZmlyc3RDaGlsZCA9IHNsaWRlclJlZi5jdXJyZW50LmZpcnN0RWxlbWVudENoaWxkO1xyXG4gICAgICAgICAgY29uc3QgY2FyZFdpZHRoID0gZmlyc3RDaGlsZCA/IGZpcnN0Q2hpbGQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggOiAzMDA7XHJcbiAgICAgICAgICBjb25zdCBnYXAgPSB3aW5kb3cuaW5uZXJXaWR0aCA+PSA3NjggPyAyNCA6IDE2O1xyXG4gICAgICAgICAgc2xpZGVyUmVmLmN1cnJlbnQuc2Nyb2xsQnkoeyBsZWZ0OiBjYXJkV2lkdGggKyBnYXAsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0sIDQwMDApOyAvLyBTY3JvbGwgZXZlcnkgNCBzZWNvbmRzXHJcblxyXG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xyXG4gIH0sIFtzZXJ2aWNlcywgbG9hZGluZywgaXNIb3ZlcmVkXSk7XHJcblxyXG4gIGNvbnN0IHNjcm9sbFNsaWRlciA9IChkaXJlY3Rpb24pID0+IHtcclxuICAgIGlmIChzbGlkZXJSZWYuY3VycmVudCkge1xyXG4gICAgICAvLyBTY3JvbGwgYnkgcm91Z2hseSAxIGNhcmQgd2lkdGggKyBnYXAgKGFwcHJveCAzMDBweClcclxuICAgICAgY29uc3Qgc2Nyb2xsQW1vdW50ID0gZGlyZWN0aW9uID09PSAnbGVmdCcgPyAtMzAwIDogMzAwO1xyXG4gICAgICBzbGlkZXJSZWYuY3VycmVudC5zY3JvbGxCeSh7IGxlZnQ6IHNjcm9sbEFtb3VudCwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGlmIChsb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudCBweS0yIHB4LTQgbWQ6cHgtOFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWQ6Z2FwLTYgb3ZlcmZsb3cteC1hdXRvIHBiLTQgc2Nyb2xsYmFyLWhpZGVcIj5cclxuICAgICAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IGxpbWl0IHx8IDYgfSkubWFwKChfLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInctW2NhbGMoKDEwMCUtMTZweCkvMildIHNtOnctW2NhbGMoKDEwMCUtNDhweCkvMy41KV0gbWQ6dy1bY2FsYygoMTAwJS03MnB4KS8zLjUpXSBsZzp3LVtjYWxjKCgxMDAlLTE0NHB4KS82LjUpXSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VydmljZUNhcmRTa2VsZXRvbiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgZGlzcGxheWVkU2VydmljZXMgPSBsaW1pdCA/IHNlcnZpY2VzLnNsaWNlKDAsIGxpbWl0KSA6IHNlcnZpY2VzO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gYmctdHJhbnNwYXJlbnQgcHktMiBweC00IHNtOnB4LTYgbGc6cHgtOCByZWxhdGl2ZSBncm91cC9zZWN0aW9uXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgey8qIEhlYWRlciBTZWN0aW9uICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIG1kOnRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2Vjb25kYXJ5IGZvbnQtcG9wcGluc1wiPlxyXG4gICAgICAgICAgICBQb3B1bGFyIFNlcnZpY2VzXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89XCIvY3VzdG9tZXIvc2VydmljZXMtbGlzdFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgbWQ6dGV4dC1zbSBmb250LWJvbGQgdGV4dC1wcmltYXJ5IGhvdmVyOnRleHQtdGVhbC04MDAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZ3JvdXAvbGlua1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFZpZXcgQWxsIFNlcnZpY2VzXHJcbiAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBncm91cC1ob3Zlci9saW5rOnRyYW5zbGF0ZS14LTFcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQ2Fyb3VzZWwgQ29udGFpbmVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgIHsvKiBMZWZ0IEFycm93IEJ1dHRvbiAqL31cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2Nyb2xsU2xpZGVyKCdsZWZ0Jyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIC1sZWZ0LTQgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHotMjAgdy0xMCBoLTEwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0xNTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1sZyB0ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgYWN0aXZlOnNjYWxlLTkwIHRyYW5zaXRpb24tYWxsIG9wYWNpdHktMCBncm91cC1ob3Zlci9zZWN0aW9uOm9wYWNpdHktMTAwIGRpc2FibGVkOm9wYWNpdHktMFwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTY3JvbGwgbGVmdFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgIHsvKiBSaWdodCBBcnJvdyBCdXR0b24gKi99XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNjcm9sbFNsaWRlcigncmlnaHQnKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXJpZ2h0LTQgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHotMjAgdy0xMCBoLTEwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0xNTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1sZyB0ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LXByaW1hcnkgYWN0aXZlOnNjYWxlLTkwIHRyYW5zaXRpb24tYWxsIG9wYWNpdHktMCBncm91cC1ob3Zlci9zZWN0aW9uOm9wYWNpdHktMTAwIGRpc2FibGVkOm9wYWNpdHktMFwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTY3JvbGwgcmlnaHRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgey8qIFNsaWRlciBDb250ZW50ICovfVxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICByZWY9e3NsaWRlclJlZn1cclxuICAgICAgICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiBzZXRJc0hvdmVyZWQodHJ1ZSl9XHJcbiAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KCkgPT4gc2V0SXNIb3ZlcmVkKGZhbHNlKX1cclxuICAgICAgICAgICAgb25Ub3VjaFN0YXJ0PXsoKSA9PiBzZXRJc0hvdmVyZWQodHJ1ZSl9XHJcbiAgICAgICAgICAgIG9uVG91Y2hFbmQ9eygpID0+IHNldElzSG92ZXJlZChmYWxzZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWQ6Z2FwLTYgb3ZlcmZsb3cteC1hdXRvIHBiLTQgc2Nyb2xsLXNtb290aCBzbmFwLXggc25hcC1tYW5kYXRvcnkgc2Nyb2xsYmFyLWhpZGVcIlxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIHNjcm9sbGJhcldpZHRoOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgbXNPdmVyZmxvd1N0eWxlOiAnbm9uZScsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtkaXNwbGF5ZWRTZXJ2aWNlcy5tYXAoKHNlcnZpY2UpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e3NlcnZpY2UuX2lkfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1bY2FsYygoMTAwJS0xNnB4KS8yKV0gc206dy1bY2FsYygoMTAwJS00OHB4KS8zLjUpXSBtZDp3LVtjYWxjKCgxMDAlLTcycHgpLzMuNSldIGxnOnctW2NhbGMoKDEwMCUtMTQ0cHgpLzYuNSldIGZsZXgtc2hyaW5rLTAgc25hcC1zdGFydFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlcnZpY2VDYXJkXHJcbiAgICAgICAgICAgICAgICAgIHNlcnZpY2U9e3NlcnZpY2V9XHJcbiAgICAgICAgICAgICAgICAgIGNhdGVnb3J5TWFwPXtjYXRlZ29yeU1hcH1cclxuICAgICAgICAgICAgICAgICAgb25Cb29rPXtoYW5kbGVCb29rTm93fVxyXG4gICAgICAgICAgICAgICAgICBnZXRNZXJnZWRQcmljZT17Z2V0TWVyZ2VkUHJpY2V9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7c2VydmljZXMubGVuZ3RoID09PSAwICYmICFsb2FkaW5nICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMjAgYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LWdyYXktMjAwIG14LWF1dG8gbWItNFwiIC8+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeSBtYi0yXCI+Tm8gU2VydmljZXMgRm91bmQ8L2gzPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIG1iLTZcIj5XZSdyZSB3b3JraW5nIGhhcmQgdG8gYnJpbmcgbW9yZSBzZXJ2aWNlcyB0byB5b3UuPC9wPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMiBiZy1ncmF5LTUwIHRleHQtc2Vjb25kYXJ5IGZvbnQtYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvbi1hbGwgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IFJlZnJlc2hcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2VydmljZXM7XHJcbiJdLCJmaWxlIjoiQzovUHJvamVjdC9TZXJ2aWNlL2NsaWVudC9zcmMvZmVhdHVyZXMvc2hhcmVkL3N0YXRpYy9TZXJ2aWNlcy5qc3gifQ==